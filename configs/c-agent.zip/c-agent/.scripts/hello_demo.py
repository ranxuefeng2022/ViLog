#!/usr/bin/env python3
#!/usr/bin/env python3
import sys
import datetime

def main():
    print("=" * 40)
    print("你好！这是一个演示脚本")
    print("=" * 40)
    print(f"当前时间: {datetime.datetime.now()}")
    print(f"Python 版本: {sys.version}")
    print(f"命令行参数: {sys.argv[1:]}")
    print("=" * 40)

if __name__ == "__main__":
    main()
