# c-agent — C11 终端 AI 编程助手

基于 C11 的终端 AI 编程助手，通过 Anthropic Messages API 与 LLM 交互。ReAct + Plan-and-Execute + Reflection 代理架构，termbox2 TUI，SSE 流式输出，pthread 多线程，模块化工具系统。

技术栈: C11 (gcc -std=gnu11) | termbox2 | cJSON (vendored) | libcurl | pthread

## 快速开始

```bash
export GLM_API_KEY=xxx          # 设置 API 密钥 (或 DEEPSEEK_API_KEY / KIMI_API_KEY)
make                            # 编译 (产物仅 c-agent，.o 自动删除)
make test                       # 编译并运行所有测试套件
make clean                      # 清理
./c-agent                       # 启动 (自动检测 TTY 选择 TUI/stdio)
```

## 核心架构

```
main.c → app.c (TUI 事件循环 + 线程管理) → agent.c (ReAct 循环)
       → llm_client.c (HTTP/SSE) → tool_engine.c → tools/* (工具模块)
       → tui.c (渲染) → context.c (上下文管理)
```

| 模块 | 职责 |
|------|------|
| `app.c` | TUI 事件循环，agent 线程管理，弹窗交互 |
| `agent.c` | ReAct 循环，Plan/Reflection，StreamAdapter 桥接 AgentOutput→StreamCallbacks |
| `llm_client.c` | HTTP/SSE 通信，消息管理，流式解析 |
| `tool_engine.c` | 工具注册表，ToolContext 分发，返回 ToolResult |
| `tui.c` | termbox2 渲染，输入处理，弹窗渲染 |

## 10 条黄金法则

1. **agent 线程禁止直接访问 TUIState** — 所有 UI 更新通过 RingBuffer 间接完成
2. **跨线程共享数据必须用 `_Atomic` 或 `pthread_mutex`** — 禁止 `volatile` 做线程同步
3. **工具返回 `ToolResult {success, text}`** — 调用者检查 `.success`，不匹配字符串前缀
4. **命令执行用 `fork()+execvp()`** — 禁止 `popen()`，无 shell 注入风险
5. **API 密钥只从环境变量 `getenv()` 读取** — 禁止硬编码任何密钥
6. **新增工具用 `TOOL_MODULE` 宏** — 在 `app.c` 的 `init_modules()` 注册，零改动核心代码
7. **4 空格缩进，`snake_case` 函数名带模块前缀，`PascalCase` 类型名** — 保持风格一致
8. **`malloc`/`fopen` 返回值必须检查** — 处理 NULL，不允许静默忽略
9. **每次修改后运行 `make test`** — 确保所有测试通过
10. **修改数据结构或函数签名后更新 SKILL.md** — 保持知识库同步

## 文件结构

```
src/main.c          入口：config → 注册 → run mode
src/app.c/h         TUI 事件循环，线程管理
src/command.c/h     斜杠命令数据 (纯数据，无渲染)
src/prompt.c/h      系统提示词构建
src/agent.c/h       Agent 循环，Plan，Reflection，AgentOutput
src/llm_client.c/h  LLM HTTP/SSE 通信
src/context.c/h     上下文管理，token 估算
src/tool_engine.c/h 工具注册表，ToolContext
src/tui.c/h         TUI 渲染，输入，弹窗
src/tools/          工具模块 (file_ops, compiler, project_analyzer, math_ops)
vendor/             cJSON, termbox2 (vendored)
tests/              测试套件
```

## 必读文档

修改代码前必须阅读开发规范:
@.claude/conventions.md

技术知识库（数据结构、调用链、线程模型等详细信息，以及自动更新规则）:
@.claude/skills/c-agent-knowledge/SKILL.md
