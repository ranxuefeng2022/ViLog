# c-agent 开发规范

> 本文档定义 c-agent 项目的编码、架构、模块化、并发、内存、安全等方面的开发规范。
> AI 在开发本项目时必须遵守这些规则。

---

## 1. 编码风格

### 1.1 命名约定

| 实体 | 风格 | 示例 | 规则 |
|------|------|------|------|
| 类型 (struct/enum/typedef) | PascalCase | `AgentSession`, `ToolResult`, `StepStatus` | 每个单词首字母大写 |
| 函数 | snake_case + 模块前缀 | `tool_registry_init`, `agent_run_turn` | `模块_动作` 格式 |
| 静态内部函数 | snake_case 无前缀 | `emit_text`, `adapter_on_text` | 仅模块内部使用 |
| 宏/常量 | UPPER_SNACK_CASE | `AGENT_MAX_ITERATIONS`, `HISTORY_MAX` | 全大写+下划线 |
| 枚举值 | UPPER_SNAKE_CASE | `STEP_PENDING`, `AGENT_OK` | 同宏命名规则 |
| 局部变量 | snake_case | `result_len`, `msg_count` | 简短有意义 |
| 文件名 | snake_case | `tool_engine.c`, `llm_client.h` | 小写+下划线 |

正确示例:
```c
ToolResult result = tool_execute(reg, name, params);
int token_count = context_estimate_tokens(text);
static void adapter_on_text(void *ud, const char *text, size_t len);
```

错误示例:
```c
ToolResult res = tool_execute(reg, name, params);  // 𐄂 缩写无意义
int tokens = context_est_tokens(text);               // 𐄂 函数名缩写
static void AdapterOnText(void *ud, ...);             // 𐄂 C 函数不用 PascalCase
```

### 1.2 格式规范

- **缩进**: 4 个空格，禁止 Tab
- **花括号**: K&R 风格（函数定义花括号独占一行，控制结构花括号同行）

```c
// 函数定义 — 花括号独占一行
static void emit_text(AgentSession *session, const char *text, size_t len)
{
    if (session->output.on_text)
        session->output.on_text(session->output.user_data, text, len);
}

// 控制结构 — 花括号同行
if (result.success) {
    llm_append_tool_result(ctx, id, result.text);
} else {
    rb_push(ring, TAG_ERROR, result.text, strlen(result.text));
}
```

- **行宽**: 目标 100 字符，硬上限 120 字符
- **空格**: 关键字后加空格 `if (`, `while (`, `for (`；二元运算符两侧加空格
- **指针星号**: 靠近变量名 `char *text`, `AgentSession *session`

### 1.3 注释规范

**核心原则: 注释只写 WHY，不写 WHAT。** 代码本身应该能说明做了什么。

```c
// 好的注释 — 解释 WHY
/* fork+execvp 避免通过 shell 解释参数，防止命令注入 */
pid_t pid = fork();

// 坏的注释 — 只是重复 WHAT
/* 循环遍历工具调用 */
cJSON_ArrayForEach(item, tool_calls) {
```

**何时写注释:**
- 非显而易见的约束或不变量
- 临时变通方案 (workaround)，说明原因和关联的 bug/issue
- 并发安全的设计决策
- 性能优化的理由

**何时不写注释:**
- 函数签名已经自解释的
- 重复代码逻辑的描述
- 变量声明后的说明

**分隔注释**: 模块内用 `/* ===== Section Name ===== */` 划分区域:
```c
/* ===== Session lifecycle ===== */

void agent_session_init(AgentSession *session, ...) { ... }
void agent_session_free(AgentSession *session) { ... }

/* ===== Plan Management ===== */

AgentPlan *agent_plan_parse(const char *plan_text) { ... }
```

### 1.4 头文件规范

**Include Guard**: 使用 `#ifndef FILENAME_H` 格式:
```c
#ifndef AGENT_H
#define AGENT_H
// ...
#endif
```

**Include 顺序**:
1. 对应的 `.h` 文件（如果 `.c` 文件）
2. 本项目的头文件 (`"..."`)
3. vendor 头文件 (`"cJSON.h"`, `"termbox2.h"`)
4. 系统头文件 (`<...>`)

```c
// agent.c
#include "agent.h"           // 1. 对应头文件
#include "string_utils.h"    // 2. 项目头文件
#include <stdio.h>           // 4. 系统头文件
#include <stdlib.h>
#include <string.h>
```

**头文件内容**: 只放声明（类型定义、函数声明、宏），不放实现。唯一的例外是 `static inline` 函数（如 `tool_ok`/`tool_err`）。

---

## 2. 软件工程设计原则

> 以下是本项目遵循的核心设计原则。每次新增模块、拆分文件、设计接口时，必须用这些原则检验设计是否合理。

### 2.1 高内聚低耦合

**内聚**: 一个模块内部的代码应该围绕同一个目标协作。一个函数只做一件事，一个文件只管一个领域。

```c
// 高内聚 — command.c 只管命令数据定义，不管渲染
static const SlashCommandDef SLASH_COMMANDS[] = { ... };
void cmd_update_matches(CommandPopup *popup, const char *input) { ... }

// 低内聚 — 把渲染和数据混在一起
void cmd_render_and_handle(CommandPopup *popup, TUIState *tui) {  // 𐄂 一个函数既处理逻辑又画 UI
    tb_set_cell(x, y, ...);  // 𐄂 command 不应该知道 termbox2
    cmd_update_matches(popup, input);
}
```

**耦合**: 模块之间通过最小接口交互，不暴露内部实现。衡量标准：修改一个模块时，需要同步修改多少其他文件。

| 耦合等级 | 本项目要求 | 示例 |
|----------|-----------|------|
| 无耦合 | 数据模块的标准 | `command.c` 零外部依赖 |
| 数据耦合 (只传数据) | 工具模块的标准 | `tools/*.c` 只接收 `ToolContext` + `cJSON` |
| 接口耦合 (通过函数指针) | 跨层通信的标准 | `AgentOutput` 回调抽象 |
| 实现耦合 (知道内部结构) | **禁止** | agent 线程直接操作 `TUIState` |

**检验方法**: 新增或修改一个工具模块时，应该只需要改动 `tools/` 下的文件和 `app.c` 的注册行。如果需要改动 `agent.c`、`tui.c` 或 `llm_client.c`，说明耦合出了问题。

### 2.2 关注点分离 (Separation of Concerns)

不同性质的代码必须物理分离到不同文件：

| 关注点 | 归属文件 | 不应该出现在 |
|--------|----------|-------------|
| 数据定义 | `command.c`, `config.c` | `tui.c`, `app.c` |
| 渲染逻辑 | `tui.c` | `command.c`, `agent.c` |
| 业务策略 | `agent.c` | `tui.c`, `app.c` |
| HTTP 通信 | `llm_client.c` | `agent.c`, `tui.c` |
| 工具实现 | `tools/*.c` | `tool_engine.c` |
| 事件分发 | `app.c` | `tui.c`, `agent.c` |

**本项目最关键的分离**: 命令的数据定义 (`command.c`) 和命令的渲染 (`tui.c`) 完全分离。`command.c` 中没有一行 `tb_set_cell`，`tui.c` 不知道有哪些命令。

### 2.3 分层架构

本项目采用清晰的 3 层架构，依赖严格单向：

```
┌─────────────────────────────────────────┐
│ 表现层 (Presentation)                   │  app.c, tui.c, command.c
│ — 用户交互、事件循环、渲染              │  只调用应用层接口
├─────────────────────────────────────────┤
│ 应用层 (Application/Business)           │  agent.c, context.c
│ — 业务策略、ReAct 循环、上下文管理      │  只调用基础设施层接口
├─────────────────────────────────────────┤
│ 基础设施层 (Infrastructure)             │  llm_client.c, tool_engine.c, tools/*
│ — HTTP 通信、工具执行、文件操作          │  不依赖上层
└─────────────────────────────────────────┘
```

**依赖规则**: 上层可以调用下层，下层不能调用上层。跨越层级必须通过抽象接口（回调/函数指针）。

```
// 正确 — 上层调用下层
app.c → agent_run_turn() → llm_chat_ex()

// 正确 — 跨层通过抽象接口
agent.c → AgentOutput.on_text()  (agent 不知道谁在接收)

// 错误 — 下层依赖上层
llm_client.c → tui_push_line()   // 𐄂 HTTP 层不应知道 UI
```

### 2.4 依赖倒置 (Dependency Inversion)

高层模块不依赖低层模块的具体实现，两者都依赖抽象接口。

**本项目的核心抽象:**

| 高层模块 | 抽象接口 | 低层实现 |
|----------|----------|----------|
| `agent.c` | `AgentOutput` (回调) | `app.c` 中的 RingBuffer 回调 |
| `agent.c` | `StreamCallbacks` | `llm_client.c` 中的 SSE 解析 |
| `tool_engine.c` | `ToolFunc` (函数指针) | `tools/*.c` 中的具体工具 |
| `tui.c` | `tui_render_menu_popup()` | `app.c` 传入命令数据 |

```c
// agent.c 不知道 RingBuffer、termbox2、TUIState 的存在
// 它只知道 AgentOutput 这个抽象
typedef struct {
    void (*on_text)(void *ud, const char *text, size_t len);
    void (*on_tool_call)(void *ud, const char *name, const char *input_json);
    // ...
} AgentOutput;

// app.c 在运行时注入具体实现
session->output.on_text = on_stream_text;  // 具体实现: rb_push
session->output.user_data = ring;
```

**新增功能时的检验**: 如果 `agent.c` 需要 `#include "tui.h"` 或 `#include "ringbuf.h"`，说明抽象出了问题。正确的做法是在 `AgentOutput` 中添加新的回调。

### 2.5 信息隐藏 (Information Hiding)

模块通过 `.h` 文件暴露最小公共接口，实现细节留在 `.c` 中。

```c
// tool_engine.h — 暴露的接口
void       tool_registry_init(ToolRegistry *reg);
ToolResult tool_execute(ToolRegistry *reg, const char *name, cJSON *params);
void       tool_registry_free(ToolRegistry *reg);

// 调用者不需要知道:
// - ToolEntry 的具体字段
// - 工具是如何存储的 (动态数组)
// - ToolContext 是如何传递的
```

**规则:**
- `.h` 文件只放类型定义、函数声明、宏定义
- 结构体的内部字段如果调用者不需要直接访问，考虑用不透明指针 (opaque pointer)
- `static` 函数和 `static` 全局变量不出现在 `.h` 中
- 如果一个函数只有本模块使用，声明为 `static`

**本项目的例外**: `AgentSession`、`TUIState` 等结构体字段是公开的，因为 C 没有私有成员机制，且调用者需要栈分配。这是 C 语言的务实选择——用文档约束访问边界。

### 2.6 不重复 (DRY — Don't Repeat Yourself)

重复代码是系统腐化的根源。同一段逻辑出现 3 次以上，必须提取。

```c
// 重复 — 多个工具都有类似的参数检查
cJSON *path = cJSON_GetObjectItem(params, "path");
if (!path || !path->valuestring) return tool_err("Missing 'path'");

// 提取后 — 在 tool_module.h 提供辅助宏或函数
static inline const char *json_string(cJSON *obj, const char *key) {
    cJSON *item = cJSON_GetObjectItem(obj, key);
    return (item && item->valuestring) ? item->valuestring : NULL;
}
```

**但要避免过度抽象**: 三行相似代码比一个过早抽象好。如果提取后的抽象增加了理解成本，不如保持重复。

判断标准：
- **提取**: 3 处以上重复 + 未来还会增加 + 逻辑复杂易出错
- **不提取**: 2 处重复 + 不会增加 + 每处有微妙差异

### 2.7 开放封闭 (Open/Closed Principle)

新增功能时，应该通过添加代码来实现，而不是修改已有代码。

**本项目的经典案例 — 工具系统:**

```c
// 新增一个工具，只需:
// 1. 创建 tools/new_tool.c — 添加新文件
// 2. app.c 添加一行注册 — 最小改动
// 3. 不修改 tool_engine.c, agent.c, llm_client.c

// TOOL_MODULE 宏让工具自描述
TOOL_MODULE(new_tool, TOOLS);
// tool_register_module 自动注册所有工具到 Registry
// sync_tools_to_llm 自动同步到 LLM
// agent.c 自动调用新工具
```

**反模式 — 修改核心文件:**
```c
// 如果新增工具需要改 agent.c 的 execute_tools():
if (strcmp(name, "new_tool") == 0) {  // 𐄂 每加一个工具改一次 agent.c
    // special handling
}
// 说明工具系统的抽象不够，需要改进注册机制
```

### 2.8 单一职责 (Single Responsibility)

每个函数只做一件事，每个文件只管一个领域。

**函数层面的单一职责:**

```c
// 好的 — 一个函数一个职责
static void emit_text(AgentSession *session, const char *text, size_t len) {
    if (session->output.on_text)
        session->output.on_text(session->output.user_data, text, len);
}

// 坏的 — 一个函数做太多事
void process_and_render(AgentSession *session, TUIState *tui) {  // 𐄂 又处理又渲染
    LLMResponse resp;
    llm_chat_ex(session->ctx, NULL, &resp, &sc);  // 𐄂 调 LLM
    tui_push_line(tui, TAG_AGENT, resp.text);       // 𐄂 又更新 UI
    free(resp.text);
}
```

**文件层面的单一职责:**

| 如果你想把 X 加入 Y 文件... | 先问: 这个职责属于 Y 吗？ |
|---|---|
| 渲染逻辑加入 `command.c` | 不属于。command 是纯数据，渲染放 `tui.c` |
| HTTP 解析加入 `agent.c` | 不属于。agent 是策略层，HTTP 放 `llm_client.c` |
| 业务规则加入 `tui.c` | 不属于。tui 是表现层，业务放 `agent.c` |

### 2.9 接口隔离 (Interface Segregation)

不要强迫模块依赖它不需要的接口。

```c
// 好的 — 工具只看到 ToolContext (只有 workspace)
typedef struct {
    char workspace[1024];
} ToolContext;

// 坏的 — 工具看到整个 AppContext
typedef struct { ... } AppContext;  // 𐄂 工具不需要知道 agent、tui、ring

// 好的 — llm_client 不知道 UI
int llm_chat_ex(LLMContext *ctx, const char *msg,
                LLMResponse *resp, StreamCallbacks *callbacks);
// callbacks 是抽象接口，llm_client 不知道背后是 RingBuffer 还是 stdout
```

### 2.10 设计决策检查清单

每次新增模块或修改架构时，逐项检查：

- [ ] **内聚**: 这个文件里的代码都围绕同一个目标吗？
- [ ] **耦合**: 修改这个模块时，需要改动几个其他文件？(目标: ≤2)
- [ ] **分层**: 依赖方向是否严格单向？有没有下层调用上层？
- [ ] **抽象**: 高层模块是否通过接口(回调/函数指针)与低层交互？
- [ ] **隐藏**: `.h` 文件是否只暴露必要的接口？
- [ ] **不重复**: 有没有 3 处以上的重复代码？
- [ ] **开放封闭**: 新增功能是否只需要添加代码，不改已有代码？
- [ ] **单一职责**: 每个函数只做一件事吗？每个文件只管一个领域吗？
- [ ] **接口隔离**: 模块是否只接收它需要的数据，不被迫依赖不需要的结构？

---

## 3. 架构设计

### 3.1 模块职责与边界

每个模块有且只有一个清晰的职责:

| 模块 | 唯一职责 | 不应该做 |
|------|----------|----------|
| `app.c` | UI 事件循环 + 线程编排 | 不包含业务逻辑 |
| `agent.c` | ReAct 循环策略 + Plan + Reflection | 不直接操作 UI 或 HTTP |
| `llm_client.c` | HTTP 通信 + 消息存储 | 不包含 agent 策略 |
| `tool_engine.c` | 工具注册 + 分发 | 不实现具体工具逻辑 |
| `tools/*.c` | 具体工具实现 | 不依赖其他工具模块 |
| `context.c` | 上下文管理 + token 估算 + 快照转储 | 不直接操作 LLM 消息数组 |
| `tui.c` | 渲染 + 输入处理 | 不包含业务逻辑 |
| `command.c` | 命令/快捷键数据定义 | 不包含渲染代码 |

### 3.2 依赖方向规则

依赖必须单向流动，**禁止循环依赖**:

```
main.c → app.c → agent.c → llm_client.c → curl
                  → tool_engine.c → tools/*
                  → context.c → llm_client.h (仅类型)
         → tui.c → ringbuf.h
         → command.c (纯数据，无依赖)
```

**规则:**
- 上层模块可以 `#include` 下层模块的头文件
- 下层模块不得 `#include` 上层模块的头文件
- `command.c` 零外部依赖（纯数据定义）
- `tui.c` 不依赖 `agent.h`、`llm_client.h`
- `tools/*.c` 只依赖 `tool_module.h`，不依赖其他模块

### 3.3 接口设计原则

**最小接口**: 暴露必要的函数，隐藏实现细节。

```c
// 好的接口 — 调用者不需要知道内部结构
ToolResult tool_execute(ToolRegistry *reg, const char *name, cJSON *params);
void tool_registry_init(ToolRegistry *reg);
void tool_registry_free(ToolRegistry *reg);

// 坏的接口 — 暴露了内部数组操作
ToolEntry *tool_find_entry(ToolRegistry *reg, const char *name);  // 𐄂 调用者不应操作 ToolEntry
```

**回调抽象**: 当模块需要通知外部但不依赖外部时，使用回调。

```c
// AgentOutput — agent.c 不依赖任何 UI 代码
typedef struct {
    void  *user_data;
    void (*on_text)(void *ud, const char *text, size_t len);
    void (*on_tool_call)(void *ud, const char *name, const char *input_json);
    // ...
} AgentOutput;
```

**桥接模式**: 当两个模块的接口不兼容时，在调用侧做适配，不改被调用侧。

```c
// StreamAdapter 在 agent.c 内部桥接 AgentOutput → StreamCallbacks
// 不修改 llm_client.c 的 StreamCallbacks 接口
typedef struct {
    AgentOutput *output;
} StreamAdapter;
```

### 3.4 数据流向

**单向数据流**: 数据总是沿着依赖方向流动。

```
主线程: UI 事件 → AgentSession → llm_chat_ex → HTTP → SSE 响应
Agent 线程: SSE 响应 → AgentOutput 回调 → RingBuffer → 主线程消费
```

**所有权明确**: 每块动态内存有且只有一个所有者，释放权随所有权转移。

---

## 4. 模块化

### 4.1 新增工具模块

使用 `TOOL_MODULE` 宏自描述，核心代码零改动:

**步骤:**

1. 创建 `src/tools/new_tool.h`:
```c
#ifndef NEW_TOOL_H
#define NEW_TOOL_H

#include "tools/tool_module.h"

TOOL_MODULE_DECL(new_tool);

#endif
```

2. 创建 `src/tools/new_tool.c`:
```c
#include "new_tool.h"
#include <stdio.h>

static ToolResult tool_do_something(const char *name, cJSON *params, const ToolContext *ctx)
{
    cJSON *path_obj = cJSON_GetObjectItem(params, "path");
    if (!path_obj || !path_obj->valuestring)
        return tool_err("Missing 'path' parameter");

    const char *path = path_obj->valuestring;
    /* 使用 ctx->workspace 作为工作目录 */
    /* ... 执行操作 ... */

    return tool_ok(strdup("result text"));  /* 调用者负责 free */
}

static const ToolDesc TOOLS[] = {
    {"do_something",
     "Do something with a file",
     "{\"type\":\"object\",\"properties\":{\"path\":{\"type\":\"string\"}},\"required\":[\"path\"]}",
     tool_do_something},
};

TOOL_MODULE(new_tool, TOOLS);
```

3. 在 `app.c` 的 `init_modules()` 注册:
```c
#include "tools/new_tool.h"

void init_modules(void) {
    g_modules[0] = file_ops_module_get_module();
    // ...
    g_modules[N] = new_tool_module_get_module();  // 添加这一行
}
```

4. 同时增加 `g_modules` 数组大小

**Makefile 自动包含 `src/tools/*.c`，无需修改构建文件。**

### 4.2 新增源文件规范

如果添加新的 `.c/.h` 文件（非工具模块）:

1. 在 `src/` 下创建 `.c` 和 `.h` 文件
2. 遵循 include guard 和 include 顺序规范
3. 如果需要暴露给其他模块，在对应的 `.h` 中声明公共函数
4. Makefile 使用 `$(wildcard src/*.c)` 自动包含
5. 如果被测试使用，添加到 Makefile 的 `TEST_OBJS` 列表

### 4.3 模块间通信规则

- **同步调用**: 直接函数调用（如 `agent.c` 调用 `llm_chat_ex`）
- **异步通信**: 通过 `RingBuffer`（生产者-消费者模式，agent 线程 → 主线程）
- **回调通知**: 通过函数指针（如 `AgentOutput`）
- **禁止**: 模块间直接访问对方的内部状态变量

---

## 5. 并发安全

### 5.1 `_Atomic` 使用规范

**何时使用 `_Atomic`:**
- 简单的布尔标志，一个线程写、另一个线程读
- 配合 `atomic_store()` 和 `atomic_load()` 使用

```c
// 正确用法
_Atomic bool cancelled;                    // 声明
atomic_store(&session->cancelled, false);  // 写
if (atomic_load(&session->cancelled))      // 读
    return AGENT_ERROR_CANCELLED;

// 错误用法
volatile bool cancelled;    // 𐄂 不保证原子性
session->cancelled = true;  // 𐄂 数据竞争
```

### 5.2 RingBuffer 使用规范

RingBuffer 是唯一的跨线程数据通道:

```c
// Agent 线程 (生产者)
rb_push(ring, TAG_AGENT, text, len);     // 内部 mutex 保护

// 主线程 (消费者)
rb_has_data(ring);                        // 检查
tui_consume_output(tui);                  // 内部调用 rb_drain
```

**禁止:**
- 在两个线程中同时 `rb_push`（未设计为多生产者）
- 直接访问 `RingBuffer` 的内部字段

### 5.3 并发禁止事项

| 禁止事项 | 原因 | 正确做法 |
|----------|------|----------|
| agent 线程直接操作 TUIState | termbox2 非线程安全 | 通过 RingBuffer + rb_push |
| agent 线程调用 tb_* 函数 | termbox2 非线程安全 | 通过 AgentOutput 回调 |
| 用 `volatile` 做线程同步 | C 标准不保证原子性 | 用 `_Atomic` 或 `pthread_mutex` |
| 多线程同时访问同一 malloc 内存 | 未定义行为 | 用 mutex 保护或单线程所有权 |

---

## 6. 内存管理

### 6.1 所有权模型

每块动态内存有明确的所有者。所有者负责释放，所有权可以转移但不可共享。

**所有权表:**

| 资源 | 所有者 | 释放函数 |
|------|--------|----------|
| `AgentConfig` 字段 | `config` 模块 | `config_free()` |
| `LLMContext` 及消息 | `llm_client` 模块 | `llm_context_free()` |
| `LLMResponse` | 调用者 | `llm_response_free()` |
| `ToolResult.text` | 调用者 | `free()` |
| `tui_input_steal()` 返回值 | 调用者 | `free()` 或传给 agent 线程 |
| `build_system_prompt()` 返回值 | `main.c` | `free()` |
| `AgentPlan.steps` | `agent` 模块 | `agent_plan_free()` |

### 6.2 分配/释放必须配对

```c
// 正确 — 配对
char *text = strdup("hello");
// ... 使用 text ...
free(text);

// 正确 — 所有权转移
char *msg = tui_input_steal(tui);  // 所有权转移给 msg
thread_arg.user_msg = msg;          // 所有权转移给 thread_arg
// ... agent 线程完成后 ...
free(thread_arg.user_msg);          // 最终释放

// 错误 — 忘记释放 ToolResult.text
ToolResult r = tool_execute(reg, name, params);
llm_append_tool_result(ctx, id, r.text);
// 𐄂 缺少 free(r.text) — 内存泄漏！
```

### 6.3 malloc/fopen 检查

```c
// 正确 — 检查返回值
char *buf = malloc(size);
if (!buf) return tool_err("Out of memory");

FILE *f = fopen(path, "r");
if (!f) { free(buf); return tool_err("Cannot open file"); }

// 错误 — 静默忽略
char *buf = malloc(size);   // 𐄂 如果 malloc 失败，buf==NULL，后续操作崩溃
strcpy(buf, src);
```

---

## 7. 错误处理

### 7.1 ToolResult 模式

所有工具函数返回 `ToolResult`:

```c
// 成功 — 返回动态分配的结果文本
return tool_ok(strdup("file contents here"));

// 失败 — 返回错误信息（内部 strdup，调用者仍需 free）
return tool_err("File not found: src/main.c");

// 调用侧 — 检查 success 字段
ToolResult result = tool_execute(reg, name, params);
if (!result.success) {
    // 处理错误
}
free(result.text);  // 无论 success 与否，都要 free
```

**禁止用字符串匹配判断错误:**

```c
// 错误 — 旧模式
char *result = tool_execute(reg, name, params);
if (strncmp(result, "Error:", 6) == 0) {  // 𐄂 正常文本可能碰巧以 "Error:" 开头
    // ...
}

// 正确 — 新模式
ToolResult result = tool_execute(reg, name, params);
if (!result.success) {  // 结构化判断
    // ...
}
```

### 7.2 Agent 错误处理

agent 循环通过 `AgentResult` 枚举返回结果:

| 结果 | 含义 | TUI 显示 |
|------|------|----------|
| `AGENT_OK` | 正常完成 | 最终文本 |
| `AGENT_ERROR_API` | HTTP/LLM 错误 | [API Error] |
| `AGENT_ERROR_CANCELLED` | 用户中断 | [Interrupted] |
| `AGENT_ERROR_MAX_ITERATIONS` | 超过迭代上限 | [Max iterations reached] |

### 7.3 上下文溢出处理

当 token 估算超限时，通过 `llm_drop_messages()` 删除最早的完整对话轮次:

```c
// 正确 — 使用 API
llm_drop_messages(ctx, count);  // 正确释放消息内容

// 错误 — 直接操作数组
free(ctx->messages[0].content);  // 𐄂 绕过 API，可能遗漏 tool_calls 等字段
memmove(ctx->messages, ...);
```

---

## 8. 安全规范

### 8.1 命令执行安全

**强制使用 `fork()+execvp()`，禁止 `popen()`:**

```c
// 正确 — 参数作为独立 argv 传递，无 shell 解释
pid_t pid = fork();
if (pid == 0) {
    char *argv[] = {"/bin/sh", "-c", cmd, NULL};
    execvp(argv[0], argv);
    _exit(127);
}

// 正确 — grep 无 shell，pattern 和 extension 作为独立参数
char *argv[] = {"grep", "-rn", "--include", ext, pattern, ctx->workspace, NULL};
execvp("grep", argv);

// 错误 — shell 注入风险
char cmd[256];
snprintf(cmd, sizeof(cmd), "grep -rn '%s' %s", pattern, path);  // 𐄂 单引号绕过不完整
FILE *fp = popen(cmd, "r");                                       // 𐄂 shell 会解释特殊字符
```

### 8.2 API 密钥管理

**禁止硬编码任何 API 密钥。** 只从环境变量读取:

```c
// 正确
const char *env_key = "GLM_API_KEY";
const char *key = getenv(env_key);

// 错误
const char *key = "sk-xxxxxxxx";  // 𐄂 禁止硬编码
```

### 8.3 输入消毒

外部输入（用户输入、工具参数）在使用前必须验证:

```c
// 正确 — 检查 cJSON 字段存在性和类型
cJSON *path_obj = cJSON_GetObjectItem(params, "path");
if (!path_obj || !cJSON_IsString(path_obj))
    return tool_err("Missing or invalid 'path' parameter");

// 错误 — 盲目使用
const char *path = cJSON_GetObjectItem(params, "path")->valuestring;  // 𐄂 可能 NULL
```

---

## 9. 测试规范

### 9.1 测试要求

- 每次修改后必须运行 `make test`
- 新增工具必须添加对应的测试文件 `tests/test_new_tool.c`
- 测试使用 `tests/test_framework.h` 提供的宏:
  - `TEST(name)` — 定义测试函数
  - `ASSERT(cond)` — 断言条件为真
  - `ASSERT_STR_EQ(a, b)` — 断言字符串相等
  - `ASSERT_INT_EQ(a, b)` — 断言整数相等

### 9.2 测试模式

- 工具测试: 使用临时目录作为 workspace，测试后清理
- Agent 测试: 使用 mock LLM 响应，不依赖真实 API
- 内存测试: 使用 Valgrind 验证 0 leaks, 0 errors
