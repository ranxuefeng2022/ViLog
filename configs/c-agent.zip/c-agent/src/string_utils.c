#include "string_utils.h"
#include <stdlib.h>
#include <string.h>

void sb_init(StringBuffer *sb) {
    sb->data = NULL;
    sb->len = 0;
    sb->cap = 0;
}

void sb_append(StringBuffer *sb, const char *data, size_t len) {
    if (sb->len + len + 1 > sb->cap) {
        size_t new_cap = (sb->cap == 0) ? 4096 : sb->cap;
        while (new_cap < sb->len + len + 1) new_cap *= 2;
        sb->data = realloc(sb->data, new_cap);
        sb->cap = new_cap;
    }
    memcpy(sb->data + sb->len, data, len);
    sb->len += len;
    sb->data[sb->len] = '\0';
}

void sb_free(StringBuffer *sb) {
    free(sb->data);
    sb_init(sb);
}
