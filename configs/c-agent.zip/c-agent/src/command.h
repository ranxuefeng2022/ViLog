#ifndef COMMAND_H
#define COMMAND_H

#include <stdbool.h>

typedef enum {
    CMD_THEME,
    CMD_MODEL,
    CMD_SHORTCUTS,
    CMD_COUNT
} SlashCommand;

typedef struct {
    const char *name;
    const char *desc;
    const char *shortcut;
    SlashCommand id;
} SlashCommandDef;

typedef struct {
    bool active;
    int  match_indices[16];
    int  match_count;
    int  selected;
} CommandPopup;

enum { SUB_NONE, SUB_THEME, SUB_MODEL, SUB_SHORTCUTS };

const SlashCommandDef *command_def(int index);
int                    command_def_count(void);

typedef struct { const char *key; const char *desc; } ShortcutInfo;
int                    shortcut_count(void);
const ShortcutInfo    *shortcut_get(int index);

void cmd_update_matches(CommandPopup *popup, const char *input);

#endif
