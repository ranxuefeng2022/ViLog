#include "context.h"
#include "llm_client.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>

int context_estimate_tokens(const char *text) {
    if (!text) return 0;
    int len = (int)strlen(text);
    return (len + CTX_CHARS_PER_TOKEN - 1) / CTX_CHARS_PER_TOKEN;
}

int context_estimate_messages(LLMContext *ctx) {
    int total = 0;
    int count = llm_msg_count(ctx);
    for (int i = 0; i < count; i++) {
        total += context_estimate_tokens(llm_msg_content(ctx, i));
        cJSON *tc = llm_msg_tool_calls(ctx, i);
        if (tc) {
            char *tc_json = cJSON_PrintUnformatted(tc);
            total += context_estimate_tokens(tc_json);
            free(tc_json);
        }
    }
    return total;
}

ContextStats context_compute_stats(LLMContext *ctx, const char *system_prompt) {
    ContextStats s = {0};
    s.message_count = llm_msg_count(ctx);
    s.total_estimated_tokens = context_estimate_tokens(system_prompt);
    s.total_estimated_tokens += context_estimate_messages(ctx);
    return s;
}

/* ===== Context Dump (Markdown) ===== */

static void mkdirs(const char *path) {
    char tmp[2048];
    snprintf(tmp, sizeof(tmp), "%s", path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            mkdir(tmp, 0755);
            *p = '/';
        }
    }
    mkdir(tmp, 0755);
}

static void write_file(const char *path, const char *content) {
    FILE *f = fopen(path, "w");
    if (!f) return;
    if (content) fputs(content, f);
    fclose(f);
}

static void fwrite_timestamp(FILE *f) {
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    char buf[32];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", t);
    fputs(buf, f);
}

static void fwrite_escaped_json(FILE *f, const char *json) {
    fputc('"', f);
    for (const char *p = json; *p; p++) {
        if (*p == '"')      fputs("\\\"", f);
        else if (*p == '\\') fputs("\\\\", f);
        else                fputc(*p, f);
    }
    fputc('"', f);
}

static const char *role_label(MessageRole role) {
    switch (role) {
        case ROLE_USER:        return "User";
        case ROLE_ASSISTANT:   return "Assistant";
        case ROLE_TOOL_RESULT: return "Tool Result";
        default:               return "Unknown";
    }
}

void context_dump_md(LLMContext *ctx, const char *system_prompt, int seq, const char *base_dir) {
    char dir[2048];
    snprintf(dir, sizeof(dir), "%s/.ctx", base_dir);
    mkdirs(dir);

    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    char ts[16];
    strftime(ts, sizeof(ts), "%H%M%S", t);

    char filename[64];
    snprintf(filename, sizeof(filename), "%03d_%s.md", seq, ts);

    char path[2200];
    snprintf(path, sizeof(path), "%s/%s", dir, filename);

    FILE *f = fopen(path, "w");
    if (!f) return;

    ContextStats stats = context_compute_stats(ctx, system_prompt);
    int msg_count = llm_msg_count(ctx);

    fprintf(f, "# Context #%03d | ", seq);
    fwrite_timestamp(f);
    fprintf(f, "\n\n> tokens: ~%d | messages: %d\n\n---\n",
            stats.total_estimated_tokens, stats.message_count);

    if (system_prompt) {
        fprintf(f, "\n## System\n\n%s\n\n---\n", system_prompt);
    }

    for (int i = 0; i < msg_count; i++) {
        MessageRole role = llm_msg_role(ctx, i);
        const char *label = role_label(role);
        const char *tool_id = llm_msg_tool_use_id(ctx, i);
        const char *content = llm_msg_content(ctx, i);
        cJSON *tool_calls = llm_msg_tool_calls(ctx, i);

        if (role == ROLE_TOOL_RESULT && tool_id) {
            fprintf(f, "\n## %s (%s)\n\n", label, tool_id);
        } else {
            fprintf(f, "\n## %s\n\n", label);
        }

        if (content) {
            if (role == ROLE_TOOL_RESULT) {
                fputs("```\n", f);
                fputs(content, f);
                fputs("\n```\n", f);
            } else {
                fputs(content, f);
                fputc('\n', f);
            }
        }

        if (role == ROLE_ASSISTANT && tool_calls) {
            fputs("\n[tool_calls]\n```json\n", f);
            cJSON *item;
            cJSON_ArrayForEach(item, tool_calls) {
                cJSON *name_obj = cJSON_GetObjectItem(item, "name");
                cJSON *input_obj = cJSON_GetObjectItem(item, "input");
                const char *name = name_obj ? name_obj->valuestring : "unknown";
                fprintf(f, "  %s(", name);
                if (input_obj) {
                    char *input_str = cJSON_PrintUnformatted(input_obj);
                    fwrite_escaped_json(f, input_str);
                    free(input_str);
                } else {
                    fputs("{}", f);
                }
                fputs(")\n", f);
            }
            fputs("```\n", f);
        }

        fputs("\n---\n", f);
    }

    fclose(f);

    char latest_path[2100];
    snprintf(latest_path, sizeof(latest_path), "%s/.ctx/latest", base_dir);
    write_file(latest_path, filename);
}

void context_dump_request_json(const char *json, int seq, const char *base_dir) {
    if (!json || !base_dir) return;

    char dir[2048];
    snprintf(dir, sizeof(dir), "%s/.ctx", base_dir);
    mkdirs(dir);

    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    char ts[16];
    strftime(ts, sizeof(ts), "%H%M%S", t);

    char filename[64];
    snprintf(filename, sizeof(filename), "%03d_%s_req.json", seq, ts);

    char path[2200];
    snprintf(path, sizeof(path), "%s/%s", dir, filename);

    FILE *f = fopen(path, "w");
    if (!f) return;
    cJSON *root = cJSON_Parse(json);
    if (root) {
        char *formatted = cJSON_Print(root);
        if (formatted) { fputs(formatted, f); free(formatted); }
        cJSON_Delete(root);
    } else {
        fputs(json, f);
    }
    fputc('\n', f);
    fclose(f);
}
