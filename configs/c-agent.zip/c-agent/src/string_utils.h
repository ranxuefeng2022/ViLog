#ifndef STRING_UTILS_H
#define STRING_UTILS_H

#include <stddef.h>

typedef struct {
    char   *data;
    size_t  len;
    size_t  cap;
} StringBuffer;

void sb_init(StringBuffer *sb);
void sb_append(StringBuffer *sb, const char *data, size_t len);
void sb_free(StringBuffer *sb);

#endif
