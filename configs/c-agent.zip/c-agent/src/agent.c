#include "agent.h"
#include "string_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===== Stream adapter: AgentOutput -> StreamCallbacks ===== */

typedef struct {
    AgentOutput *output;
} StreamAdapter;

static void adapter_on_text(void *ud, const char *text, size_t len) {
    StreamAdapter *a = (StreamAdapter *)ud;
    if (a->output->on_text)
        a->output->on_text(a->output->user_data, text, len);
}

static void adapter_on_thinking(void *ud, const char *text, size_t len) {
    StreamAdapter *a = (StreamAdapter *)ud;
    if (a->output->on_thinking)
        a->output->on_thinking(a->output->user_data, text, len);
}

static void adapter_on_complete(void *ud, int cancelled) {
    (void)ud; (void)cancelled;
}

static bool session_has_output(const AgentSession *session) {
    return session->output.on_text != NULL;
}

/* ===== Session lifecycle ===== */

void agent_session_init(AgentSession *session, LLMContext *ctx, ToolRegistry *reg) {
    memset(session, 0, sizeof(*session));
    session->ctx = ctx;
    session->reg = reg;
    session->max_iterations = AGENT_MAX_ITERATIONS;
    reflection_init(&session->reflection);
}

void agent_session_free(AgentSession *session) {
    agent_plan_free(&session->plan);
    free(session->reflection.last_error);
    memset(session, 0, sizeof(*session));
}

void agent_session_reset(AgentSession *session) {
    agent_plan_free(&session->plan);
    memset(&session->plan, 0, sizeof(session->plan));
    reflection_reset(&session->reflection);
    session->iteration_count = 0;
    atomic_store(&session->cancelled, false);
}

/* ===== Plan Management ===== */

AgentPlan *agent_plan_parse(const char *plan_text) {
    if (!plan_text || !plan_text[0]) return NULL;

    AgentPlan *plan = calloc(1, sizeof(AgentPlan));
    plan->steps = calloc(AGENT_MAX_PLAN_STEPS, sizeof(PlanStep));
    plan->step_count = 0;
    plan->current_step = 0;
    plan->active = true;

    const char *p = plan_text;
    while (*p && plan->step_count < AGENT_MAX_PLAN_STEPS) {
        while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;

        const char *line_start = p;
        while (*p && *p != '\n') p++;
        int line_len = (int)(p - line_start);
        if (line_len == 0) continue;

        while (*p == '\n' || *p == '\r') p++;

        int skip = 0;
        while (skip < line_len && (line_start[skip] == '-' || line_start[skip] == '*' ||
               line_start[skip] == ' ' || line_start[skip] == '\t' ||
               (line_start[skip] >= '0' && line_start[skip] <= '9') ||
               line_start[skip] == '.' || line_start[skip] == ')')) {
            skip++;
        }
        while (skip < line_len && line_start[skip] == ' ') skip++;

        if (skip >= line_len) continue;

        int desc_len = line_len - skip;
        char *desc = malloc(desc_len + 1);
        memcpy(desc, line_start + skip, desc_len);
        desc[desc_len] = '\0';

        plan->steps[plan->step_count].index = plan->step_count;
        plan->steps[plan->step_count].description = desc;
        plan->steps[plan->step_count].status = STEP_PENDING;
        plan->steps[plan->step_count].result_summary = NULL;
        plan->step_count++;
    }

    if (plan->step_count == 0) {
        free(plan->steps);
        free(plan);
        return NULL;
    }

    return plan;
}

void agent_plan_free(AgentPlan *plan) {
    if (!plan || !plan->steps) return;
    for (int i = 0; i < plan->step_count; i++) {
        free(plan->steps[i].description);
        free(plan->steps[i].result_summary);
    }
    free(plan->steps);
    free(plan->plan_summary);
    memset(plan, 0, sizeof(*plan));
}

void agent_plan_update_step(AgentPlan *plan, int index, StepStatus status, const char *summary) {
    if (!plan || index < 0 || index >= plan->step_count) return;
    plan->steps[index].status = status;
    free(plan->steps[index].result_summary);
    plan->steps[index].result_summary = summary ? strdup(summary) : NULL;

    if (status == STEP_IN_PROGRESS) {
        plan->current_step = index;
    }
}

char *agent_plan_format(const AgentPlan *plan) {
    if (!plan || plan->step_count == 0) return strdup("No active plan.");

    StringBuffer buf;
    sb_init(&buf);

    const char *hdr = "Current Plan:\n";
    sb_append(&buf, hdr, strlen(hdr));
    for (int i = 0; i < plan->step_count; i++) {
        const char *marker;
        switch (plan->steps[i].status) {
            case STEP_PENDING:     marker = "[ ]"; break;
            case STEP_IN_PROGRESS: marker = "[>]"; break;
            case STEP_DONE:        marker = "[x]"; break;
            case STEP_FAILED:      marker = "[!]"; break;
            case STEP_SKIPPED:     marker = "[-]"; break;
            default:               marker = "[?]"; break;
        }
        char line[512];
        snprintf(line, sizeof(line), "%s %d. %s\n", marker, i + 1, plan->steps[i].description);
        sb_append(&buf, line, strlen(line));
        if (plan->steps[i].result_summary) {
            snprintf(line, sizeof(line), "    -> %s\n", plan->steps[i].result_summary);
            sb_append(&buf, line, strlen(line));
        }
    }

    return buf.data;
}

/* ===== Reflection ===== */

void reflection_init(ReflectionState *r) {
    memset(r, 0, sizeof(*r));
}

void reflection_record_tool_result(ReflectionState *r, bool success, const char *text) {
    r->total_tool_calls++;
    if (!success) {
        r->consecutive_errors++;
        r->last_tool_failed = true;
        free(r->last_error);
        r->last_error = strdup(text);
    } else {
        r->consecutive_errors = 0;
        r->last_tool_failed = false;
    }
}

void reflection_record_retry(ReflectionState *r) {
    r->total_retries++;
    r->consecutive_errors = 0;
}

bool reflection_should_retry(const ReflectionState *r) {
    return r->consecutive_errors > 0 && r->consecutive_errors < AGENT_MAX_RETRIES;
}

void reflection_reset(ReflectionState *r) {
    free(r->last_error);
    memset(r, 0, sizeof(*r));
}

char *reflection_build_prompt(const ReflectionState *r) {
    StringBuffer buf;
    sb_init(&buf);

    if (r->consecutive_errors > 0 && r->last_error) {
        const char *header = "## Reflection: Recent Errors\n";
        sb_append(&buf, header, strlen(header));
        char tmp[256];
        snprintf(tmp, sizeof(tmp),
                 "The last %d tool call(s) failed. Last error: %s\n",
                 r->consecutive_errors, r->last_error);
        sb_append(&buf, tmp, strlen(tmp));
        const char *consider =
            "Consider:\n"
            "1. Was the tool called with correct parameters?\n"
            "2. Does the target file/path exist?\n"
            "3. Should you try a different approach?\n"
            "4. Should you read the file first before modifying it?\n";
        sb_append(&buf, consider, strlen(consider));
    }

    if (r->total_tool_calls > 5) {
        char tmp[128];
        snprintf(tmp, sizeof(tmp),
                 "\nProgress: %d tool calls made so far.\n", r->total_tool_calls);
        sb_append(&buf, tmp, strlen(tmp));
        const char *progress2 =
            "If you've been trying the same approach repeatedly without success, "
            "consider stepping back and trying a completely different strategy.\n";
        sb_append(&buf, progress2, strlen(progress2));
    }

    if (buf.data == NULL) return strdup("");

    return buf.data;
}

/* ===== Output helpers ===== */

static void emit_tool_call(AgentSession *session, const char *name, const char *input_json) {
    if (session->output.on_tool_call)
        session->output.on_tool_call(session->output.user_data, name, input_json);
}

static void emit_tool_result(AgentSession *session, const char *result, bool truncated) {
    if (session->output.on_tool_result)
        session->output.on_tool_result(session->output.user_data, result, truncated);
}

static void emit_text(AgentSession *session, const char *text, size_t len) {
    if (session->output.on_text)
        session->output.on_text(session->output.user_data, text, len);
}

static void emit_status(AgentSession *session, const char *status) {
    if (session->output.on_status)
        session->output.on_status(session->output.user_data, status);
}

/* ===== Agent Loop ===== */

static void execute_tools(AgentSession *session, cJSON *tool_calls) {
    cJSON *item;
    cJSON_ArrayForEach(item, tool_calls) {
        cJSON *id_obj   = cJSON_GetObjectItem(item, "id");
        cJSON *name_obj = cJSON_GetObjectItem(item, "name");
        cJSON *input    = cJSON_GetObjectItem(item, "input");

        if (!id_obj || !name_obj) continue;

        const char *id   = id_obj->valuestring ? id_obj->valuestring : "unknown";
        const char *name = name_obj->valuestring ? name_obj->valuestring : "unknown";

        {
            char *input_str = input ? cJSON_PrintUnformatted(input) : strdup("{}");
            emit_tool_call(session, name, input_str);
            free(input_str);
        }

        cJSON *exec_input = input ? input : cJSON_CreateObject();
        ToolResult result = tool_execute(session->reg, name, exec_input);
        if (!input) cJSON_Delete(exec_input);

        reflection_record_tool_result(&session->reflection, result.success, result.text);

        llm_append_tool_result(session->ctx, id, result.text);

        emit_tool_result(session, result.text, false);
        free(result.text);
    }
}

AgentResult agent_run_turn(AgentSession *session, const char *user_msg) {
    agent_session_reset(session);

    if (user_msg) {
        llm_append_user_message(session->ctx, user_msg);
    }

    session->iteration_count = 0;

    while (session->iteration_count < session->max_iterations) {
        if (atomic_load(&session->cancelled)) return AGENT_ERROR_CANCELLED;

        int seq = session->send_seq++;
        context_dump_md(session->ctx, session->ctx->system_prompt,
                        seq, session->reg->tool_ctx.workspace);

        LLMResponse resp;
        memset(&resp, 0, sizeof(resp));
        int rc;

        if (session_has_output(session)) {
            StreamAdapter adapter = { .output = &session->output };
            StreamCallbacks sc = {
                .user_data   = &adapter,
                .on_text     = adapter_on_text,
                .on_thinking = adapter_on_thinking,
                .on_complete = adapter_on_complete,
                .cancel_ptr  = &session->cancelled,
            };
            rc = llm_chat_ex(session->ctx, NULL, &resp, &sc);
        } else {
            rc = llm_chat(session->ctx, NULL, &resp);
        }

        {
            const char *req_json = llm_last_request_json();
            if (req_json) {
                context_dump_request_json(req_json, seq,
                                          session->reg->tool_ctx.workspace);
            }
        }

        if (atomic_load(&session->cancelled)) {
            if (resp.text && strlen(resp.text) > 0) {
                llm_append_assistant_text(session->ctx, resp.text);
            }
            llm_response_free(&resp);
            return AGENT_ERROR_CANCELLED;
        }

        if (rc != 0) {
            llm_response_free(&resp);
            return AGENT_ERROR_API;
        }

        if (!resp.is_tool_use) {
            if (resp.text) {
                llm_append_assistant_text(session->ctx, resp.text);
            }
            if (!session_has_output(session)) {
                emit_text(session, resp.text, resp.text ? strlen(resp.text) : 0);
            }
            llm_response_free(&resp);
            return AGENT_OK;
        }

        llm_append_assistant_tool_calls(session->ctx, resp.text, resp.tool_calls);

        {
            char status[128];
            snprintf(status, sizeof(status),
                     "Executing tools (iter %d/%d) | ESC:interrupt",
                     session->iteration_count + 1, session->max_iterations);
            emit_status(session, status);
        }

        execute_tools(session, resp.tool_calls);
        llm_response_free(&resp);

        session->iteration_count++;

        if (reflection_should_retry(&session->reflection)) {
            char *refl = reflection_build_prompt(&session->reflection);
            if (refl && refl[0]) {
                llm_append_user_message(session->ctx, refl);
                if (session->output.on_reflection)
                    session->output.on_reflection(session->output.user_data, refl);
            }
            free(refl);
            reflection_record_retry(&session->reflection);
        }

        if (session->plan.active && session->plan.step_count > 0) {
            if (session->plan.current_step < session->plan.step_count) {
                if (!session->reflection.last_tool_failed) {
                    agent_plan_update_step(&session->plan, session->plan.current_step,
                                          STEP_DONE, "completed");
                    if (session->plan.current_step + 1 < session->plan.step_count) {
                        agent_plan_update_step(&session->plan, session->plan.current_step + 1,
                                              STEP_IN_PROGRESS, NULL);
                    }
                } else {
                    agent_plan_update_step(&session->plan, session->plan.current_step,
                                          STEP_FAILED, session->reflection.last_error);
                }
            }
            if (session->output.on_plan_update)
                session->output.on_plan_update(session->output.user_data, &session->plan);
        }
    }

    return AGENT_ERROR_MAX_ITERATIONS;
}
