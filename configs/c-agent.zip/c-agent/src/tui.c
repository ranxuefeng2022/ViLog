#include "tui.h"
#include "termbox2.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// ===== Theme System (V7) =====

static const TUITheme THEMES[] = {
    {
        .bg = 0x0D1117, .status_bg = 0x161B22, .status_fg = 0xC9D1D9,
        .status_fg_dim = 0x6E7681, .input_border = 0x30363D,
        .input_prompt = 0x3FB950, .input_prompt_paste = 0xD29922,
        .input_prompt_busy = 0x6E7681, .scrollbar_track = 0x21262D,
        .scrollbar_thumb = 0x484F58, .line_number_fg = 0x484F58,
        .separator_fg = 0x21262D, .code_border = 0x30363D,
        .code_lang_fg = 0x8B949E, .code_bg = 0x161B22,
        .card_border = 0x30363D, .user_fg = 0x79C0FF,
        .user_label_fg = 0x58A6FF, .agent_fg = 0x7EE787,
        .agent_label_fg = 0x3FB950, .thinking_fg = 0x6E7681,
        .thinking_label_fg = 0x484F58, .tool_call_fg = 0xD2A8FF,
        .tool_result_fg = 0x7EE787, .error_fg = 0xFF7B72,
        .system_fg = 0xD2A8FF,
        .header_fg = 0x79C0FF, .quote_fg = 0x8B949E,
        .quote_bar_fg = 0x3FB950, .list_marker_fg = 0x3FB950,
        .inline_code_fg = 0xFF7B72, .inline_code_bg = 0x1C2128,
    },
    {
        .bg = 0x1A1A2E, .status_bg = 0x16213E, .status_fg = 0xE0E0E0,
        .status_fg_dim = 0x707090, .input_border = 0x0F3460,
        .input_prompt = 0x00D2FF, .input_prompt_paste = 0xFFB800,
        .input_prompt_busy = 0x505070, .scrollbar_track = 0x1A1A3E,
        .scrollbar_thumb = 0x3A3A6E, .line_number_fg = 0x3A3A5E,
        .separator_fg = 0x2A2A4E, .code_border = 0x0F3460,
        .code_lang_fg = 0x8080B0, .code_bg = 0x12122A,
        .card_border = 0x0F3460, .user_fg = 0x00D2FF,
        .user_label_fg = 0x00AAFF, .agent_fg = 0x50FA7B,
        .agent_label_fg = 0x00FF88, .thinking_fg = 0x505080,
        .thinking_label_fg = 0x3A3A60, .tool_call_fg = 0xFFB86C,
        .tool_result_fg = 0x50FA7B, .error_fg = 0xFF5555,
        .system_fg = 0xFF79C6,
        .header_fg = 0x00D2FF, .quote_fg = 0x8080B0,
        .quote_bar_fg = 0x50FA7B, .list_marker_fg = 0x50FA7B,
        .inline_code_fg = 0xFFB86C, .inline_code_bg = 0x1A1A3E,
    },
    {
        .bg = 0x282C34, .status_bg = 0x2C313A, .status_fg = 0xABB2BF,
        .status_fg_dim = 0x5C6370, .input_border = 0x3E4451,
        .input_prompt = 0x98C379, .input_prompt_paste = 0xE5C07B,
        .input_prompt_busy = 0x5C6370, .scrollbar_track = 0x2C313A,
        .scrollbar_thumb = 0x5C6370, .line_number_fg = 0x4B5263,
        .separator_fg = 0x3E4451, .code_border = 0x3E4451,
        .code_lang_fg = 0x7F848E, .code_bg = 0x21252B,
        .card_border = 0x3E4451, .user_fg = 0x61AFEF,
        .user_label_fg = 0x61AFEF, .agent_fg = 0x98C379,
        .agent_label_fg = 0x98C379, .thinking_fg = 0x5C6370,
        .thinking_label_fg = 0x4B5263, .tool_call_fg = 0xC678DD,
        .tool_result_fg = 0x98C379, .error_fg = 0xE06C75,
        .system_fg = 0xC678DD,
        .header_fg = 0x61AFEF, .quote_fg = 0x7F848E,
        .quote_bar_fg = 0x98C379, .list_marker_fg = 0x98C379,
        .inline_code_fg = 0xE06C75, .inline_code_bg = 0x2C313A,
    },
    {
        .bg = 0xF8F8F2, .status_bg = 0xEEEEF0, .status_fg = 0x282A36,
        .status_fg_dim = 0x9090A0, .input_border = 0xCCCCD0,
        .input_prompt = 0x50FA7B, .input_prompt_paste = 0xFFB86C,
        .input_prompt_busy = 0x9090A0, .scrollbar_track = 0xDDDDDF,
        .scrollbar_thumb = 0xAAAAAF, .line_number_fg = 0xBBBBBF,
        .separator_fg = 0xCCCCD0, .code_border = 0xCCCCD0,
        .code_lang_fg = 0x6272A4, .code_bg = 0xEEEEF2,
        .card_border = 0xCCCCD0, .user_fg = 0x0060B0,
        .user_label_fg = 0x0050A0, .agent_fg = 0x008040,
        .agent_label_fg = 0x007030, .thinking_fg = 0x9090A0,
        .thinking_label_fg = 0xA0A0B0, .tool_call_fg = 0x800080,
        .tool_result_fg = 0x008040, .error_fg = 0xCC0000,
        .system_fg = 0x800080,
        .header_fg = 0x0050A0, .quote_fg = 0x6272A4,
        .quote_bar_fg = 0x008040, .list_marker_fg = 0x008040,
        .inline_code_fg = 0xC00000, .inline_code_bg = 0xEEEEF2,
    },
};
#define THEME_COUNT (sizeof(THEMES) / sizeof(THEMES[0]))

static const char *THEME_NAMES[] = {
    "GitHub Dark", "Cyberpunk", "One Dark", "Light"
};

// ===== Constants =====

static const uint32_t SPINNER_FRAMES[] = {
    0x280B, 0x2819, 0x2839, 0x2838,
    0x283C, 0x2834, 0x2826, 0x2827
};
#define SPINNER_COUNT 8

// ===== UTF-8 helpers =====

static int utf8_char_len(const char *s) {
    unsigned char c = (unsigned char)*s;
    if (c < 0x80) return 1;
    if ((c & 0xE0) == 0xC0) return 2;
    if ((c & 0xF0) == 0xE0) return 3;
    if ((c & 0xF8) == 0xF0) return 4;
    return 1;
}

static uint32_t utf8_decode(const char *s, int *out_len) {
    unsigned char c = (unsigned char)*s;
    uint32_t cp;
    int len;
    if (c < 0x80) { cp = c; len = 1; }
    else if ((c & 0xE0) == 0xC0) { cp = c & 0x1F; len = 2; }
    else if ((c & 0xF0) == 0xE0) { cp = c & 0x0F; len = 3; }
    else if ((c & 0xF8) == 0xF0) { cp = c & 0x07; len = 4; }
    else { cp = c; len = 1; }
    for (int i = 1; i < len; i++) {
        cp = (cp << 6) | ((unsigned char)s[i] & 0x3F);
    }
    if (out_len) *out_len = len;
    return cp;
}

static int utf8_encode(uint32_t cp, char *out) {
    if (cp < 0x80) {
        out[0] = (char)cp; return 1;
    } else if (cp < 0x800) {
        out[0] = (char)(0xC0 | (cp >> 6));
        out[1] = (char)(0x80 | (cp & 0x3F)); return 2;
    } else if (cp < 0x10000) {
        out[0] = (char)(0xE0 | (cp >> 12));
        out[1] = (char)(0x80 | ((cp >> 6) & 0x3F));
        out[2] = (char)(0x80 | (cp & 0x3F)); return 3;
    } else if (cp < 0x110000) {
        out[0] = (char)(0xF0 | (cp >> 18));
        out[1] = (char)(0x80 | ((cp >> 12) & 0x3F));
        out[2] = (char)(0x80 | ((cp >> 6) & 0x3F));
        out[3] = (char)(0x80 | (cp & 0x3F)); return 4;
    }
    return 0;
}

static int char_width(uint32_t cp) {
    if (cp < 0x20) return 0;
    if (cp < 0x7F) return 1;
    if (cp >= 0x1100 && cp <= 0x115F) return 2;
    if (cp >= 0x2329 && cp <= 0x232A) return 2;
    if (cp >= 0x2E80 && cp <= 0x303E) return 2;
    if (cp >= 0x3040 && cp <= 0x3247) return 2;
    if (cp >= 0x3250 && cp <= 0x4DBF) return 2;
    if (cp >= 0x4E00 && cp <= 0x9FFF) return 2;
    if (cp >= 0xA960 && cp <= 0xA97C) return 2;
    if (cp >= 0xAC00 && cp <= 0xD7A3) return 2;
    if (cp >= 0xF900 && cp <= 0xFAFF) return 2;
    if (cp >= 0xFE10 && cp <= 0xFE6B) return 2;
    if (cp >= 0xFF01 && cp <= 0xFF60) return 2;
    if (cp >= 0xFFE0 && cp <= 0xFFE6) return 2;
    if (cp >= 0x20000 && cp <= 0x2FFFD) return 2;
    if (cp >= 0x30000 && cp <= 0x3FFFD) return 2;
    return 1;
}

static int input_col_at_byte(const char *buf, int byte_pos) {
    int col = 0, i = 0;
    while (i < byte_pos) {
        int clen = utf8_char_len(buf + i);
        uint32_t cp = utf8_decode(buf + i, NULL);
        col += char_width(cp);
        i += clen;
    }
    return col;
}

static int input_byte_at_col(const char *buf, int buf_len, int col) {
    int c = 0, i = 0;
    while (i < buf_len) {
        int clen = utf8_char_len(buf + i);
        if (i + clen > buf_len) break;
        uint32_t cp = utf8_decode(buf + i, NULL);
        int cw = char_width(cp);
        if (c + cw > col) return i;
        c += cw;
        i += clen;
    }
    return i;
}

static int input_line_count(InputLine *inp) {
    int n = 1;
    for (int i = 0; i < inp->len; i++)
        if (inp->buf[i] == '\n') n++;
    return n;
}

static void input_get_line(InputLine *inp, int line_idx, int *start, int *end) {
    int cur = 0;
    *start = 0;
    for (int i = 0; i < inp->len; i++) {
        if (inp->buf[i] == '\n') {
            if (cur == line_idx) { *end = i; return; }
            cur++;
            *start = i + 1;
        }
    }
    if (cur == line_idx) { *end = inp->len; return; }
    *start = *end = inp->len;
}

static int input_cursor_line(InputLine *inp) {
    int line = 0;
    for (int i = 0; i < inp->cursor; i++)
        if (inp->buf[i] == '\n') line++;
    return line;
}

// ===== Theme-aware color mapping =====

static uintattr_t tag_to_fg(const TUITheme *theme, OutputTag tag) {
    switch (tag) {
        case TAG_USER:       return theme->user_fg;
        case TAG_AGENT:      return theme->agent_fg;
        case TAG_THINKING:   return theme->thinking_fg;
        case TAG_TOOL_CALL:  return theme->tool_call_fg;
        case TAG_TOOL_RESULT:return theme->tool_result_fg;
        case TAG_ERROR:      return theme->error_fg;
        case TAG_SYSTEM:     return theme->system_fg;
        case TAG_SEPARATOR:  return theme->separator_fg;
        default:             return theme->status_fg;
    }
}

static uintattr_t tag_to_label_fg(const TUITheme *theme, OutputTag tag) {
    switch (tag) {
        case TAG_USER:       return theme->user_label_fg;
        case TAG_AGENT:      return theme->agent_label_fg;
        case TAG_THINKING:   return theme->thinking_label_fg;
        case TAG_TOOL_CALL:  return theme->tool_call_fg;
        case TAG_TOOL_RESULT:return theme->tool_result_fg;
        case TAG_ERROR:      return theme->error_fg;
        case TAG_SYSTEM:     return theme->system_fg;
        default:             return theme->status_fg;
    }
}

// ===== Line storage =====

static void ensure_line_cap(TUIState *tui) {
    if (tui->line_count >= tui->line_cap) {
        tui->line_cap = tui->line_cap ? tui->line_cap * 2 : 256;
        tui->lines = realloc(tui->lines, tui->line_cap * sizeof(DisplayLine));
    }
}

/* Detect line-level markdown and return type. Advances *seg and *seg_len past prefix. */
static uint8_t detect_md_line(const char **seg, int *seg_len)
{
    const char *p = *seg;
    int len = *seg_len;
    if (len <= 0) return MD_NONE;

    /* Horizontal rule: --- or *** or ___ (3+ same char) */
    if (len >= 3 && (p[0] == '-' || p[0] == '*' || p[0] == '_')) {
        char c = p[0];
        bool all_same = true;
        for (int i = 1; i < len; i++) {
            if (p[i] != c) { all_same = false; break; }
        }
        if (all_same && len >= 3) {
            *seg_len = 0;
            return MD_HRULE;
        }
    }

    /* Headers: # ... #### */
    if (p[0] == '#') {
        int level = 0;
        while (level < 4 && level < len && p[level] == '#') level++;
        if (level < len && p[level] == ' ') {
            *seg = p + level + 1;
            *seg_len = len - level - 1;
            return (uint8_t)(MD_H1 + level - 1);
        }
    }

    /* Blockquote */
    if (p[0] == '>' && len > 1 && p[1] == ' ') {
        *seg = p + 2;
        *seg_len = len - 2;
        return MD_QUOTE;
    }

    /* Table: starts with | */
    if (p[0] == '|') {
        bool is_sep = true;
        for (int i = 1; i < len; i++) {
            if (p[i] != '-' && p[i] != '|' && p[i] != ' ' && p[i] != ':') {
                is_sep = false;
                break;
            }
        }
        if (is_sep) {
            /* Keep full text so renderer can find | positions for borders */
            return MD_TABLE_SEP;
        }
        return MD_TABLE;
    }

    /* Task list: - [ ] or - [x] */
    if (p[0] == '-' && len > 5 && p[1] == ' ' && p[2] == '['
        && p[4] == ']' && p[5] == ' ') {
        *seg = p + 6;
        *seg_len = len - 6;
        return (p[3] == 'x' || p[3] == 'X') ? MD_TASK_DONE : MD_TASK_OPEN;
    }

    /* Unordered list: - or * at line start */
    if ((p[0] == '-' || p[0] == '*') && len > 1 && p[1] == ' ') {
        *seg = p + 2;
        *seg_len = len - 2;
        return MD_LIST;
    }

    /* Ordered list: 1. 2. etc - keep full prefix for number rendering */
    if (len > 2 && p[0] >= '0' && p[0] <= '9') {
        int dot = 1;
        while (dot < len && p[dot] >= '0' && p[dot] <= '9') dot++;
        if (dot < len && p[dot] == '.' && dot + 1 < len && p[dot + 1] == ' ') {
            *seg = p;
            *seg_len = len;
            return MD_LIST_ORD;
        }
    }
    return MD_NONE;
}

static int detect_label_end(const char *text, int len) {
    if (len < 4 || text[0] != '[') return 0;
    for (int i = 1; i < len; i++) {
        if (text[i] == ']') {
            if (i + 1 < len && text[i + 1] == ' ') return i + 2;
            return 0;
        }
        if (text[i] == '\0' || text[i] == '\n') return 0;
    }
    return 0;
}

static bool is_table_type(uint8_t md_line) {
    return md_line == MD_TABLE || md_line == MD_TABLE_SEP;
}

static void add_line_ex(TUIState *tui, OutputTag tag, const char *text, int len,
                        bool code_block, int first_line_label, uint8_t md_line) {
    /* Inject table top border when entering a table */
    if (is_table_type(md_line)) {
        if (tui->line_count == 0 || !is_table_type(tui->lines[tui->line_count - 1].md_line)) {
            ensure_line_cap(tui);
            DisplayLine *border = &tui->lines[tui->line_count];
            border->tag = tag;
            border->text = strndup(text, len);
            border->in_code_block = false;
            border->hidden = false;
            border->collapse_group = 0;
            border->label_end = 0;
            border->md_line = MD_TABLE_TOP;
            tui->line_count++;
        }
    } else {
        /* Inject table bottom border when leaving a table */
        if (tui->line_count > 0 && is_table_type(tui->lines[tui->line_count - 1].md_line)) {
            /* Find the last MD_TABLE row (not sep) for pipe positions */
            const char *bot_text = "";
            int bot_len = 0;
            for (int k = tui->line_count - 1; k >= 0; k--) {
                if (tui->lines[k].md_line == MD_TABLE) {
                    bot_text = tui->lines[k].text;
                    bot_len = strlen(bot_text);
                    break;
                }
            }
            ensure_line_cap(tui);
            DisplayLine *border = &tui->lines[tui->line_count];
            border->tag = tui->lines[tui->line_count - 1].tag;
            border->text = strndup(bot_text, bot_len);
            border->in_code_block = false;
            border->hidden = false;
            border->collapse_group = 0;
            border->label_end = 0;
            border->md_line = MD_TABLE_BOT;
            tui->line_count++;
        }
    }

    ensure_line_cap(tui);
    DisplayLine *dl = &tui->lines[tui->line_count];
    dl->tag = tag;
    dl->text = strndup(text, len);
    dl->in_code_block = code_block;
    dl->hidden = false;
    dl->collapse_group = 0;
    dl->label_end = first_line_label ? detect_label_end(text, len) : 0;
    dl->md_line = md_line;
    tui->line_count++;
}

// ===== Accumulator =====

void tui_init(TUIState *tui, RingBuffer *ring) {
    memset(tui, 0, sizeof(*tui));
    tui->ring = ring;
    tui->line_cap = 256;
    tui->lines = calloc(tui->line_cap, sizeof(DisplayLine));
    tui->input.cap = 256;
    tui->input.buf = calloc(tui->input.cap, 1);
    tui->width = 80;
    tui->height = 24;
    tui->acc_cap = 4096;
    tui->acc_buf = calloc(tui->acc_cap, 1);
    tui->acc_tag = (OutputTag)-1;
    tui->history_index = -1;
    tui->state_text[0] = '\0';
    tui->model_name[0] = '\0';
}

void tui_shutdown(TUIState *tui) {
    for (int i = 0; i < tui->line_count; i++)
        free(tui->lines[i].text);
    free(tui->lines);
    free(tui->input.buf);
    free(tui->acc_buf);
    for (int i = 0; i < tui->history_count; i++)
        free(tui->history[i]);
}

void tui_clear_output(TUIState *tui) {
    for (int i = 0; i < tui->line_count; i++)
        free(tui->lines[i].text);
    tui->line_count = 0;
    tui->scroll_off = 0;
    tui->acc_len = 0;
    tui->acc_tag = (OutputTag)-1;
}

static void acc_ensure_cap(TUIState *tui, int needed) {
    if (tui->acc_len + needed + 1 >= tui->acc_cap) {
        tui->acc_cap = (tui->acc_len + needed + 1) * 2;
        tui->acc_buf = realloc(tui->acc_buf, tui->acc_cap);
    }
}

static void acc_flush(TUIState *tui) {
    if (tui->acc_len == 0) return;

    if (tui->acc_tag == TAG_SEPARATOR) {
        add_line_ex(tui, TAG_SEPARATOR, "", 0, false, 0, MD_NONE);
        tui->acc_len = 0;
        tui->acc_buf[0] = '\0';
        return;
    }

    /* Compute the actual text rendering width to match tui_render's layout.
       tui_render uses: scrollbar_col - line_num_width - 1 - indent
       We approximate scrollbar_col = width-1 (scrollbar is typical for long output),
       line_num_width = 4. This gives text_w = width - 1 - 4 - 1 = width - 6. */
    int full_w = tui->width > 0 ? tui->width : 80;
    int line_num_w = 4;
    int sb_margin = 1; /* scrollbar column */
    int base_text_w = full_w - sb_margin - line_num_w - 1;
    if (base_text_w < 10) { base_text_w = 10; line_num_w = 0; }

    const char *start = tui->acc_buf;
    const char *end = tui->acc_buf + tui->acc_len;
    const char *p = start;
    bool first_segment = true;

    while (p < end) {
        const char *nl = memchr(p, '\n', end - p);
        int seg_len = nl ? (int)(nl - p) : (int)(end - p);

        if (seg_len > 0) {
            if (seg_len >= 3 && (strncmp(p, "```", 3) == 0)) {
                tui->acc_in_code_block = !tui->acc_in_code_block;
                first_segment = false;
                if (nl) { p = nl + 1; } else { break; }
                continue;
            }

            /* Detect line-level markdown (skip inside code blocks) */
            uint8_t md_line = MD_NONE;
            const char *seg = p;
            int sLen = seg_len;
            if (!tui->acc_in_code_block) {
                md_line = detect_md_line(&seg, &sLen);
                seg_len = sLen;
            }

            int indent = tui->acc_in_code_block ? 2 : 0;
            int wrap_w = base_text_w - indent;
            if (wrap_w < 10) wrap_w = 10;

            int col = 0;
            const char *ws = seg;
            int i = 0;
            bool first_wrap = true;
            while (i < seg_len) {
                int clen = utf8_char_len(seg + i);
                if (i + clen > seg_len) break;
                uint32_t cp = utf8_decode(seg + i, NULL);
                int cw = char_width(cp);
                if (col + cw > wrap_w && col > 0) {
                    add_line_ex(tui, tui->acc_tag, ws, (seg + i) - ws,
                                tui->acc_in_code_block,
                                first_segment && first_wrap ? 1 : 0, md_line);
                    ws = seg + i;
                    col = 0;
                    first_wrap = false;
                }
                col += cw;
                i += clen;
            }
            if (i > (ws - seg)) {
                add_line_ex(tui, tui->acc_tag, ws, (seg + i) - ws,
                            tui->acc_in_code_block,
                            first_segment && first_wrap ? 1 : 0, md_line);
            }
            first_segment = false;
        }
        if (nl) { p = nl + 1; } else { break; }
    }
    tui->acc_len = 0;
    tui->acc_buf[0] = '\0';
}

static void acc_append(TUIState *tui, OutputTag tag, const char *text, size_t len) {
    if (tui->acc_len > 0 && tui->acc_tag != tag) {
        acc_flush(tui);
    }
    tui->acc_tag = tag;
    acc_ensure_cap(tui, (int)len);
    memcpy(tui->acc_buf + tui->acc_len, text, len);
    tui->acc_len += len;
    tui->acc_buf[tui->acc_len] = '\0';

    char *last_nl = NULL;
    for (char *p = tui->acc_buf; p < tui->acc_buf + tui->acc_len; p++)
        if (*p == '\n') last_nl = p;
    if (last_nl) {
        int flush_len = (int)(last_nl - tui->acc_buf) + 1;
        char *tmp = strndup(tui->acc_buf, flush_len);
        int old_len = tui->acc_len;
        tui->acc_len = flush_len;
        memcpy(tui->acc_buf, tmp, flush_len);
        tui->acc_buf[flush_len] = '\0';
        acc_flush(tui);
        free(tmp);
        int remaining = old_len - flush_len;
        if (remaining > 0)
            memmove(tui->acc_buf, tui->acc_buf + flush_len, remaining);
        tui->acc_len = remaining;
        tui->acc_buf[tui->acc_len] = '\0';
    }
}

void tui_push_line(TUIState *tui, OutputTag tag, const char *text) {
    acc_append(tui, tag, text, strlen(text));
}

static void rb_drain_callback(OutputTag tag, const char *text, size_t len, void *ctx) {
    TUIState *tui = (TUIState *)ctx;

    if (tag == TAG_STATUS) {
        tui_set_state_text(tui, "%.*s", (int)len, text);
        return;
    }

    if (tag == TAG_AGENT && tui->needs_agent_label) {
        acc_append(tui, tag, "\xF0\x9F\xA4\x96 ", 5);
        tui->needs_agent_label = false;
    }
    acc_append(tui, tag, text, len);
}

void tui_consume_output(TUIState *tui) {
    int before = tui->line_count;
    rb_drain(tui->ring, rb_drain_callback, tui);
    int new_lines = tui->line_count - before;
    if (tui->scroll_off > 0 && new_lines > 0) {
        tui->scroll_off += new_lines;
        tui_clamp_scroll(tui);
    }
}

void tui_flush(TUIState *tui) {
    acc_flush(tui);
    /* Close any open table at the end of output */
    if (tui->line_count > 0) {
        uint8_t last_md = tui->lines[tui->line_count - 1].md_line;
        if (last_md == MD_TABLE || last_md == MD_TABLE_SEP) {
            const char *bot_text = "";
            int bot_len = 0;
            for (int k = tui->line_count - 1; k >= 0; k--) {
                if (tui->lines[k].md_line == MD_TABLE) {
                    bot_text = tui->lines[k].text;
                    bot_len = strlen(bot_text);
                    break;
                }
            }
            ensure_line_cap(tui);
            DisplayLine *border = &tui->lines[tui->line_count];
            border->tag = tui->lines[tui->line_count - 1].tag;
            border->text = strndup(bot_text, bot_len);
            border->in_code_block = false;
            border->hidden = false;
            border->collapse_group = 0;
            border->label_end = 0;
            border->md_line = MD_TABLE_BOT;
            tui->line_count++;
        }
    }
}

// ===== Rendering helpers =====

int render_text(int x, int y, const char *text, int tlen, uintattr_t fg, uintattr_t bg, int bold_end) {
    int max_x = tb_width();
    int i = 0;
    while (i < tlen && x < max_x) {
        int clen = utf8_char_len(text + i);
        if (i + clen > tlen) break;
        uint32_t cp = utf8_decode(text + i, NULL);
        int cw = char_width(cp);
        if (x + cw > max_x) break;
        uintattr_t attr = (i < bold_end) ? (fg | TB_BOLD) : fg;
        for (int j = 0; j < cw; j++) {
            tb_set_cell(x, y, j == 0 ? cp : 0, attr, bg);
            x++;
        }
        i += clen;
    }
    return x;
}

static int text_display_width(const char *text, int len) {
    int w = 0;
    for (int i = 0; i < len; ) {
        int clen = utf8_char_len(text + i);
        if (i + clen > len) break;
        w += char_width(utf8_decode(text + i, NULL));
        i += clen;
    }
    return w;
}

// ===== V1+V10: Status bar with 3-section layout + themed colors =====

static void tui_render_statusbar(TUIState *tui, const TUITheme *theme, int status_row, int w) {
    for (int x = 0; x < w; x++)
        tb_set_cell(x, status_row, ' ', theme->status_fg, theme->status_bg);

    int sx = 1;

    if (tui->agent_busy) {
        int cw = char_width(SPINNER_FRAMES[tui->spinner_frame]);
        for (int j = 0; j < cw && sx < w; j++)
            tb_set_cell(sx++, status_row, j == 0 ? SPINNER_FRAMES[tui->spinner_frame] : 0,
                        0xFFFFFF, theme->status_bg);
        tb_set_cell(sx++, status_row, ' ', theme->status_fg, theme->status_bg);
    }

    sx = render_text(sx, status_row, tui->state_text, strlen(tui->state_text),
                     theme->status_fg, theme->status_bg, 0);

    char center[64];
    int clen = 0;
    if (tui->turn_number > 0 && tui->response_start_ms > 0) {
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        long long elapsed = (long long)ts.tv_sec * 1000 + ts.tv_nsec / 1000000 - tui->response_start_ms;
        clen = snprintf(center, sizeof(center), "%.1fs", elapsed / 1000.0);
    } else if (tui->turn_number > 0) {
        clen = snprintf(center, sizeof(center), "Turn %d", tui->turn_number);
    }
    if (clen > 0) {
        int cw = text_display_width(center, clen);
        int cx = (w - cw) / 2;
        if (cx > sx + 2) {
            render_text(cx, status_row, center, clen, theme->status_fg_dim, theme->status_bg, 0);
        }
    }

    char right[128];
    int rlen = 0;
    if (tui->model_name[0]) {
        rlen = snprintf(right, sizeof(right), "[%s]", tui->model_name);
    }
    rlen += snprintf(right + rlen, sizeof(right) - rlen, " %s",
                     THEME_NAMES[tui->theme_index % THEME_COUNT]);
    int right_w = text_display_width(right, rlen);
    int rx = w - right_w - 1;
    if (rx < sx + 2) rx = sx + 2;
    render_text(rx, status_row, right, rlen, theme->status_fg_dim, theme->status_bg, 0);
}

// ===== V2: Input area with rounded border =====

static void tui_render_input_border(TUIState *tui, const TUITheme *theme,
                                     int input_row_start, int input_rows, int w) {
    if (input_rows <= 0 || w < 4) return;

    tb_set_cell(0, input_row_start, 0x256D, theme->input_border, theme->bg);
    for (int x = 1; x < w - 1; x++)
        tb_set_cell(x, input_row_start, 0x2500, theme->input_border, theme->bg);
    tb_set_cell(w - 1, input_row_start, 0x256E, theme->input_border, theme->bg);

    for (int ln = 0; ln < input_rows; ln++) {
        int row = input_row_start + 1 + ln;
        if (row >= tui->height - 1) break;
        tb_set_cell(0, row, 0x2502, theme->input_border, theme->bg);
        tb_set_cell(w - 1, row, 0x2502, theme->input_border, theme->bg);
    }

    int bottom_row = input_row_start + 1 + input_rows;
    if (bottom_row < tui->height) {
        tb_set_cell(0, bottom_row, 0x2570, theme->input_border, theme->bg);
        for (int x = 1; x < w - 1; x++)
            tb_set_cell(x, bottom_row, 0x2500, theme->input_border, theme->bg);
        tb_set_cell(w - 1, bottom_row, 0x256F, theme->input_border, theme->bg);
    }
}

// ===== V4: Code block language label detection =====

static const char *detect_code_lang(const char *text, int len) {
    if (len < 1 || text[0] != '`') return NULL;
    int backtick_count = 0;
    int i = 0;
    while (i < len && text[i] == '`') { backtick_count++; i++; }
    if (backtick_count < 3) return NULL;
    int lang_start = i;
    while (i < len && text[i] != '`' && text[i] != '\n' && text[i] != ' ') i++;
    if (i == lang_start) return NULL;
    static char lang_buf[32];
    int lang_len = i - lang_start;
    if (lang_len >= (int)sizeof(lang_buf)) lang_len = (int)sizeof(lang_buf) - 1;
    memcpy(lang_buf, text + lang_start, lang_len);
    lang_buf[lang_len] = '\0';
    return lang_buf;
}

// ===== V9: Tool call card rendering =====

static bool is_tool_card_tag(OutputTag tag) {
    return tag == TAG_TOOL_CALL || tag == TAG_TOOL_RESULT;
}

// ===== Main render =====

void tui_render(TUIState *tui) {
    const TUITheme *theme = &THEMES[tui->theme_index % THEME_COUNT];
    int w = tui->width;
    int h = tui->height;
    if (w <= 0 || h <= 5) return;

    int total_input_lines = input_line_count(&tui->input);
    int max_input_rows = (h - 4) / 2;
    if (max_input_rows < 1) max_input_rows = 1;
    int input_rows = total_input_lines;
    if (input_rows > max_input_rows) input_rows = max_input_rows;
    int border_rows = 2;
    int input_area_rows = border_rows + input_rows;
    int output_rows = h - 2 - input_area_rows;
    if (output_rows < 3) { output_rows = 3; input_rows = h - 7; if (input_rows < 1) input_rows = 1; }
    int input_row_start = output_rows + 1;

    int cur_input_line = input_cursor_line(&tui->input);
    int input_vscroll = 0;
    if (cur_input_line >= input_rows) {
        input_vscroll = cur_input_line - input_rows + 1;
    }

    int total = tui->line_count;

    int *visible = NULL;
    int visible_count = 0;
    if (total > 0) {
        visible = malloc(total * sizeof(int));
        if (!visible) return;
        for (int i = 0; i < total; i++) {
            if (!tui->lines[i].hidden)
                visible[visible_count++] = i;
        }
    }

    int visible_start;
    if (tui->scroll_off == 0) {
        visible_start = visible_count - output_rows;
        if (visible_start < 0) visible_start = 0;
    } else {
        visible_start = visible_count - output_rows - tui->scroll_off;
        if (visible_start < 0) visible_start = 0;
    }

    bool need_scrollbar = visible_count > output_rows;
    int line_num_width = 4;
    int scrollbar_col = need_scrollbar ? w - 1 : w;
    int text_w = scrollbar_col - line_num_width - 1;
    if (text_w < 10) { text_w = 10; line_num_width = w - scrollbar_col - 12; if (line_num_width < 0) line_num_width = 0; }

    bool show_acc = (tui->acc_len > 0 && (int)tui->acc_tag >= 0
                    && tui->scroll_off == 0);

    for (int row = 0; row < output_rows; row++) {
        for (int x = 0; x < w; x++)
            tb_set_cell(x, row, ' ', theme->status_fg, theme->bg);

        int vidx = visible_start + row;
        if (vidx >= 0 && vidx < visible_count) {
            int idx = visible[vidx];
            DisplayLine *dl = &tui->lines[idx];

            // V8: Line numbers
            if (line_num_width > 0) {
                char lnum[16];
                int lnum_len = snprintf(lnum, sizeof(lnum), "%*d", line_num_width, vidx + 1);
                render_text(0, row, lnum, lnum_len > line_num_width ? line_num_width : lnum_len,
                           theme->line_number_fg, theme->bg, 0);
                tb_set_cell(line_num_width, row, 0x2502, theme->line_number_fg, theme->bg);
            }

            if (dl->tag == TAG_SEPARATOR) {
                for (int x = line_num_width + 1; x < scrollbar_col; x++)
                    tb_set_cell(x, row, 0x2500, theme->separator_fg, theme->bg);
                continue;
            }

            uintattr_t fg = tag_to_fg(theme, dl->tag);
            uintattr_t label_fg = tag_to_label_fg(theme, dl->tag);
            uintattr_t line_bg = theme->bg;
            int indent = 0;

            // V4: Code block styling
            if (dl->in_code_block) {
                indent = 2;
                line_bg = theme->code_bg;
                tb_set_cell(line_num_width + 1, row, 0x2502, theme->code_border, line_bg);
                tb_set_cell(line_num_width + 2, row, ' ', theme->code_border, line_bg);
                for (int x = line_num_width + 3; x < scrollbar_col; x++)
                    tb_set_cell(x, row, ' ', fg, line_bg);
            }

            // V5: Thinking dim style
            if (dl->tag == TAG_THINKING) {
                fg = theme->thinking_fg;
            }

            // V9: Tool card border
            if (is_tool_card_tag(dl->tag)) {
                int card_x = line_num_width + 1;
                tb_set_cell(card_x, row, 0x2502, theme->card_border, line_bg);
                indent = 2;
            }

            int tlen = strlen(dl->text);
            int bold_end = dl->label_end;
            int x = line_num_width + 1 + indent;
            int i = 0;

            /* Line-level markdown styling */
            uintattr_t line_fg = fg;
            bool line_handled = false; /* true if md_line rendered the full row */
            if (!dl->in_code_block) {
                switch (dl->md_line) {
                case MD_H1: case MD_H2:
                    line_fg = theme->header_fg | TB_BOLD;
                    break;
                case MD_H3:
                    line_fg = theme->header_fg;
                    break;
                case MD_H4:
                    line_fg = theme->header_fg | TB_DIM;
                    break;
                case MD_QUOTE:
                    line_fg = theme->quote_fg;
                    tb_set_cell(line_num_width + 1 + indent, row, 0x2502,
                                theme->quote_bar_fg, line_bg);
                    indent += 2;
                    x += 2;
                    break;
                case MD_LIST:
                    tb_set_cell(x, row, 0x2022,
                                theme->list_marker_fg | TB_BOLD, line_bg);
                    x += 2;
                    break;
                case MD_LIST_ORD: {
                    /* Render number prefix from text (e.g. "1. ") */
                    int pi = 0;
                    while (pi < tlen && dl->text[pi] != ' ') {
                        int pclen = utf8_char_len(dl->text + pi);
                        if (pi + pclen > tlen) break;
                        uint32_t pcp = utf8_decode(dl->text + pi, NULL);
                        int pcw = char_width(pcp);
                        if (x + pcw > scrollbar_col) break;
                        tb_set_cell(x, row, pcp,
                                    theme->list_marker_fg | TB_BOLD, line_bg);
                        x += pcw;
                        pi += pclen;
                    }
                    /* Skip "1. " prefix, advance to content */
                    int skip = pi + 1; /* skip space after dot */
                    i = skip < tlen ? skip : tlen;
                    break;
                }
                case MD_TABLE: {
                    /* Parse cells between | delimiters */
                    int cx = line_num_width + 1;
                    int ti = 0;
                    if (ti < tlen && dl->text[ti] == '|') ti++;
                    while (ti < tlen && cx < scrollbar_col) {
                        tb_set_cell(cx, row, 0x2502, theme->card_border, line_bg);
                        cx++;
                        if (cx >= scrollbar_col) break;
                        /* space after border */
                        tb_set_cell(cx, row, ' ', theme->header_fg, line_bg);
                        cx++;
                        /* find end of cell */
                        int cell_start = ti;
                        while (ti < tlen && dl->text[ti] != '|') ti++;
                        int cell_len = ti - cell_start;
                        /* trim leading spaces */
                        int cs = cell_start;
                        while (cs < cell_start + cell_len && dl->text[cs] == ' ') cs++;
                        /* render cell content */
                        int ci = cs;
                        while (ci < cell_start + cell_len && cx < scrollbar_col) {
                            int cclen = utf8_char_len(dl->text + ci);
                            if (ci + cclen > cell_start + cell_len) break;
                            uint32_t ccp = utf8_decode(dl->text + ci, NULL);
                            int ccw = char_width(ccp);
                            if (cx + ccw > scrollbar_col) break;
                            tb_set_cell(cx, row, ccp, theme->header_fg, line_bg);
                            cx += ccw;
                            ci += cclen;
                        }
                        /* space before next border */
                        if (cx < scrollbar_col) {
                            tb_set_cell(cx, row, ' ', theme->header_fg, line_bg);
                            cx++;
                        }
                        if (ti < tlen && dl->text[ti] == '|') ti++;
                    }
                    if (cx < scrollbar_col)
                        tb_set_cell(cx, row, 0x2502, theme->card_border, line_bg);
                    /* Fill remaining row after table */
                    for (int fx = cx + 1; fx < scrollbar_col; fx++)
                        tb_set_cell(fx, row, ' ', fg, line_bg);
                    i = tlen;
                    line_handled = true;
                    break;
                }
                case MD_TABLE_TOP:
                case MD_TABLE_SEP:
                case MD_TABLE_BOT: {
                    /* Render horizontal border: ┌─┬─┐ / ├─┼─┤ / └─┴─┘ */
                    uint32_t left_ch, mid_ch, right_ch;
                    if (dl->md_line == MD_TABLE_TOP) {
                        left_ch = 0x250C;  /* ┌ */
                        mid_ch = 0x252C;   /* ┬ */
                        right_ch = 0x2510; /* ┐ */
                    } else if (dl->md_line == MD_TABLE_BOT) {
                        left_ch = 0x2514;  /* └ */
                        mid_ch = 0x2534;   /* ┴ */
                        right_ch = 0x2518; /* ┘ */
                    } else {
                        left_ch = 0x251C;  /* ├ */
                        mid_ch = 0x253C;   /* ┼ */
                        right_ch = 0x2524; /* ┤ */
                    }
                    int cx = line_num_width + 1;
                    /* Find pipe positions from text to determine cell boundaries */
                    int ti = 0;
                    if (ti < tlen && dl->text[ti] == '|') ti++;
                    /* Left corner */
                    tb_set_cell(cx, row, left_ch, theme->card_border, line_bg);
                    cx++;
                    while (ti < tlen && cx < scrollbar_col) {
                        /* Find next pipe */
                        int next_pipe = ti;
                        while (next_pipe < tlen && dl->text[next_pipe] != '|') next_pipe++;
                        /* Render dashes for the gap between pipes.
                           +1 accounts for the trailing space padding in data rows */
                        int gap = next_pipe - ti + 1;
                        for (int d = 0; d < gap && cx < scrollbar_col; d++) {
                            tb_set_cell(cx, row, 0x2500, theme->card_border, line_bg);
                            cx++;
                        }
                        if (next_pipe < tlen) {
                            /* Another cell boundary — render crossing or T */
                            if (cx < scrollbar_col) {
                                /* Check if there's more content after this pipe */
                                int peek = next_pipe + 1;
                                bool has_more = false;
                                while (peek < tlen) {
                                    if (dl->text[peek] == '|') { has_more = true; break; }
                                    if (dl->text[peek] != '-' && dl->text[peek] != ':'
                                        && dl->text[peek] != ' ') { has_more = true; break; }
                                    peek++;
                                }
                                if (has_more)
                                    tb_set_cell(cx, row, mid_ch, theme->card_border, line_bg);
                                else
                                    tb_set_cell(cx, row, right_ch, theme->card_border, line_bg);
                                cx++;
                            }
                            ti = next_pipe + 1;
                        } else {
                            /* End of text — render right corner */
                            if (cx < scrollbar_col) {
                                tb_set_cell(cx, row, right_ch, theme->card_border, line_bg);
                                cx++;
                            }
                            break;
                        }
                    }
                    /* If no pipes found or text was empty, fill with dashes and right corner */
                    if (ti == 0 || (ti >= tlen && cx < scrollbar_col)) {
                        while (cx < scrollbar_col) {
                            tb_set_cell(cx, row, 0x2500, theme->card_border, line_bg);
                            cx++;
                        }
                    }
                    /* Fill remaining row */
                    for (int fx = cx; fx < scrollbar_col; fx++)
                        tb_set_cell(fx, row, ' ', fg, line_bg);
                    i = tlen;
                    line_handled = true;
                    break;
                }
                case MD_HRULE:
                    for (int hx = line_num_width + 1; hx < scrollbar_col; hx++)
                        tb_set_cell(hx, row, 0x2500, theme->separator_fg, line_bg);
                    i = tlen;
                    line_handled = true;
                    break;
                case MD_TASK_OPEN:
                    tb_set_cell(x, row, 0x25A1,
                                theme->list_marker_fg, line_bg);
                    x += 2;
                    break;
                case MD_TASK_DONE:
                    tb_set_cell(x, row, 0x2611,
                                theme->list_marker_fg | TB_BOLD, line_bg);
                    x += 2;
                    break;
                default: break;
                }
            }

            /* Inline markdown state machine */
            bool md_bold = false;
            bool md_italic = false;
            bool md_code = false;
            bool md_strike = false;

            while (i < tlen && x < scrollbar_col) {
                /* Skip inline markdown in code blocks */
                if (!dl->in_code_block && i >= bold_end) {
                    /* Check for inline code: `text` */
                    if (dl->text[i] == '`' && !md_bold && !md_italic && !md_strike) {
                        md_code = !md_code;
                        i++;
                        continue;
                    }
                    /* Check for strikethrough: ~~text~~ */
                    if (i + 1 < tlen && dl->text[i] == '~' && dl->text[i+1] == '~'
                        && !md_code) {
                        md_strike = !md_strike;
                        i += 2;
                        continue;
                    }
                    /* Check for bold: **text** or __text__ */
                    if (i + 1 < tlen &&
                        ((dl->text[i] == '*' && dl->text[i+1] == '*') ||
                         (dl->text[i] == '_' && dl->text[i+1] == '_')) &&
                        !md_code) {
                        md_bold = !md_bold;
                        i += 2;
                        continue;
                    }
                    /* Check for italic: *text* or _text* (single, not double) */
                    if ((dl->text[i] == '*' || dl->text[i] == '_') && !md_code) {
                        /* Make sure it's not a ** prefix */
                        if (i + 1 >= tlen || dl->text[i+1] != dl->text[i]) {
                            md_italic = !md_italic;
                            i++;
                            continue;
                        }
                    }
                    /* Check for [link](url) — render link text, skip url */
                    if (dl->text[i] == '[') {
                        int close = i + 1;
                        while (close < tlen && dl->text[close] != ']') close++;
                        if (close < tlen && close + 1 < tlen && dl->text[close+1] == '(') {
                            int url_end = close + 2;
                            while (url_end < tlen && dl->text[url_end] != ')') url_end++;
                            if (url_end < tlen) {
                                /* Render link text from i+1..close */
                                int li = i + 1;
                                while (li < close && x < scrollbar_col) {
                                    int lclen = utf8_char_len(dl->text + li);
                                    if (li + lclen > close) break;
                                    uint32_t lcp = utf8_decode(dl->text + li, NULL);
                                    int lcw = char_width(lcp);
                                    if (x + lcw > scrollbar_col) break;
                                    uintattr_t lattr = line_fg | TB_UNDERLINE;
                                    for (int j = 0; j < lcw; j++) {
                                        tb_set_cell(x, row, j == 0 ? lcp : 0, lattr, line_bg);
                                        x++;
                                    }
                                    li += lclen;
                                }
                                i = url_end + 1;
                                continue;
                            }
                        }
                    }
                }

                int clen = utf8_char_len(dl->text + i);
                if (i + clen > tlen) break;
                uint32_t cp = utf8_decode(dl->text + i, NULL);
                int cw = char_width(cp);
                if (x + cw > scrollbar_col) {
                    /* Pad remaining column with space if wide char won't fit */
                    if (x < scrollbar_col)
                        tb_set_cell(x, row, ' ', line_fg, line_bg);
                    break;
                }

                uintattr_t attr;
                uintattr_t cell_bg = line_bg;
                if (i < bold_end) {
                    attr = label_fg | TB_BOLD;
                } else if (dl->tag == TAG_THINKING) {
                    attr = fg | TB_ITALIC;
                } else if (md_code) {
                    attr = theme->inline_code_fg;
                    cell_bg = theme->inline_code_bg;
                } else if (md_strike) {
                    attr = theme->status_fg_dim | TB_DIM;
                } else {
                    attr = line_fg;
                    if (md_bold) attr |= TB_BOLD;
                    if (md_italic) attr |= TB_ITALIC;
                }
                for (int j = 0; j < cw; j++) {
                    tb_set_cell(x, row, j == 0 ? cp : 0, attr, cell_bg);
                    x++;
                }
                i += clen;
            }

            /* Fill remaining text area with line background */
            if (!line_handled) {
                for (int fx = x; fx < scrollbar_col; fx++)
                    tb_set_cell(fx, row, ' ', fg, line_bg);
            }
        }
    }

    // V6: Enhanced scrollbar
    if (need_scrollbar) {
        for (int row = 0; row < output_rows; row++)
            tb_set_cell(w - 1, row, 0x2502, theme->scrollbar_track, theme->bg);
        int thumb_size = (output_rows * output_rows) / visible_count;
        if (thumb_size < 1) thumb_size = 1;
        int thumb_start = (visible_start * output_rows) / visible_count;
        for (int i = 0; i < thumb_size; i++) {
            int row = thumb_start + i;
            if (row >= 0 && row < output_rows)
                tb_set_cell(w - 1, row, 0x2588, theme->scrollbar_thumb, theme->bg);
        }
    }

    if (show_acc) {
        int acc_row = visible_count - visible_start;
        if (acc_row < 0) acc_row = 0;
        uintattr_t acc_fg = tag_to_fg(theme, tui->acc_tag);
        int acc_x = line_num_width + 1;
        int i = 0;
        bool md_bold = false;
        bool md_italic = false;
        bool md_code = false;
        bool md_strike = false;
        int acc_line_num = visible_count + 1;
        while (i < tui->acc_len && acc_row < output_rows) {
            /* Inline markdown for accumulator preview */
            if (tui->acc_buf[i] == '`' && !md_bold && !md_italic && !md_strike) {
                md_code = !md_code;
                i++;
                continue;
            }
            if (i + 1 < tui->acc_len && tui->acc_buf[i] == '~' && tui->acc_buf[i+1] == '~'
                && !md_code) {
                md_strike = !md_strike;
                i += 2;
                continue;
            }
            if (i + 1 < tui->acc_len &&
                ((tui->acc_buf[i] == '*' && tui->acc_buf[i+1] == '*') ||
                 (tui->acc_buf[i] == '_' && tui->acc_buf[i+1] == '_')) &&
                !md_code) {
                md_bold = !md_bold;
                i += 2;
                continue;
            }
            if ((tui->acc_buf[i] == '*' || tui->acc_buf[i] == '_') && !md_code) {
                if (i + 1 >= tui->acc_len || tui->acc_buf[i+1] != tui->acc_buf[i]) {
                    md_italic = !md_italic;
                    i++;
                    continue;
                }
            }

            int clen = utf8_char_len(tui->acc_buf + i);
            if (i + clen > tui->acc_len) break;
            uint32_t cp = utf8_decode(tui->acc_buf + i, NULL);
            int cw = char_width(cp);
            if (acc_x + cw > text_w && acc_x > line_num_width + 1) {
                /* Fill remainder of current row */
                for (int fx = acc_x; fx < scrollbar_col; fx++)
                    tb_set_cell(fx, acc_row, ' ', acc_fg, theme->bg);
                acc_row++;
                acc_x = line_num_width + 1;
                md_bold = false;
                md_italic = false;
                md_code = false;
                md_strike = false;
                acc_line_num++;
                if (acc_row >= output_rows) break;
                /* Draw line number and separator for new row */
                if (line_num_width > 0) {
                    char lnum[16];
                    int lnum_len = snprintf(lnum, sizeof(lnum), "%*d", line_num_width, acc_line_num);
                    render_text(0, acc_row, lnum, lnum_len > line_num_width ? line_num_width : lnum_len,
                               theme->line_number_fg, theme->bg, 0);
                    tb_set_cell(line_num_width, acc_row, 0x2502, theme->line_number_fg, theme->bg);
                }
                for (int fx = line_num_width + 1; fx < scrollbar_col; fx++)
                    tb_set_cell(fx, acc_row, ' ', acc_fg, theme->bg);
            }
            if (acc_x + cw > scrollbar_col) {
                /* Pad remaining column if wide char won't fit */
                if (acc_x < scrollbar_col)
                    tb_set_cell(acc_x, acc_row, ' ', acc_fg, theme->bg);
                break;
            }
            uintattr_t acc_attr;
            if (md_code) {
                acc_attr = theme->inline_code_fg;
            } else if (md_strike) {
                acc_attr = theme->status_fg_dim | TB_DIM;
            } else {
                acc_attr = acc_fg;
                if (md_bold) acc_attr |= TB_BOLD;
                if (md_italic) acc_attr |= TB_ITALIC;
            }
            for (int j = 0; j < cw; j++) {
                tb_set_cell(acc_x, acc_row, j == 0 ? cp : 0, acc_attr,
                            md_code ? theme->inline_code_bg : theme->bg);
                acc_x++;
            }
            i += clen;
        }
        /* Fill remainder of last accumulator row */
        for (int fx = acc_x; fx < scrollbar_col; fx++)
            tb_set_cell(fx, acc_row, ' ', acc_fg, theme->bg);
        /* Draw line number for first accumulator row if not yet drawn */
        if (acc_row < output_rows && line_num_width > 0) {
            char lnum[16];
            int first_acc_row = visible_count - visible_start;
            if (first_acc_row < 0) first_acc_row = 0;
            int first_acc_num = visible_count + 1;
            int lnum_len = snprintf(lnum, sizeof(lnum), "%*d", line_num_width, first_acc_num);
            render_text(0, first_acc_row, lnum, lnum_len > line_num_width ? line_num_width : lnum_len,
                       theme->line_number_fg, theme->bg, 0);
            tb_set_cell(line_num_width, first_acc_row, 0x2502, theme->line_number_fg, theme->bg);
        }
    }

    int status_row = output_rows;
    tui_render_statusbar(tui, theme, status_row, w);

    // V2: Input area with border
    tui_render_input_border(tui, theme, input_row_start, input_rows, w);

    InputLine *inp = &tui->input;
    int prompt_width = 3;
    int visible_width = w - prompt_width - 2;
    if (visible_width < 1) visible_width = 1;

    uintattr_t prompt_fg = tui->agent_busy ? theme->input_prompt_busy : theme->input_prompt;
    if (tui->paste_mode) prompt_fg = theme->input_prompt_paste;

    for (int ln = 0; ln < input_rows; ln++) {
        int actual_ln = ln + input_vscroll;
        if (actual_ln >= total_input_lines) break;
        int row = input_row_start + 1 + ln;
        if (row >= h - 1) break;

        for (int x = 1; x < w - 1; x++)
            tb_set_cell(x, row, ' ', theme->status_fg, theme->bg);

        if (actual_ln == 0) {
            uint32_t prompt_ch = tui->paste_mode ? 0x25B6 : 0x276F;
            tb_set_cell(1, row, prompt_ch, prompt_fg, theme->bg);
            tb_set_cell(2, row, ' ', prompt_fg, theme->bg);
        } else {
            tb_set_cell(1, row, ' ', prompt_fg, theme->bg);
            tb_set_cell(2, row, 0x00B7, theme->status_fg_dim, theme->bg);
        }

        int line_start, line_end;
        input_get_line(inp, actual_ln, &line_start, &line_end);
        int line_len = line_end - line_start;
        char *line_buf = inp->buf + line_start;

        int cur_line = input_cursor_line(inp);
        int cursor_on_this_line = (cur_line == actual_ln);
        int cursor_byte_in_line = cursor_on_this_line ? (inp->cursor - line_start) : 0;
        if (cursor_byte_in_line > line_len) cursor_byte_in_line = line_len;
        int cursor_col = input_col_at_byte(line_buf, cursor_byte_in_line);

        int scroll = 0;
        if (cursor_col < scroll) scroll = cursor_col;
        if (cursor_col - scroll >= visible_width)
            scroll = cursor_col - visible_width + 1;
        if (scroll < 0) scroll = 0;

        int byte_pos = input_byte_at_col(line_buf, line_len, scroll);
        int col = 0;
        while (byte_pos < line_len && col < visible_width) {
            int clen = utf8_char_len(line_buf + byte_pos);
            if (byte_pos + clen > line_len) break;
            uint32_t cp = utf8_decode(line_buf + byte_pos, NULL);
            int cw = char_width(cp);
            for (int j = 0; j < cw && col < visible_width; j++) {
                tb_set_cell(prompt_width + col, row, j == 0 ? cp : 0, theme->status_fg, theme->bg);
                col++;
            }
            byte_pos += clen;
        }

        if (cursor_on_this_line) {
            int cursor_x = prompt_width + (cursor_col - scroll);
            tb_set_cursor(cursor_x, row);
        }
    }
    free(visible);
}

static void exit_history(TUIState *tui) {
    tui->history_index = -1;
}

void tui_input_insert(TUIState *tui, uint32_t ch) {
    InputLine *inp = &tui->input;
    exit_history(tui);

    if (ch == '\n') {
        if (input_line_count(inp) >= 1000) return;
    }

    char utf8[4];
    int len = utf8_encode(ch, utf8);
    if (len == 0) return;

    while (inp->len + len + 1 >= inp->cap) {
        inp->cap *= 2;
        inp->buf = realloc(inp->buf, inp->cap);
    }
    memmove(inp->buf + inp->cursor + len, inp->buf + inp->cursor,
            inp->len - inp->cursor);
    memcpy(inp->buf + inp->cursor, utf8, len);
    inp->len += len;
    inp->buf[inp->len] = '\0';
    inp->cursor += len;
}

void tui_input_backspace(TUIState *tui) {
    InputLine *inp = &tui->input;
    exit_history(tui);
    if (inp->cursor == 0) return;
    int prev = inp->cursor - 1;
    while (prev > 0 && ((unsigned char)inp->buf[prev] & 0xC0) == 0x80) prev--;
    int char_len = inp->cursor - prev;
    memmove(inp->buf + prev, inp->buf + inp->cursor, inp->len - inp->cursor);
    inp->len -= char_len;
    inp->buf[inp->len] = '\0';
    inp->cursor = prev;
}

void tui_input_delete(TUIState *tui) {
    InputLine *inp = &tui->input;
    exit_history(tui);
    if (inp->cursor >= inp->len) return;
    int char_len = utf8_char_len(inp->buf + inp->cursor);
    if (inp->cursor + char_len > inp->len) char_len = inp->len - inp->cursor;
    memmove(inp->buf + inp->cursor, inp->buf + inp->cursor + char_len,
            inp->len - inp->cursor - char_len);
    inp->len -= char_len;
    inp->buf[inp->len] = '\0';
}

void tui_input_move(TUIState *tui, int delta) {
    InputLine *inp = &tui->input;
    if (delta < 0) {
        if (inp->cursor > 0) {
            int prev = inp->cursor - 1;
            while (prev > 0 && ((unsigned char)inp->buf[prev] & 0xC0) == 0x80) prev--;
            inp->cursor = prev;
        }
    } else if (delta > 0) {
        if (inp->cursor < inp->len) {
            inp->cursor += utf8_char_len(inp->buf + inp->cursor);
            if (inp->cursor > inp->len) inp->cursor = inp->len;
        }
    }
}

void tui_input_move_vertical(TUIState *tui, int delta) {
    InputLine *inp = &tui->input;
    int cur_line = input_cursor_line(inp);
    int target = cur_line + delta;

    if (target < 0 || target >= input_line_count(inp)) return;

    int cur_start, cur_end, tgt_start, tgt_end;
    input_get_line(inp, cur_line, &cur_start, &cur_end);
    input_get_line(inp, target, &tgt_start, &tgt_end);

    int col_in_line = input_col_at_byte(inp->buf + cur_start, inp->cursor - cur_start);

    int tgt_line_len = tgt_end - tgt_start;
    int new_byte = input_byte_at_col(inp->buf + tgt_start, tgt_line_len, col_in_line);
    inp->cursor = tgt_start + new_byte;
}

void tui_input_home(TUIState *tui) {
    exit_history(tui);
    tui->input.cursor = 0;
}

void tui_input_end(TUIState *tui) {
    exit_history(tui);
    tui->input.cursor = tui->input.len;
}

char *tui_input_steal(TUIState *tui) {
    InputLine *inp = &tui->input;
    char *result = strdup(inp->buf[0] ? inp->buf : "");

    if (inp->buf[0]) {
        if (tui->history_count >= HISTORY_MAX) {
            free(tui->history[0]);
            memmove(tui->history, tui->history + 1, (HISTORY_MAX - 1) * sizeof(char*));
            tui->history_count = HISTORY_MAX - 1;
        }
        tui->history[tui->history_count++] = strdup(inp->buf);
    }

    inp->len = 0;
    inp->cursor = 0;
    inp->buf[0] = '\0';
    inp->scroll = 0;
    tui->history_index = -1;
    return result;
}

// ===== Input history =====

void tui_history_load(TUIState *tui, int index) {
    InputLine *inp = &tui->input;
    if (index < 0 || index >= tui->history_count) return;

    const char *entry = tui->history[tui->history_count - 1 - index];
    int elen = strlen(entry);
    while (inp->cap <= elen + 1) {
        inp->cap *= 2;
        inp->buf = realloc(inp->buf, inp->cap);
    }
    memcpy(inp->buf, entry, elen);
    inp->buf[elen] = '\0';
    inp->len = elen;
    inp->cursor = elen;
    inp->scroll = 0;
    tui->history_index = index;
}

// ===== Collapse toggle =====

void tui_toggle_collapse(TUIState *tui) {
    int last_group = 0;
    for (int i = tui->line_count - 1; i >= 0; i--) {
        if (tui->lines[i].collapse_group > 0) {
            last_group = tui->lines[i].collapse_group;
            break;
        }
    }
    if (last_group == 0) return;

    bool any_hidden = false;
    for (int i = 0; i < tui->line_count; i++) {
        if (tui->lines[i].collapse_group == last_group && tui->lines[i].hidden) {
            any_hidden = true;
            break;
        }
    }
    for (int i = 0; i < tui->line_count; i++) {
        if (tui->lines[i].collapse_group == last_group) {
            tui->lines[i].hidden = !any_hidden;
        }
    }
}

void tui_spinner_tick(TUIState *tui) {
    tui->spinner_frame = (tui->spinner_frame + 1) % SPINNER_COUNT;
}

void tui_render_statusbar_only(TUIState *tui) {
    const TUITheme *theme = &THEMES[tui->theme_index % THEME_COUNT];
    int w = tui->width;
    int h = tui->height;
    if (w <= 0 || h <= 3) return;

    int total_input_lines = input_line_count(&tui->input);
    int max_input_rows = (h - 4) / 2;
    if (max_input_rows < 1) max_input_rows = 1;
    int input_rows = total_input_lines;
    if (input_rows > max_input_rows) input_rows = max_input_rows;
    int output_rows = h - 2 - input_rows - 2;
    if (output_rows < 3) output_rows = 3;

    tui_render_statusbar(tui, theme, output_rows, w);
}

// ===== Scrolling =====

void tui_clamp_scroll(TUIState *tui)
{
    if (tui->scroll_off <= 0) { tui->scroll_off = 0; return; }
    int visible = 0;
    for (int i = 0; i < tui->line_count; i++)
        if (!tui->lines[i].hidden) visible++;

    int max_input_rows = (tui->height - 4) / 2;
    if (max_input_rows < 1) max_input_rows = 1;
    int total_il = input_line_count(&tui->input);
    int ir = total_il > max_input_rows ? max_input_rows : total_il;
    int output_rows = tui->height - 2 - ir - 2;
    if (output_rows < 3) output_rows = 3;

    int max_off = visible - output_rows;
    if (max_off < 0) max_off = 0;
    if (tui->scroll_off > max_off) tui->scroll_off = max_off;
}

void tui_scroll_up(TUIState *tui, int n) {
    tui->scroll_off += n;
    tui_clamp_scroll(tui);
}

void tui_scroll_down(TUIState *tui, int n) {
    tui->scroll_off -= n;
    if (tui->scroll_off < 0) tui->scroll_off = 0;
}

void tui_scroll_to_bottom(TUIState *tui) {
    tui->scroll_off = 0;
}

void tui_set_status(TUIState *tui, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(tui->status, sizeof(tui->status), fmt, ap);
    va_end(ap);
    va_start(ap, fmt);
    vsnprintf(tui->state_text, sizeof(tui->state_text), fmt, ap);
    va_end(ap);
}

void tui_set_state_text(TUIState *tui, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(tui->state_text, sizeof(tui->state_text), fmt, ap);
    va_end(ap);
}

void tui_cycle_theme(TUIState *tui) {
    tui->theme_index = (tui->theme_index + 1) % THEME_COUNT;
}

int tui_theme_count(void) {
    return (int)THEME_COUNT;
}

const char *tui_theme_name(int index) {
    if (index < 0 || index >= (int)THEME_COUNT) return "Unknown";
    return THEME_NAMES[index];
}

const TUITheme *tui_get_theme(int index) {
    if (index < 0 || index >= (int)THEME_COUNT) return &THEMES[0];
    return &THEMES[index];
}

/* ===== Generic popup rendering ===== */

void tui_render_menu_popup(const TUIState *tui, int input_row,
                            const char **labels, const char **shortcuts,
                            int item_count, int selected) {
    const TUITheme *theme = &THEMES[tui->theme_index % THEME_COUNT];
    int w = tui->width;
    int max_w = w > 40 ? 40 : w;
    int popup_h = item_count + 2;
    int popup_row = input_row - popup_h;
    if (popup_row < 0) popup_row = 0;

    int px = 2, py = popup_row;

    tb_set_cell(px, py, 0x256D, theme->card_border, theme->bg);
    for (int x = 1; x < max_w - 1; x++)
        tb_set_cell(px + x, py, 0x2500, theme->card_border, theme->bg);
    tb_set_cell(px + max_w - 1, py, 0x256E, theme->card_border, theme->bg);

    for (int i = 0; i < item_count; i++) {
        int r = py + 1 + i;
        uintattr_t fg = theme->status_fg, bg = theme->bg;
        if (i == selected) { fg = theme->bg; bg = theme->status_fg; }
        tb_set_cell(px, r, 0x2502, theme->card_border, theme->bg);
        for (int x = 1; x < max_w - 1; x++)
            tb_set_cell(px + x, r, ' ', fg, bg);
        int llen = (int)strlen(labels[i]);
        render_text(px + 1, r, labels[i], llen > max_w - 2 ? max_w - 2 : llen, fg, bg, 0);
        if (shortcuts && shortcuts[i]) {
            char sc[16];
            int slen = snprintf(sc, sizeof(sc), "[%s]", shortcuts[i]);
            int sc_x = px + max_w - 2 - slen;
            if (sc_x > px + 1)
                render_text(sc_x, r, sc, slen, theme->status_fg_dim, bg, 0);
        }
        tb_set_cell(px + max_w - 1, r, 0x2502, theme->card_border, theme->bg);
    }

    int br = py + 1 + item_count;
    tb_set_cell(px, br, 0x2570, theme->card_border, theme->bg);
    for (int x = 1; x < max_w - 1; x++)
        tb_set_cell(px + x, br, 0x2500, theme->card_border, theme->bg);
    tb_set_cell(px + max_w - 1, br, 0x256F, theme->card_border, theme->bg);
}

void tui_render_list_popup(const TUIState *tui, int input_row,
                            const char *title, const char **items,
                            int item_count, int selected) {
    const TUITheme *theme = &THEMES[tui->theme_index % THEME_COUNT];
    int w = tui->width;
    int max_w = w > 40 ? 40 : w;
    int popup_h = item_count + 2;
    int popup_row = input_row - popup_h;
    if (popup_row < 0) popup_row = 0;

    int px = 2, py = popup_row;

    tb_set_cell(px, py, 0x256D, theme->card_border, theme->bg);
    int tlen = (int)strlen(title);
    render_text(px + 1, py, title, tlen < max_w - 2 ? tlen : max_w - 2, theme->code_lang_fg, theme->bg, 0);
    for (int x = 1 + (tlen < max_w - 2 ? tlen : max_w - 2); x < max_w - 1; x++)
        tb_set_cell(px + x, py, 0x2500, theme->card_border, theme->bg);
    tb_set_cell(px + max_w - 1, py, 0x256E, theme->card_border, theme->bg);

    for (int i = 0; i < item_count; i++) {
        int r = py + 1 + i;
        uintattr_t fg = theme->status_fg, bg = theme->bg;
        if (i == selected) { fg = theme->bg; bg = theme->status_fg; }
        tb_set_cell(px, r, 0x2502, theme->card_border, theme->bg);
        for (int x = 1; x < max_w - 1; x++)
            tb_set_cell(px + x, r, ' ', fg, bg);
        char line[64];
        int llen = snprintf(line, sizeof(line), " %s", items[i]);
        render_text(px + 1, r, line, llen > max_w - 2 ? max_w - 2 : llen, fg, bg, 0);
        tb_set_cell(px + max_w - 1, r, 0x2502, theme->card_border, theme->bg);
    }

    int br = py + 1 + item_count;
    tb_set_cell(px, br, 0x2570, theme->card_border, theme->bg);
    for (int x = 1; x < max_w - 1; x++)
        tb_set_cell(px + x, br, 0x2500, theme->card_border, theme->bg);
    tb_set_cell(px + max_w - 1, br, 0x256F, theme->card_border, theme->bg);
}

void tui_render_shortcuts_popup(const TUIState *tui, int input_row) {
    /* This uses command.h data — include via extern in app.c which builds the arrays */
    /* For simplicity, render is done in app.c via tui_render_list_popup per-item */
    /* This function is a placeholder; app.c uses tui_render_list_popup directly */
    (void)tui; (void)input_row;
}
