#include "command.h"
#include <string.h>

static const SlashCommandDef SLASH_COMMANDS[] = {
    {"theme",     "Switch color theme",           "t", CMD_THEME},
    {"model",     "Switch LLM model profile",     "m", CMD_MODEL},
    {"shortcuts", "Show keyboard shortcuts",      "s", CMD_SHORTCUTS},
};
#define SLASH_CMD_COUNT (sizeof(SLASH_COMMANDS) / sizeof(SLASH_COMMANDS[0]))

const SlashCommandDef *command_def(int index) {
    if (index < 0 || index >= (int)SLASH_CMD_COUNT) return NULL;
    return &SLASH_COMMANDS[index];
}

int command_def_count(void) {
    return (int)SLASH_CMD_COUNT;
}

static const ShortcutInfo SHORTCUTS[] = {
    {"Enter",       "Send message"},
    {"Ctrl+N",      "Insert newline"},
    {"Ctrl+V",      "Toggle paste mode"},
    {"Ctrl+P",      "Switch model profile"},
    {"Ctrl+C",      "Interrupt / Quit (x2)"},
    {"ESC",         "Cancel / Interrupt"},
    {"Alt+Enter",   "Insert newline"},
    {"\\ + Enter",  "Line continuation"},
    {"/",           "Open command menu"},
    {"t",           "Toggle collapsed output"},
    {"Shift+Up/Dn", "Scroll output"},
    {"PgUp/PgDn",  "Half-page scroll"},
    {"Up/Down",     "History (empty) / Cursor"},
};
#define SHORTCUTS_COUNT (sizeof(SHORTCUTS) / sizeof(SHORTCUTS[0]))

int shortcut_count(void) {
    return (int)SHORTCUTS_COUNT;
}

const ShortcutInfo *shortcut_get(int index) {
    if (index < 0 || index >= (int)SHORTCUTS_COUNT) return NULL;
    return &SHORTCUTS[index];
}

void cmd_update_matches(CommandPopup *popup, const char *input) {
    popup->match_count = 0;
    popup->selected = 0;
    if (!input || !input[0]) {
        for (int i = 0; i < (int)SLASH_CMD_COUNT && popup->match_count < 16; i++)
            popup->match_indices[popup->match_count++] = i;
        return;
    }
    for (int i = 0; i < (int)SLASH_CMD_COUNT && popup->match_count < 16; i++) {
        if (strstr(SLASH_COMMANDS[i].name, input) == SLASH_COMMANDS[i].name)
            popup->match_indices[popup->match_count++] = i;
    }
}
