#ifndef AGENT_H
#define AGENT_H

#include "llm_client.h"
#include "tool_engine.h"
#include "context.h"
#include "cJSON.h"
#include <stdatomic.h>
#include <stdbool.h>

#define AGENT_MAX_ITERATIONS    25
#define AGENT_MAX_PLAN_STEPS    20
#define AGENT_MAX_RETRIES       3

typedef enum {
    AGENT_OK = 0,
    AGENT_ERROR_API,
    AGENT_ERROR_MAX_ITERATIONS,
    AGENT_ERROR_CANCELLED
} AgentResult;

typedef enum {
    STEP_PENDING,
    STEP_IN_PROGRESS,
    STEP_DONE,
    STEP_FAILED,
    STEP_SKIPPED
} StepStatus;

typedef struct {
    int         index;
    char       *description;
    StepStatus  status;
    char       *result_summary;
} PlanStep;

typedef struct {
    PlanStep   *steps;
    int         step_count;
    int         current_step;
    bool        active;
    char       *plan_summary;
} AgentPlan;

typedef struct {
    int         consecutive_errors;
    int         total_tool_calls;
    int         total_retries;
    bool        last_tool_failed;
    char       *last_error;
} ReflectionState;

typedef struct {
    void  *user_data;
    void (*on_text)(void *ud, const char *text, size_t len);
    void (*on_thinking)(void *ud, const char *text, size_t len);
    void (*on_tool_call)(void *ud, const char *name, const char *input_json);
    void (*on_tool_result)(void *ud, const char *result, bool truncated);
    void (*on_plan_update)(void *ud, const AgentPlan *plan);
    void (*on_reflection)(void *ud, const char *reflection_text);
    void (*on_status)(void *ud, const char *status);
    _Atomic bool *cancel_flag;
} AgentOutput;

typedef struct {
    LLMContext     *ctx;
    ToolRegistry   *reg;
    AgentPlan       plan;
    ReflectionState reflection;
    int             iteration_count;
    int             max_iterations;
    int             send_seq;
    _Atomic bool    cancelled;

    AgentOutput     output;
} AgentSession;

void        agent_session_init(AgentSession *session, LLMContext *ctx, ToolRegistry *reg);
void        agent_session_free(AgentSession *session);
void        agent_session_reset(AgentSession *session);

AgentResult agent_run_turn(AgentSession *session, const char *user_msg);

AgentPlan  *agent_plan_parse(const char *plan_text);
void        agent_plan_free(AgentPlan *plan);
void        agent_plan_update_step(AgentPlan *plan, int index, StepStatus status, const char *summary);
char       *agent_plan_format(const AgentPlan *plan);

void   reflection_init(ReflectionState *r);
void   reflection_record_tool_result(ReflectionState *r, bool success, const char *text);
void   reflection_record_retry(ReflectionState *r);
bool   reflection_should_retry(const ReflectionState *r);
void   reflection_reset(ReflectionState *r);
char  *reflection_build_prompt(const ReflectionState *r);

#endif
