#include "llm_client.h"
#include "string_utils.h"
#include <curl/curl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ===== SSE Streaming State =====

typedef struct {
    int   index;
    int   type;         // 0=text, 1=tool_use
    char *tool_id;
    char *tool_name;
    char *tool_input_json;   // accumulated JSON for tool input
} ContentBlock;

typedef struct {
    StringBuffer line_buf;   // incomplete SSE line
    ContentBlock blocks[32];
    int          block_count;

    // Accumulated response
    StringBuffer text_buf;
    cJSON       *tool_calls;
    bool         is_tool_use;
    bool         had_error;
    char        *error_msg;

    StreamCallbacks *callbacks;   // NULL for stdout mode
} StreamState;

static void stream_state_init(StreamState *s) {
    sb_init(&s->line_buf);
    sb_init(&s->text_buf);
    memset(s->blocks, 0, sizeof(s->blocks));
    s->block_count = 0;
    s->tool_calls = NULL;
    s->is_tool_use = false;
    s->had_error = false;
    s->error_msg = NULL;
}

static void stream_state_free(StreamState *s) {
    sb_free(&s->line_buf);
    sb_free(&s->text_buf);
    for (int i = 0; i < s->block_count; i++) {
        free(s->blocks[i].tool_id);
        free(s->blocks[i].tool_name);
        free(s->blocks[i].tool_input_json);
    }
    free(s->error_msg);
    // tool_calls is transferred to LLMResponse, not freed here
}

// ===== Process a single SSE data line =====

static void process_sse_data(StreamState *state, const char *data) {
    cJSON *root = cJSON_Parse(data);
    if (!root) return;

    cJSON *type = cJSON_GetObjectItem(root, "type");
    if (!type || !type->valuestring) { cJSON_Delete(root); return; }

    if (strcmp(type->valuestring, "error") == 0) {
        cJSON *err = cJSON_GetObjectItem(root, "error");
        if (err) {
            cJSON *msg = cJSON_GetObjectItem(err, "message");
            state->had_error = true;
            state->error_msg = strdup(msg && msg->valuestring ? msg->valuestring : "Unknown error");
        }
    }
    // New content block starting
    else if (strcmp(type->valuestring, "content_block_start") == 0) {
        cJSON *idx = cJSON_GetObjectItem(root, "index");
        cJSON *cb = cJSON_GetObjectItem(root, "content_block");
        if (!cb) { cJSON_Delete(root); return; }

        int i = state->block_count++;
        state->blocks[i].index = idx ? idx->valueint : i;
        state->blocks[i].tool_input_json = NULL;

        cJSON *cb_type = cJSON_GetObjectItem(cb, "type");
        if (cb_type && strcmp(cb_type->valuestring, "text") == 0) {
            state->blocks[i].type = 0;
        } else if (cb_type && strcmp(cb_type->valuestring, "tool_use") == 0) {
            state->blocks[i].type = 1;
            cJSON *id = cJSON_GetObjectItem(cb, "id");
            cJSON *name = cJSON_GetObjectItem(cb, "name");
            state->blocks[i].tool_id = strdup(id && id->valuestring ? id->valuestring : "");
            state->blocks[i].tool_name = strdup(name && name->valuestring ? name->valuestring : "");
            state->blocks[i].tool_input_json = calloc(1, 1); // empty string
        }
    }
    // Delta: text or tool input fragment
    else if (strcmp(type->valuestring, "content_block_delta") == 0) {
        cJSON *idx = cJSON_GetObjectItem(root, "index");
        int i = idx ? idx->valueint : 0;
        cJSON *delta = cJSON_GetObjectItem(root, "delta");
        if (!delta) { cJSON_Delete(root); return; }

        cJSON *d_type = cJSON_GetObjectItem(delta, "type");

        if (d_type && strcmp(d_type->valuestring, "text_delta") == 0) {
            cJSON *txt = cJSON_GetObjectItem(delta, "text");
            if (txt && txt->valuestring) {
                const char *text = txt->valuestring;
                size_t text_len = strlen(text);

                if (state->callbacks && state->callbacks->on_text) {
                    state->callbacks->on_text(state->callbacks->user_data,
                                              text, text_len);
                }
                sb_append(&state->text_buf, text, text_len);
            }
        } else if (d_type && strcmp(d_type->valuestring, "input_json_delta") == 0) {
            cJSON *pj = cJSON_GetObjectItem(delta, "partial_json");
            if (pj && pj->valuestring) {
                // Accumulate tool input JSON
                ContentBlock *blk = NULL;
                for (int b = 0; b < state->block_count; b++) {
                    if (state->blocks[b].index == i) { blk = &state->blocks[b]; break; }
                }
                if (blk) {
                    size_t old_len = blk->tool_input_json ? strlen(blk->tool_input_json) : 0;
                    size_t add_len = strlen(pj->valuestring);
                    blk->tool_input_json = realloc(blk->tool_input_json, old_len + add_len + 1);
                    memcpy(blk->tool_input_json + old_len, pj->valuestring, add_len);
                    blk->tool_input_json[old_len + add_len] = '\0';
                }
            }
        }
    }
    // Message-level delta (stop_reason)
    else if (strcmp(type->valuestring, "message_delta") == 0) {
        cJSON *delta = cJSON_GetObjectItem(root, "delta");
        if (delta) {
            cJSON *stop = cJSON_GetObjectItem(delta, "stop_reason");
            if (stop && stop->valuestring && strcmp(stop->valuestring, "tool_use") == 0) {
                state->is_tool_use = true;
            }
        }
    }

    cJSON_Delete(root);
}

// ===== Process buffered SSE lines =====

// SSE lines come in as: "event: xxx\ndata: {...}\n\n"
// curl delivers arbitrary chunks, so we buffer by newlines.
static void process_buffered_lines(StreamState *state) {
    char *data = state->line_buf.data;
    if (!data) return;

    char *line = data;
    while (line && *line) {
        char *nl = strchr(line, '\n');
        if (nl) {
            *nl = '\0';
            // Remove \r if present
            size_t ll = strlen(line);
            if (ll > 0 && line[ll - 1] == '\r') line[ll - 1] = '\0';

            if (strncmp(line, "data: ", 6) == 0) {
                process_sse_data(state, line + 6);
            } else if (strncmp(line, "data:", 5) == 0) {
                process_sse_data(state, line + 5);
            }

            line = nl + 1;
        } else {
            // Incomplete line — move remainder to start of buffer
            size_t remaining = strlen(line);
            memmove(data, line, remaining);
            data[remaining] = '\0';
            state->line_buf.len = remaining;
            return;
        }
    }
    // All consumed
    sb_free(&state->line_buf);
    sb_init(&state->line_buf);
}

// ===== Curl write callback for SSE =====

static size_t stream_write_cb(void *ptr, size_t size, size_t nmemb, void *ud) {
    StreamState *state = (StreamState *)ud;

    if (state->callbacks && state->callbacks->cancel_ptr &&
        atomic_load(state->callbacks->cancel_ptr)) {
        return 0;
    }

    size_t total = size * nmemb;
    sb_append(&state->line_buf, (const char *)ptr, total);
    process_buffered_lines(state);
    return total;
}

// ===== Build final response from stream state =====

static void build_response_from_state(StreamState *state, LLMResponse *resp) {
    memset(resp, 0, sizeof(*resp));

    resp->text = state->text_buf.data;  // transfer ownership
    state->text_buf.data = NULL;

    resp->is_tool_use = state->is_tool_use;

    // Assemble tool_calls from content blocks
    for (int i = 0; i < state->block_count; i++) {
        if (state->blocks[i].type == 1) {
            if (!resp->tool_calls) resp->tool_calls = cJSON_CreateArray();

            cJSON *tc = cJSON_CreateObject();
            cJSON_AddStringToObject(tc, "type", "tool_use");
            cJSON_AddStringToObject(tc, "id", state->blocks[i].tool_id);
            cJSON_AddStringToObject(tc, "name", state->blocks[i].tool_name);

            // Parse accumulated input JSON
            cJSON *input = cJSON_Parse(state->blocks[i].tool_input_json ? state->blocks[i].tool_input_json : "{}");
            if (!input) input = cJSON_CreateObject();
            cJSON_AddItemToObject(tc, "input", input);

            cJSON_AddItemToArray(resp->tool_calls, tc);
        }
    }
}

// ===== Message history helpers =====

static void ensure_msg_capacity(LLMContext *ctx) {
    if (ctx->msg_count >= ctx->msg_capacity) {
        ctx->msg_capacity = ctx->msg_capacity ? ctx->msg_capacity * 2 : 16;
        ctx->messages = realloc(ctx->messages, ctx->msg_capacity * sizeof(Message));
    }
}

static void push_message(LLMContext *ctx, Message msg) {
    ensure_msg_capacity(ctx);
    ctx->messages[ctx->msg_count++] = msg;
}

// ===== Build request JSON =====

static char *build_request_json(LLMContext *ctx, const char *user_msg) {
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "model", ctx->config->model);
    cJSON_AddNumberToObject(root, "max_tokens", ctx->config->max_tokens);
    cJSON_AddBoolToObject(root, "stream", 1);

    // Bug Fix 1: System prompt as top-level API parameter
    if (ctx->system_prompt || ctx->system_prompt_context) {
        StringBuffer sb;
        sb_init(&sb);
        if (ctx->system_prompt)
            sb_append(&sb, ctx->system_prompt, strlen(ctx->system_prompt));
        if (ctx->system_prompt_context) {
            if (sb.data) sb_append(&sb, "\n\n", 2);
            sb_append(&sb, ctx->system_prompt_context,
                      strlen(ctx->system_prompt_context));
        }
        cJSON_AddStringToObject(root, "system", sb.data ? sb.data : "");
        free(sb.data);
    }

    cJSON *msgs = cJSON_AddArrayToObject(root, "messages");

    // Bug Fix 2: Sliding window — cap at MAX_HISTORY messages
    int max_history = 40;
    int start = 0;
    if (ctx->msg_count > max_history) {
        start = ctx->msg_count - max_history;
        // Align to start of a turn (skip partial tool_result sequences)
        while (start < ctx->msg_count && ctx->messages[start].role == ROLE_TOOL_RESULT) {
            start++;
        }
    }

    for (int i = start; i < ctx->msg_count; i++) {
        Message *m = &ctx->messages[i];

        if (m->role == ROLE_TOOL_RESULT) {
            cJSON *msg_obj = cJSON_CreateObject();
            cJSON_AddStringToObject(msg_obj, "role", "user");
            cJSON *arr = cJSON_AddArrayToObject(msg_obj, "content");

            while (i < ctx->msg_count && ctx->messages[i].role == ROLE_TOOL_RESULT) {
                Message *tr_msg = &ctx->messages[i];
                cJSON *tr = cJSON_CreateObject();
                cJSON_AddStringToObject(tr, "type", "tool_result");
                cJSON_AddStringToObject(tr, "tool_use_id", tr_msg->tool_use_id);
                cJSON_AddStringToObject(tr, "content", tr_msg->content ? tr_msg->content : "");
                cJSON_AddItemToArray(arr, tr);
                i++;
            }
            i--;
            cJSON_AddItemToArray(msgs, msg_obj);
        } else if (m->role == ROLE_ASSISTANT && m->tool_calls) {
            cJSON *msg_obj = cJSON_CreateObject();
            cJSON_AddStringToObject(msg_obj, "role", "assistant");
            cJSON *arr = cJSON_AddArrayToObject(msg_obj, "content");
            if (m->content) {
                cJSON *txt = cJSON_CreateObject();
                cJSON_AddStringToObject(txt, "type", "text");
                cJSON_AddStringToObject(txt, "text", m->content);
                cJSON_AddItemToArray(arr, txt);
            }
            cJSON *tc;
            cJSON_ArrayForEach(tc, m->tool_calls) {
                cJSON_AddItemToArray(arr, cJSON_Duplicate(tc, 1));
            }
            cJSON_AddItemToArray(msgs, msg_obj);
        } else {
            cJSON *msg_obj = cJSON_CreateObject();
            cJSON_AddStringToObject(msg_obj, "role",
                m->role == ROLE_USER ? "user" : "assistant");
            cJSON_AddStringToObject(msg_obj, "content", m->content ? m->content : "");
            cJSON_AddItemToArray(msgs, msg_obj);
        }
    }

    if (user_msg) {
        cJSON *msg_obj = cJSON_CreateObject();
        cJSON_AddStringToObject(msg_obj, "role", "user");
        cJSON_AddStringToObject(msg_obj, "content", user_msg);
        cJSON_AddItemToArray(msgs, msg_obj);
    }

    if (ctx->tool_count > 0) {
        cJSON *tools_arr = cJSON_AddArrayToObject(root, "tools");
        for (int i = 0; i < ctx->tool_count; i++) {
            cJSON *t = cJSON_CreateObject();
            cJSON_AddStringToObject(t, "name", ctx->tools[i].name);
            cJSON_AddStringToObject(t, "description", ctx->tools[i].description);
            cJSON_AddItemToObject(t, "input_schema",
                                  cJSON_Duplicate(ctx->tools[i].parameters, 1));
            cJSON_AddItemToArray(tools_arr, t);
        }
    }

    char *json_str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return json_str;
}

static char *g_last_request_json = NULL;

const char *llm_last_request_json(void) {
    return g_last_request_json;
}

int llm_chat_ex(LLMContext *ctx, const char *user_msg,
                LLMResponse *resp, StreamCallbacks *callbacks) {

    char *req_json = build_request_json(ctx, user_msg);

    free(g_last_request_json);
    g_last_request_json = strdup(req_json);

    char url[1024];
    snprintf(url, sizeof(url), "%s/v1/messages", ctx->config->base_url);

    StreamState state;
    stream_state_init(&state);
    state.callbacks = callbacks;

    CURL *curl = curl_easy_init();
    if (!curl) { free(req_json); stream_state_free(&state); return -1; }

    struct curl_slist *headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    char auth[512];
    snprintf(auth, sizeof(auth), "x-api-key: %s", ctx->config->api_key);
    headers = curl_slist_append(headers, auth);
    headers = curl_slist_append(headers, "anthropic-version: 2023-06-01");

    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, req_json);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, stream_write_cb);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &state);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, (long)ctx->config->timeout_ms);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);

    CURLcode res = curl_easy_perform(curl);

    long http_code = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    free(req_json);

    bool was_cancelled = callbacks && callbacks->cancel_ptr &&
                         atomic_load(callbacks->cancel_ptr);

    if (was_cancelled) {
        build_response_from_state(&state, resp);
        resp->is_tool_use = false;
        if (callbacks->on_complete) {
            callbacks->on_complete(callbacks->user_data, 1);
        }
        stream_state_free(&state);
        return 0;
    }

    if (res != CURLE_OK) {
        fprintf(stderr, "[HTTP Error] %s\n", curl_easy_strerror(res));
        stream_state_free(&state);
        return -1;
    }

    if (http_code >= 400) {
        if (state.had_error && state.error_msg) {
            fprintf(stderr, "[API Error %ld] %s\n", http_code, state.error_msg);
        } else {
            fprintf(stderr, "[API Error %ld]\n", http_code);
        }
        stream_state_free(&state);
        return -1;
    }

    if (state.had_error) {
        fprintf(stderr, "[Stream Error] %s\n", state.error_msg ? state.error_msg : "unknown");
        stream_state_free(&state);
        return -1;
    }

    // Ensure trailing newline after typewriter output (stdout mode only)
    if (!callbacks && state.text_buf.len > 0) {
        fputs("\n", stdout);
        fflush(stdout);
    }

    build_response_from_state(&state, resp);
    if (callbacks && callbacks->on_complete) {
        callbacks->on_complete(callbacks->user_data, 0);
    }
    stream_state_free(&state);
    return 0;
}

int llm_chat(LLMContext *ctx, const char *user_msg, LLMResponse *resp) {
    return llm_chat_ex(ctx, user_msg, resp, NULL);
}

// ===== Tool registration =====

int llm_register_tool(LLMContext *ctx, const char *name,
                      const char *desc, cJSON *params_schema) {
    if (ctx->tool_count >= 32) return -1;
    ToolDef *t = &ctx->tools[ctx->tool_count++];
    t->name = strdup(name);
    t->description = strdup(desc);
    t->parameters = cJSON_Duplicate(params_schema, 1);
    return 0;
}

int llm_append_assistant_tool_calls(LLMContext *ctx, const char *text,
                                    cJSON *tool_calls) {
    Message msg = {0};
    msg.role = ROLE_ASSISTANT;
    msg.content = text ? strdup(text) : NULL;
    msg.tool_calls = cJSON_Duplicate(tool_calls, 1);
    push_message(ctx, msg);
    return 0;
}

int llm_append_assistant_text(LLMContext *ctx, const char *text) {
    Message msg = {0};
    msg.role = ROLE_ASSISTANT;
    msg.content = text ? strdup(text) : NULL;
    push_message(ctx, msg);
    return 0;
}

int llm_append_user_message(LLMContext *ctx, const char *text) {
    Message msg = {0};
    msg.role = ROLE_USER;
    msg.content = text ? strdup(text) : NULL;
    push_message(ctx, msg);
    return 0;
}

int llm_append_tool_result(LLMContext *ctx, const char *tool_use_id,
                           const char *result) {
    Message msg = {0};
    msg.role = ROLE_TOOL_RESULT;
    msg.tool_use_id = strdup(tool_use_id);
    msg.content = result ? strdup(result) : strdup("");
    push_message(ctx, msg);
    return 0;
}

void llm_response_free(LLMResponse *resp) {
    if (resp->text) { free(resp->text); resp->text = NULL; }
    if (resp->tool_calls) { cJSON_Delete(resp->tool_calls); resp->tool_calls = NULL; }
    resp->is_tool_use = false;
}

void llm_drop_messages(LLMContext *ctx, int count) {
    if (count <= 0 || count > ctx->msg_count) return;
    for (int i = 0; i < count; i++) {
        free(ctx->messages[i].content);
        free(ctx->messages[i].tool_use_id);
        if (ctx->messages[i].tool_calls) cJSON_Delete(ctx->messages[i].tool_calls);
    }
    int remaining = ctx->msg_count - count;
    if (remaining > 0) {
        memmove(&ctx->messages[0], &ctx->messages[count],
                remaining * sizeof(Message));
    }
    ctx->msg_count = remaining;
}

LLMContext *llm_context_create(AgentConfig *cfg) {
    LLMContext *ctx = calloc(1, sizeof(LLMContext));
    ctx->config = cfg;
    ctx->tools = calloc(32, sizeof(ToolDef));
    return ctx;
}

void llm_context_free(LLMContext *ctx) {
    if (!ctx) return;
    for (int i = 0; i < ctx->msg_count; i++) {
        free(ctx->messages[i].content);
        free(ctx->messages[i].tool_use_id);
        if (ctx->messages[i].tool_calls) cJSON_Delete(ctx->messages[i].tool_calls);
    }
    free(ctx->messages);
    for (int i = 0; i < ctx->tool_count; i++) {
        free(ctx->tools[i].name);
        free(ctx->tools[i].description);
        cJSON_Delete(ctx->tools[i].parameters);
    }
    free(ctx->tools);
    free(ctx->system_prompt_context);
    free(ctx);
}

/* ===== Message accessors ===== */

int llm_msg_count(const LLMContext *ctx) {
    return ctx ? ctx->msg_count : 0;
}

MessageRole llm_msg_role(const LLMContext *ctx, int index) {
    if (!ctx || index < 0 || index >= ctx->msg_count) return ROLE_USER;
    return ctx->messages[index].role;
}

const char *llm_msg_content(const LLMContext *ctx, int index) {
    if (!ctx || index < 0 || index >= ctx->msg_count) return NULL;
    return ctx->messages[index].content;
}

const char *llm_msg_tool_use_id(const LLMContext *ctx, int index) {
    if (!ctx || index < 0 || index >= ctx->msg_count) return NULL;
    return ctx->messages[index].tool_use_id;
}

cJSON *llm_msg_tool_calls(const LLMContext *ctx, int index) {
    if (!ctx || index < 0 || index >= ctx->msg_count) return NULL;
    return ctx->messages[index].tool_calls;
}
