#ifndef CONFIG_H
#define CONFIG_H

#define MAX_PROFILES 8

typedef struct {
    char *name;
    char *base_url;
    char *model;
    char *api_key;
} ModelProfile;

typedef struct {
    char *api_key;
    char *base_url;
    char *model;
    int   timeout_ms;
    char *workspace_dir;
    char *haiku_model;
    char *sonnet_model;
    char *opus_model;
    int   max_tokens;
    int   profile_index;
} AgentConfig;

int  config_load(AgentConfig *cfg, const char *json_path);
void config_free(AgentConfig *cfg);
int  config_profile_count(void);
const ModelProfile *config_get_profile(int index);
void config_switch_profile(AgentConfig *cfg, int index);

#endif
