#ifndef LLM_CLIENT_H
#define LLM_CLIENT_H

#include "config.h"
#include "cJSON.h"
#include <stdatomic.h>
#include <stdbool.h>

typedef enum { ROLE_USER, ROLE_ASSISTANT, ROLE_TOOL_RESULT } MessageRole;

typedef struct {
    MessageRole role;
    char  *content;
    char  *tool_use_id;
    cJSON *tool_calls;
} Message;

typedef struct {
    char  *name;
    char  *description;
    cJSON *parameters;
} ToolDef;

typedef struct {
    char  *text;
    cJSON *tool_calls;
    bool   is_tool_use;
} LLMResponse;

typedef struct {
    void         *user_data;
    void (*on_text)(void *user_data, const char *text, size_t len);
    void (*on_thinking)(void *user_data, const char *text, size_t len);
    void (*on_complete)(void *user_data, int cancelled);
    _Atomic bool *cancel_ptr;
} StreamCallbacks;

typedef struct LLMContext {
    Message     *messages;
    int          msg_count;
    int          msg_capacity;
    ToolDef     *tools;
    int          tool_count;
    AgentConfig *config;
    const char  *system_prompt;
    char        *system_prompt_context;  /* editor context slot, replaced each turn */
} LLMContext;

LLMContext *llm_context_create(AgentConfig *cfg);
void        llm_context_free(LLMContext *ctx);

int  llm_register_tool(LLMContext *ctx, const char *name,
                       const char *desc, cJSON *params_schema);

int  llm_chat(LLMContext *ctx, const char *user_msg, LLMResponse *resp);
int  llm_chat_ex(LLMContext *ctx, const char *user_msg,
                 LLMResponse *resp, StreamCallbacks *callbacks);

int  llm_append_tool_result(LLMContext *ctx, const char *tool_use_id,
                            const char *result);

int  llm_append_assistant_tool_calls(LLMContext *ctx, const char *text,
                                     cJSON *tool_calls);
int  llm_append_assistant_text(LLMContext *ctx, const char *text);
int  llm_append_user_message(LLMContext *ctx, const char *text);

void llm_drop_messages(LLMContext *ctx, int count);

void llm_response_free(LLMResponse *resp);

const char *llm_last_request_json(void);

/* ===== Message accessors ===== */

int           llm_msg_count(const LLMContext *ctx);
MessageRole   llm_msg_role(const LLMContext *ctx, int index);
const char   *llm_msg_content(const LLMContext *ctx, int index);
const char   *llm_msg_tool_use_id(const LLMContext *ctx, int index);
cJSON        *llm_msg_tool_calls(const LLMContext *ctx, int index);

#endif
