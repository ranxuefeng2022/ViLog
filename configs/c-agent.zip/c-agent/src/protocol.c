#include "protocol.h"
#include "string_utils.h"
#include "cJSON.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===== JSON escaping ===== */

char *protocol_json_escape(const char *src, size_t len)
{
    StringBuffer buf;
    sb_init(&buf);

    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)src[i];
        switch (c) {
        case '"':
            sb_append(&buf, "\\\"", 2);
            break;
        case '\\':
            sb_append(&buf, "\\\\", 2);
            break;
        case '\n':
            sb_append(&buf, "\\n", 2);
            break;
        case '\r':
            sb_append(&buf, "\\r", 2);
            break;
        case '\t':
            sb_append(&buf, "\\t", 2);
            break;
        default:
            if (c < 0x20) {
                char hex[8];
                snprintf(hex, sizeof(hex), "\\u%04x", c);
                sb_append(&buf, hex, strlen(hex));
            } else {
                sb_append(&buf, (char[]){(char)c}, 1);
            }
            break;
        }
    }

    return buf.data;    /* caller frees; may be NULL if empty */
}

/* ===== Adapter lifecycle ===== */

void protocol_adapter_init(ProtocolAdapter *adapter, Transport *transport)
{
    adapter->transport = transport;
    pthread_mutex_init(&adapter->write_mutex, NULL);
}

void protocol_adapter_free(ProtocolAdapter *adapter)
{
    pthread_mutex_destroy(&adapter->write_mutex);
    adapter->transport = NULL;
}

/* ===== JSON-RPC send helpers ===== */

static void send_json_line(ProtocolAdapter *adapter, const char *json, size_t len)
{
    if (!adapter->transport) return;
    pthread_mutex_lock(&adapter->write_mutex);
    adapter->transport->write_message(adapter->transport, json, len);
    pthread_mutex_unlock(&adapter->write_mutex);
}

void protocol_send_response(ProtocolAdapter *adapter, int id, const char *result_json)
{
    char buf[8192];
    int n = snprintf(buf, sizeof(buf),
                     "{\"jsonrpc\":\"2.0\",\"id\":%d,\"result\":%s}", id, result_json);
    if (n > 0 && (size_t)n < sizeof(buf))
        send_json_line(adapter, buf, (size_t)n);
}

void protocol_send_error(ProtocolAdapter *adapter, int id, int code, const char *message)
{
    char *escaped = protocol_json_escape(message, strlen(message));
    if (!escaped) escaped = strdup("Unknown error");

    char buf[4096];
    int n = snprintf(buf, sizeof(buf),
                     "{\"jsonrpc\":\"2.0\",\"id\":%d,\"error\":{\"code\":%d,\"message\":\"%s\"}}",
                     id, code, escaped);
    free(escaped);

    if (n > 0 && (size_t)n < sizeof(buf))
        send_json_line(adapter, buf, (size_t)n);
}

void protocol_send_notification(ProtocolAdapter *adapter, const char *params_json)
{
    char buf[16384];
    int n = snprintf(buf, sizeof(buf),
                     "{\"jsonrpc\":\"2.0\",\"method\":\"notify\",\"params\":%s}",
                     params_json);
    if (n > 0 && (size_t)n < sizeof(buf))
        send_json_line(adapter, buf, (size_t)n);
}

/* ===== JSON-RPC request parsing ===== */

int protocol_parse_request(const char *line, int *out_id,
                           char **out_method, char **out_params_json)
{
    *out_id = 0;
    *out_method = NULL;
    *out_params_json = NULL;

    cJSON *root = cJSON_Parse(line);
    if (!root) return -1;

    cJSON *jsonrpc = cJSON_GetObjectItem(root, "jsonrpc");
    if (!jsonrpc || !cJSON_IsString(jsonrpc) || strcmp(jsonrpc->valuestring, "2.0") != 0) {
        cJSON_Delete(root);
        return -1;
    }

    cJSON *id_obj = cJSON_GetObjectItem(root, "id");
    if (id_obj && cJSON_IsNumber(id_obj))
        *out_id = id_obj->valueint;

    cJSON *method_obj = cJSON_GetObjectItem(root, "method");
    if (!method_obj || !cJSON_IsString(method_obj)) {
        cJSON_Delete(root);
        return -1;
    }
    *out_method = strdup(method_obj->valuestring);

    cJSON *params = cJSON_GetObjectItem(root, "params");
    if (params) {
        *out_params_json = cJSON_PrintUnformatted(params);
    } else {
        *out_params_json = strdup("{}");
    }

    cJSON_Delete(root);
    return 0;
}

/* ===== AgentOutput callbacks → JSON-RPC notifications ===== */

static void proto_on_text(void *ud, const char *text, size_t len)
{
    ProtocolAdapter *adapter = (ProtocolAdapter *)ud;
    char *escaped = protocol_json_escape(text, len);
    if (!escaped) escaped = strdup("");

    char params[32768];
    int n = snprintf(params, sizeof(params),
                     "{\"type\":\"text\",\"content\":\"%s\"}", escaped);
    free(escaped);

    if (n > 0 && (size_t)n < sizeof(params))
        protocol_send_notification(adapter, params);
}

static void proto_on_thinking(void *ud, const char *text, size_t len)
{
    ProtocolAdapter *adapter = (ProtocolAdapter *)ud;
    char *escaped = protocol_json_escape(text, len);
    if (!escaped) escaped = strdup("");

    char params[32768];
    int n = snprintf(params, sizeof(params),
                     "{\"type\":\"thinking\",\"content\":\"%s\"}", escaped);
    free(escaped);

    if (n > 0 && (size_t)n < sizeof(params))
        protocol_send_notification(adapter, params);
}

static void proto_on_tool_call(void *ud, const char *name, const char *input_json)
{
    ProtocolAdapter *adapter = (ProtocolAdapter *)ud;
    char *escaped_name = protocol_json_escape(name, strlen(name));
    char *escaped_input = protocol_json_escape(input_json, strlen(input_json));
    if (!escaped_name) escaped_name = strdup("");
    if (!escaped_input) escaped_input = strdup("");

    char params[32768];
    int n = snprintf(params, sizeof(params),
                     "{\"type\":\"tool_call\",\"name\":\"%s\",\"input\":\"%s\"}",
                     escaped_name, escaped_input);
    free(escaped_name);
    free(escaped_input);

    if (n > 0 && (size_t)n < sizeof(params))
        protocol_send_notification(adapter, params);
}

static void proto_on_tool_result(void *ud, const char *result, bool truncated)
{
    ProtocolAdapter *adapter = (ProtocolAdapter *)ud;
    char *escaped = protocol_json_escape(result, strlen(result));
    if (!escaped) escaped = strdup("");

    char params[65536];
    int n = snprintf(params, sizeof(params),
                     "{\"type\":\"tool_result\",\"content\":\"%s\",\"truncated\":%s}",
                     escaped, truncated ? "true" : "false");
    free(escaped);

    if (n > 0 && (size_t)n < sizeof(params))
        protocol_send_notification(adapter, params);
}

static void proto_on_plan_update(void *ud, const AgentPlan *plan)
{
    ProtocolAdapter *adapter = (ProtocolAdapter *)ud;
    if (!plan || !plan->active) return;

    StringBuffer buf;
    sb_init(&buf);
    sb_append(&buf, "{\"type\":\"plan_update\",\"steps\":[", 31);

    for (int i = 0; i < plan->step_count; i++) {
        if (i > 0) sb_append(&buf, ",", 1);

        const PlanStep *s = &plan->steps[i];
        char *desc = protocol_json_escape(s->description, strlen(s->description));
        char *summary = s->result_summary
                            ? protocol_json_escape(s->result_summary, strlen(s->result_summary))
                            : strdup("");

        char entry[4096];
        int n = snprintf(entry, sizeof(entry),
                         "{\"index\":%d,\"description\":\"%s\",\"status\":\"%s\",\"summary\":\"%s\"}",
                         s->index,
                         desc ? desc : "",
                         s->status == STEP_PENDING     ? "pending"     :
                         s->status == STEP_IN_PROGRESS ? "in_progress" :
                         s->status == STEP_DONE        ? "done"        :
                         s->status == STEP_FAILED      ? "failed"      : "skipped",
                         summary ? summary : "");
        free(desc);
        free(summary);

        if (n > 0) sb_append(&buf, entry, (size_t)n);
    }

    sb_append(&buf, "]}", 2);

    if (buf.data)
        protocol_send_notification(adapter, buf.data);

    sb_free(&buf);
}

static void proto_on_reflection(void *ud, const char *reflection_text)
{
    ProtocolAdapter *adapter = (ProtocolAdapter *)ud;
    char *escaped = protocol_json_escape(reflection_text, strlen(reflection_text));
    if (!escaped) escaped = strdup("");

    char params[8192];
    int n = snprintf(params, sizeof(params),
                     "{\"type\":\"reflection\",\"content\":\"%s\"}", escaped);
    free(escaped);

    if (n > 0 && (size_t)n < sizeof(params))
        protocol_send_notification(adapter, params);
}

static void proto_on_status(void *ud, const char *status)
{
    ProtocolAdapter *adapter = (ProtocolAdapter *)ud;
    char *escaped = protocol_json_escape(status, strlen(status));
    if (!escaped) escaped = strdup("");

    char params[4096];
    int n = snprintf(params, sizeof(params),
                     "{\"type\":\"status\",\"content\":\"%s\"}", escaped);
    free(escaped);

    if (n > 0 && (size_t)n < sizeof(params))
        protocol_send_notification(adapter, params);
}

/* ===== Create AgentOutput wired to protocol adapter ===== */

AgentOutput protocol_adapter_create_output(ProtocolAdapter *adapter)
{
    AgentOutput out;
    memset(&out, 0, sizeof(out));

    out.user_data      = adapter;
    out.on_text        = proto_on_text;
    out.on_thinking    = proto_on_thinking;
    out.on_tool_call   = proto_on_tool_call;
    out.on_tool_result = proto_on_tool_result;
    out.on_plan_update = proto_on_plan_update;
    out.on_reflection  = proto_on_reflection;
    out.on_status      = proto_on_status;

    return out;
}
