#include "tool_engine.h"
#include <string.h>
#include <stdlib.h>

void tool_registry_init(ToolRegistry *reg) {
    reg->entries  = NULL;
    reg->count    = 0;
    reg->capacity = 0;
    memset(reg->tool_ctx.workspace, 0, sizeof(reg->tool_ctx.workspace));
}

void tool_registry_set_workspace(ToolRegistry *reg, const char *path) {
    strncpy(reg->tool_ctx.workspace, path, sizeof(reg->tool_ctx.workspace) - 1);
    reg->tool_ctx.workspace[sizeof(reg->tool_ctx.workspace) - 1] = '\0';
}

static int ensure_capacity(ToolRegistry *reg) {
    if (reg->count < reg->capacity) return 0;
    int new_cap = reg->capacity == 0 ? 16 : reg->capacity * 2;
    ToolEntry *new_entries = realloc(reg->entries, new_cap * sizeof(ToolEntry));
    if (!new_entries) return -1;
    reg->entries  = new_entries;
    reg->capacity = new_cap;
    return 0;
}

int tool_register(ToolRegistry *reg, const char *name,
                  const char *desc, const char *schema_json, ToolFunc handler) {
    if (ensure_capacity(reg) != 0) return -1;
    ToolEntry *e = &reg->entries[reg->count++];
    e->name         = strdup(name);
    e->description  = strdup(desc);
    e->param_schema = cJSON_Parse(schema_json);
    e->handler      = handler;
    e->available    = true;
    return 0;
}

int tool_register_module(ToolRegistry *reg, const ToolModule *mod) {
    for (int i = 0; i < mod->tool_count; i++) {
        const ToolDesc *td = &mod->tools[i];
        if (tool_register(reg, td->name, td->description,
                          td->param_schema, td->handler) != 0) {
            return -1;
        }
        if (td->check) {
            reg->entries[reg->count - 1].available = td->check();
        }
    }
    return 0;
}

ToolResult tool_execute(ToolRegistry *reg, const char *name, cJSON *params) {
    for (int i = 0; i < reg->count; i++) {
        if (strcmp(reg->entries[i].name, name) == 0) {
            return reg->entries[i].handler(name, params, &reg->tool_ctx);
        }
    }
    return tool_err("Error: Unknown tool");
}

void tool_registry_free(ToolRegistry *reg) {
    for (int i = 0; i < reg->count; i++) {
        free(reg->entries[i].name);
        free(reg->entries[i].description);
        cJSON_Delete(reg->entries[i].param_schema);
    }
    free(reg->entries);
    reg->entries  = NULL;
    reg->count    = 0;
    reg->capacity = 0;
}

int tool_registry_check(ToolRegistry *reg) {
    int available = 0;
    for (int i = 0; i < reg->count; i++) {
        if (reg->entries[i].available) available++;
    }
    return available;
}
