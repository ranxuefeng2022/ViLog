#include "ringbuf.h"
#include <stdlib.h>
#include <string.h>

void rb_init(RingBuffer *rb, int capacity) {
    rb->capacity = capacity;
    rb->slots = calloc(capacity, sizeof(OutputChunk));
    rb->head = 0;
    rb->tail = 0;
    rb->count = 0;
    pthread_mutex_init(&rb->mutex, NULL);
}

void rb_free(RingBuffer *rb) {
    for (int i = 0; i < rb->capacity; i++) {
        free(rb->slots[i].text);
    }
    free(rb->slots);
    pthread_mutex_destroy(&rb->mutex);
}

void rb_push(RingBuffer *rb, OutputTag tag, const char *text, size_t len) {
    pthread_mutex_lock(&rb->mutex);

    OutputChunk *slot = &rb->slots[rb->head];
    free(slot->text);
    slot->tag = tag;
    slot->text = malloc(len + 1);
    memcpy(slot->text, text, len);
    slot->text[len] = '\0';
    slot->len = len;

    rb->head = (rb->head + 1) % rb->capacity;
    if (rb->count == rb->capacity) {
        rb->tail = (rb->tail + 1) % rb->capacity;
    } else {
        rb->count++;
    }

    pthread_mutex_unlock(&rb->mutex);
}

bool rb_has_data(RingBuffer *rb) {
    pthread_mutex_lock(&rb->mutex);
    bool has = rb->count > 0;
    pthread_mutex_unlock(&rb->mutex);
    return has;
}

int rb_drain(RingBuffer *rb,
             void (*callback)(OutputTag, const char *, size_t, void *),
             void *ctx) {
    pthread_mutex_lock(&rb->mutex);
    int drained = 0;
    while (rb->count > 0) {
        OutputChunk *slot = &rb->slots[rb->tail];
        if (callback && slot->text) {
            callback(slot->tag, slot->text, slot->len, ctx);
        }
        free(slot->text);
        slot->text = NULL;
        slot->len = 0;
        rb->tail = (rb->tail + 1) % rb->capacity;
        rb->count--;
        drained++;
    }
    pthread_mutex_unlock(&rb->mutex);
    return drained;
}
