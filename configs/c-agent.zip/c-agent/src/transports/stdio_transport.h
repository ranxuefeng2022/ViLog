#ifndef STDIO_TRANSPORT_H
#define STDIO_TRANSPORT_H

#include "transports/transport.h"

TRANSPORT_MODULE_DECL(stdio_transport);

#endif
