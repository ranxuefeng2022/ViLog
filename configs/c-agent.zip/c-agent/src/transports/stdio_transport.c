#include "transports/stdio_transport.h"
#include "string_utils.h"

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===== Stdio transport internal data ===== */

typedef struct {
    pthread_mutex_t write_mutex;
} StdioData;

/* ===== Transport operations ===== */

static int stdio_init(Transport *t, const char *address)
{
    (void)t;
    (void)address;
    return 0;
}

static TransportReadResult stdio_read_message(Transport *t)
{
    (void)t;
    TransportReadResult result = {NULL, false};

    StringBuffer buf;
    sb_init(&buf);

    char tmp[4096];
    while (fgets(tmp, sizeof(tmp), stdin)) {
        size_t len = strlen(tmp);
        sb_append(&buf, tmp, len);
        if (len > 0 && tmp[len - 1] == '\n') {
            /* Strip trailing newline */
            buf.len--;
            buf.data[buf.len] = '\0';
            break;
        }
    }

    if (buf.data == NULL || buf.len == 0) {
        sb_free(&buf);
        result.eof = true;
        return result;
    }

    result.data = buf.data;
    return result;
}

static int stdio_write_message(Transport *t, const char *json, size_t len)
{
    StdioData *data = (StdioData *)t->user_data;

    pthread_mutex_lock(&data->write_mutex);
    fwrite(json, 1, len, stdout);
    fputc('\n', stdout);
    fflush(stdout);
    pthread_mutex_unlock(&data->write_mutex);

    return 0;
}

static void stdio_cleanup(Transport *t)
{
    StdioData *data = (StdioData *)t->user_data;
    if (data) {
        pthread_mutex_destroy(&data->write_mutex);
        free(data);
        t->user_data = NULL;
    }
}

/* ===== Module entry ===== */

static Transport *stdio_transport_create(void)
{
    Transport *t = calloc(1, sizeof(Transport));
    if (!t) return NULL;

    StdioData *data = calloc(1, sizeof(StdioData));
    if (!data) {
        free(t);
        return NULL;
    }
    pthread_mutex_init(&data->write_mutex, NULL);

    t->user_data = data;
    t->init = stdio_init;
    t->read_message = stdio_read_message;
    t->write_message = stdio_write_message;
    t->cleanup = stdio_cleanup;
    t->name = "stdio";
    return t;
}

TRANSPORT_MODULE(stdio_transport);
