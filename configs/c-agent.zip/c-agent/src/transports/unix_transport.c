#include "transports/unix_transport.h"
#include "string_utils.h"

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <errno.h>

/* ===== Unix socket internal data ===== */

typedef struct {
    int             listen_fd;
    int             client_fd;
    char            socket_path[256];
    StringBuffer    line_buf;
    pthread_mutex_t write_mutex;
} UnixData;

#define DEFAULT_SOCKET_PATH "/tmp/c-agent.sock"
#define RECV_BUF_SIZE 4096

/* ===== Transport operations ===== */

static int unix_init(Transport *t, const char *address)
{
    UnixData *data = (UnixData *)t->user_data;
    const char *path = (address && address[0]) ? address : DEFAULT_SOCKET_PATH;
    snprintf(data->socket_path, sizeof(data->socket_path), "%s", path);

    unlink(data->socket_path);

    data->listen_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (data->listen_fd < 0) {
        perror("unix socket create");
        return -1;
    }

    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    snprintf(addr.sun_path, sizeof(addr.sun_path), "%s", data->socket_path);

    if (bind(data->listen_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("unix socket bind");
        close(data->listen_fd);
        data->listen_fd = -1;
        return -1;
    }

    if (listen(data->listen_fd, 1) < 0) {
        perror("unix socket listen");
        close(data->listen_fd);
        data->listen_fd = -1;
        unlink(data->socket_path);
        return -1;
    }

    data->client_fd = -1;
    sb_init(&data->line_buf);

    fprintf(stderr, "[unix transport] listening on %s\n", data->socket_path);
    return 0;
}

static TransportReadResult unix_read_message(Transport *t)
{
    UnixData *data = (UnixData *)t->user_data;
    TransportReadResult result = {NULL, false};

    /* Accept a client if none connected */
    if (data->client_fd < 0) {
        data->client_fd = accept(data->listen_fd, NULL, NULL);
        if (data->client_fd < 0) {
            result.eof = true;
            return result;
        }
        fprintf(stderr, "[unix transport] client connected\n");
    }

    /* Read until we get a complete newline-terminated line */
    while (1) {
        /* Check if line_buf already has a newline */
        if (data->line_buf.data) {
            char *nl = memchr(data->line_buf.data, '\n', data->line_buf.len);
            if (nl) {
                size_t line_len = (size_t)(nl - data->line_buf.data);
                result.data = malloc(line_len + 1);
                if (!result.data) {
                    result.eof = true;
                    return result;
                }
                memcpy(result.data, data->line_buf.data, line_len);
                result.data[line_len] = '\0';

                /* Shift remaining data */
                size_t remaining = data->line_buf.len - line_len - 1;
                if (remaining > 0) {
                    memmove(data->line_buf.data, nl + 1, remaining);
                }
                data->line_buf.len = remaining;
                data->line_buf.data[remaining] = '\0';
                return result;
            }
        }

        /* Read more data from client */
        char tmp[RECV_BUF_SIZE];
        ssize_t n = recv(data->client_fd, tmp, sizeof(tmp), 0);
        if (n <= 0) {
            /* Client disconnected */
            close(data->client_fd);
            data->client_fd = -1;
            sb_free(&data->line_buf);
            sb_init(&data->line_buf);
            result.eof = true;
            return result;
        }
        sb_append(&data->line_buf, tmp, (size_t)n);
    }
}

static int unix_write_message(Transport *t, const char *json, size_t len)
{
    UnixData *data = (UnixData *)t->user_data;

    pthread_mutex_lock(&data->write_mutex);
    if (data->client_fd >= 0) {
        send(data->client_fd, json, len, MSG_NOSIGNAL);
        send(data->client_fd, "\n", 1, MSG_NOSIGNAL);
    }
    pthread_mutex_unlock(&data->write_mutex);

    return 0;
}

static void unix_cleanup(Transport *t)
{
    UnixData *data = (UnixData *)t->user_data;
    if (!data) return;

    if (data->client_fd >= 0) close(data->client_fd);
    if (data->listen_fd >= 0) close(data->listen_fd);
    if (data->socket_path[0]) unlink(data->socket_path);

    sb_free(&data->line_buf);
    pthread_mutex_destroy(&data->write_mutex);
    free(data);
    t->user_data = NULL;
}

/* ===== Module entry ===== */

static Transport *unix_transport_create(void)
{
    Transport *t = calloc(1, sizeof(Transport));
    if (!t) return NULL;

    UnixData *data = calloc(1, sizeof(UnixData));
    if (!data) {
        free(t);
        return NULL;
    }
    pthread_mutex_init(&data->write_mutex, NULL);
    data->listen_fd = -1;
    data->client_fd = -1;

    t->user_data = data;
    t->init = unix_init;
    t->read_message = unix_read_message;
    t->write_message = unix_write_message;
    t->cleanup = unix_cleanup;
    t->name = "unix";
    return t;
}

TRANSPORT_MODULE(unix_transport);
