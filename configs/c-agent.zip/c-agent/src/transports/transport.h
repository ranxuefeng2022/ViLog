#ifndef TRANSPORT_H
#define TRANSPORT_H

#include <stdbool.h>
#include <stddef.h>

/* ===== Transport read result ===== */

typedef struct {
    char *data;    /* heap-allocated JSON line, caller frees; NULL on error */
    bool  eof;     /* true if connection closed */
} TransportReadResult;

/* ===== Transport interface ===== */

typedef struct Transport Transport;

struct Transport {
    void *user_data;

    /* Initialize transport resources. address is transport-specific (NULL = default). */
    int  (*init)(Transport *t, const char *address);

    /* Read one complete JSON line (blocking). Caller frees result.data. */
    TransportReadResult (*read_message)(Transport *t);

    /* Write one complete JSON line (thread-safe). Appends newline. Returns 0 on success. */
    int  (*write_message)(Transport *t, const char *json, size_t len);

    /* Clean up transport resources. */
    void (*cleanup)(Transport *t);

    const char *name;
};

/* ===== Transport module pattern (mirrors TOOL_MODULE) ===== */

typedef struct {
    const char *name;
    Transport *(*create)(void);
} TransportModule;

#define TRANSPORT_MODULE(mod_name) \
    static TransportModule mod_name##_module = { \
        .name = #mod_name, \
        .create = mod_name##_create, \
    }; \
    const TransportModule *mod_name##_get_module(void) { return &mod_name##_module; }

#define TRANSPORT_MODULE_DECL(mod_name) \
    const TransportModule *mod_name##_get_module(void)

#endif
