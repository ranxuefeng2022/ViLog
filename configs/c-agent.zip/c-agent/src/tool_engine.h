#ifndef TOOL_ENGINE_H
#define TOOL_ENGINE_H

#include "cJSON.h"
#include "tools/tool_module.h"

typedef struct {
    char     *name;
    char     *description;
    cJSON    *param_schema;
    ToolFunc  handler;
    bool      available;
} ToolEntry;

typedef struct {
    ToolEntry  *entries;
    int         count;
    int         capacity;
    ToolContext tool_ctx;
} ToolRegistry;

void       tool_registry_init(ToolRegistry *reg);
void       tool_registry_set_workspace(ToolRegistry *reg, const char *path);
int        tool_register(ToolRegistry *reg, const char *name,
                         const char *desc, const char *schema_json, ToolFunc handler);
int        tool_register_module(ToolRegistry *reg, const ToolModule *mod);
ToolResult tool_execute(ToolRegistry *reg, const char *name, cJSON *params);
void       tool_registry_free(ToolRegistry *reg);
int        tool_registry_check(ToolRegistry *reg);

#endif
