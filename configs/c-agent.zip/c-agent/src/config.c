#include "config.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <linux/limits.h>

static ModelProfile g_profiles[MAX_PROFILES];
static int g_profile_count = 0;

static void free_profiles(void)
{
    for (int i = 0; i < g_profile_count; i++) {
        free(g_profiles[i].name);
        free(g_profiles[i].base_url);
        free(g_profiles[i].model);
        free(g_profiles[i].api_key);
    }
    g_profile_count = 0;
}

static char *json_str(cJSON *obj, const char *key)
{
    cJSON *item = cJSON_GetObjectItem(obj, key);
    return (item && item->valuestring) ? strdup(item->valuestring) : NULL;
}

static char *safe_strdup(const char *s)
{
    return s ? strdup(s) : NULL;
}

static int load_profiles_json(const char *path)
{
    FILE *f = fopen(path, "rb");
    if (!f) return -1;

    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *data = malloc(len + 1);
    if (!data) { fclose(f); return -1; }
    fread(data, 1, len, f);
    data[len] = '\0';
    fclose(f);

    cJSON *root = cJSON_Parse(data);
    free(data);
    if (!root) return -1;

    free_profiles();

    cJSON *arr = cJSON_GetObjectItem(root, "profiles");
    if (arr && cJSON_IsArray(arr)) {
        int count = cJSON_GetArraySize(arr);
        if (count > MAX_PROFILES) count = MAX_PROFILES;
        for (int i = 0; i < count; i++) {
            cJSON *item = cJSON_GetArrayItem(arr, i);
            g_profiles[i].name     = json_str(item, "name");
            g_profiles[i].base_url = json_str(item, "base_url");
            g_profiles[i].model    = json_str(item, "model");
            g_profiles[i].api_key  = json_str(item, "api_key");
            g_profile_count++;
        }
    }

    cJSON_Delete(root);
    return g_profile_count > 0 ? 0 : -1;
}

/* Fallback built-in profiles (no api_key) */
static void init_builtin_profiles(void)
{
    static const struct { const char *name, *base_url, *model, *env_key; } BUILTIN[] = {
        { "DeepSeek-V4",      "https://api.deepseek.com/anthropic",   "deepseek-v4-pro[1m]", "DEEPSEEK_API_KEY" },
        { "DeepSeek-V4-Flash","https://api.deepseek.com/anthropic",   "deepseek-v4-flash",   "DEEPSEEK_API_KEY" },
        { "GLM-5.1",          "https://open.bigmodel.cn/api/anthropic","glm-5.1",            "GLM_API_KEY" },
        { "GLM-4.7",          "https://open.bigmodel.cn/api/anthropic","glm-4.7",            "GLM_API_KEY" },
        { "Kimi-K2.5",        "https://api.moonshot.cn/anthropic",    "kimi-k2.5",           "KIMI_API_KEY" },
    };
    int count = sizeof(BUILTIN) / sizeof(BUILTIN[0]);
    if (count > MAX_PROFILES) count = MAX_PROFILES;
    for (int i = 0; i < count; i++) {
        const char *env_val = getenv(BUILTIN[i].env_key);
        g_profiles[i].name     = strdup(BUILTIN[i].name);
        g_profiles[i].base_url = strdup(BUILTIN[i].base_url);
        g_profiles[i].model    = strdup(BUILTIN[i].model);
        g_profiles[i].api_key  = env_val ? strdup(env_val) : NULL;
        g_profile_count++;
    }
}

int config_profile_count(void)
{
    return g_profile_count;
}

const ModelProfile *config_get_profile(int index)
{
    if (index < 0 || index >= g_profile_count) return NULL;
    return &g_profiles[index];
}

void config_switch_profile(AgentConfig *cfg, int index)
{
    if (index < 0 || index >= g_profile_count) return;
    const ModelProfile *p = &g_profiles[index];

    free(cfg->api_key);
    cfg->api_key   = safe_strdup(p->api_key);
    free(cfg->base_url);
    cfg->base_url  = safe_strdup(p->base_url);
    free(cfg->model);
    cfg->model     = safe_strdup(p->model);
    cfg->profile_index = index;
}

#define DEFAULT_TIMEOUT_MS  3000000
#define DEFAULT_WORKSPACE   "."

int config_load(AgentConfig *cfg, const char *json_path)
{
    memset(cfg, 0, sizeof(*cfg));

    cfg->timeout_ms   = DEFAULT_TIMEOUT_MS;
    cfg->workspace_dir = safe_strdup(DEFAULT_WORKSPACE);
    cfg->max_tokens   = 16384;

    /* Load profiles: explicit path → exe dir profiles.json → built-in fallback */
    int loaded = -1;
    if (json_path)
        loaded = load_profiles_json(json_path);
    if (loaded != 0) {
        /* Try profiles.json next to the executable */
        char exe_path[1024] = {0};
        ssize_t len = readlink("/proc/self/exe", exe_path, sizeof(exe_path) - 1);
        if (len > 0) {
            exe_path[len] = '\0';
            char *slash = strrchr(exe_path, '/');
            if (slash) {
                snprintf(slash + 1, sizeof(exe_path) - (slash + 1 - exe_path),
                         "profiles.json");
                loaded = load_profiles_json(exe_path);
            }
        }
    }
    if (loaded != 0)
        init_builtin_profiles();

    /* Default to first profile with a non-NULL api_key */
    int default_idx = 0;
    for (int i = 0; i < g_profile_count; i++) {
        if (g_profiles[i].api_key) {
            default_idx = i;
            break;
        }
    }
    config_switch_profile(cfg, default_idx);

    return 0;
}

void config_free(AgentConfig *cfg)
{
    free(cfg->api_key); free(cfg->base_url); free(cfg->model);
    free(cfg->workspace_dir);
    free_profiles();
}
