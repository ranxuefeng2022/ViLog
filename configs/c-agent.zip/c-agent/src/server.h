#ifndef SERVER_H
#define SERVER_H

#include "agent.h"

/* Run agent in server mode with the specified transport.
   Returns exit code (0 = normal shutdown). */
int run_server_mode(AgentSession *session, const char *transport_name);

#endif
