#include "server.h"
#include "protocol.h"
#include "transports/transport.h"
#include "transports/stdio_transport.h"
#include "transports/unix_transport.h"
#include "llm_client.h"
#include "tool_engine.h"
#include "string_utils.h"
#include "cJSON.h"

#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===== Transport registry ===== */

#define MAX_TRANSPORTS 8

static const TransportModule *g_transports[MAX_TRANSPORTS];
static int g_transport_count = 0;

static void init_transports(void)
{
    g_transports[g_transport_count++] = stdio_transport_get_module();
    g_transports[g_transport_count++] = unix_transport_get_module();
}

static const TransportModule *find_transport(const char *name)
{
    for (int i = 0; i < g_transport_count; i++) {
        if (strcmp(g_transports[i]->name, name) == 0)
            return g_transports[i];
        /* Match prefix: "stdio" matches "stdio_transport" */
        const char *mod = g_transports[i]->name;
        const char *underscore = strchr(mod, '_');
        if (underscore && (size_t)(underscore - mod) == strlen(name) &&
            strncmp(mod, name, (size_t)(underscore - mod)) == 0) {
            return g_transports[i];
        }
    }
    return NULL;
}

/* ===== Agent thread ===== */

enum { SRV_IDLE, SRV_RUNNING, SRV_DONE };

typedef struct {
    AgentSession *session;
    char         *user_msg;
    AgentResult   result;
    volatile int *agent_state;
} ServerThreadArg;

static void *server_agent_thread(void *arg)
{
    ServerThreadArg *a = (ServerThreadArg *)arg;
    a->result = agent_run_turn(a->session, a->user_msg);
    *a->agent_state = SRV_DONE;
    return NULL;
}

/* ===== Request dispatch ===== */

static void dispatch_chat_send(AgentSession *session, ProtocolAdapter *adapter,
                               cJSON *params, int req_id,
                               volatile int *agent_state,
                               pthread_t *agent_thread, ServerThreadArg *thread_arg)
{
    if (*agent_state == SRV_RUNNING) {
        protocol_send_error(adapter, req_id, -32000, "Agent is already running");
        return;
    }

    cJSON *msg_obj = cJSON_GetObjectItem(params, "message");
    if (!msg_obj || !cJSON_IsString(msg_obj) || !msg_obj->valuestring[0]) {
        protocol_send_error(adapter, req_id, -32602, "Missing or empty 'message' parameter");
        return;
    }

    /* Inject editor context into system prompt (replaces previous context) */
    cJSON *ctx_obj = cJSON_GetObjectItem(params, "context");
    if (ctx_obj && cJSON_IsString(ctx_obj) && ctx_obj->valuestring[0]) {
        free(session->ctx->system_prompt_context);
        session->ctx->system_prompt_context = strdup(ctx_obj->valuestring);
    }

    /* Wire AgentOutput to protocol adapter */
    AgentOutput output = protocol_adapter_create_output(adapter);
    output.cancel_flag = &session->cancelled;
    session->output = output;

    atomic_store(&session->cancelled, false);

    memset(thread_arg, 0, sizeof(*thread_arg));
    thread_arg->session = session;
    thread_arg->user_msg = strdup(msg_obj->valuestring);
    thread_arg->agent_state = agent_state;

    *agent_state = SRV_RUNNING;
    pthread_create(agent_thread, NULL, server_agent_thread, thread_arg);
}

static void dispatch_chat_cancel(AgentSession *session, ProtocolAdapter *adapter,
                                 int req_id, volatile int agent_state)
{
    if (agent_state != SRV_RUNNING) {
        protocol_send_error(adapter, req_id, -32001, "No agent turn in progress");
        return;
    }
    atomic_store(&session->cancelled, true);
    protocol_send_response(adapter, req_id, "{\"cancelled\":true}");
}

static void dispatch_session_status(AgentSession *session, ProtocolAdapter *adapter,
                                    int req_id, volatile int agent_state)
{
    const char *model = session->ctx->config->model;
    char result[512];
    int n = snprintf(result, sizeof(result),
                     "{\"status\":\"%s\",\"model\":\"%s\"}",
                     agent_state == SRV_RUNNING ? "running" : "idle",
                     model ? model : "unknown");
    if (n > 0 && (size_t)n < sizeof(result))
        protocol_send_response(adapter, req_id, result);
}

static void dispatch_config_list_models(ProtocolAdapter *adapter, int req_id)
{
    int count = config_profile_count();
    StringBuffer buf;
    sb_init(&buf);
    sb_append(&buf, "{\"models\":[", 11);

    for (int i = 0; i < count; i++) {
        if (i > 0) sb_append(&buf, ",", 1);
        const ModelProfile *p = config_get_profile(i);
        char *name_esc = protocol_json_escape(p->name ? p->name : "",
                                               p->name ? strlen(p->name) : 0);
        char *model_esc = protocol_json_escape(p->model ? p->model : "",
                                                p->model ? strlen(p->model) : 0);
        char entry[512];
        int n = snprintf(entry, sizeof(entry),
                         "{\"index\":%d,\"name\":\"%s\",\"model\":\"%s\",\"hasKey\":%s}",
                         i, name_esc ? name_esc : "", model_esc ? model_esc : "",
                         p->api_key ? "true" : "false");
        free(name_esc);
        free(model_esc);
        if (n > 0) sb_append(&buf, entry, (size_t)n);
    }

    sb_append(&buf, "]}", 2);
    protocol_send_response(adapter, req_id, buf.data ? buf.data : "{\"models\":[]}");
    sb_free(&buf);
}

static void dispatch_config_set_model(AgentSession *session, ProtocolAdapter *adapter,
                                       cJSON *params, int req_id)
{
    cJSON *idx = cJSON_GetObjectItem(params, "index");
    if (!idx || !cJSON_IsNumber(idx)) {
        protocol_send_error(adapter, req_id, -32602, "Missing 'index'");
        return;
    }
    int i = idx->valueint;
    if (i < 0 || i >= config_profile_count()) {
        protocol_send_error(adapter, req_id, -32602, "Invalid model index");
        return;
    }

    config_switch_profile(session->ctx->config, i);

    const ModelProfile *p = config_get_profile(i);
    char *name_esc = protocol_json_escape(p->name ? p->name : "",
                                           p->name ? strlen(p->name) : 0);
    char *model_esc = protocol_json_escape(p->model ? p->model : "",
                                            p->model ? strlen(p->model) : 0);
    char result[512];
    snprintf(result, sizeof(result),
             "{\"name\":\"%s\",\"model\":\"%s\"}",
             name_esc ? name_esc : "", model_esc ? model_esc : "");
    free(name_esc);
    free(model_esc);
    protocol_send_response(adapter, req_id, result);
}

static void dispatch_tools_list(ToolRegistry *reg, ProtocolAdapter *adapter, int req_id)
{
    StringBuffer buf;
    sb_init(&buf);
    sb_append(&buf, "{\"tools\":[", 10);

    for (int i = 0; i < reg->count; i++) {
        if (i > 0) sb_append(&buf, ",", 1);
        const ToolEntry *e = &reg->entries[i];

        char *name_esc = protocol_json_escape(e->name, strlen(e->name));
        char *desc_esc = protocol_json_escape(e->description, strlen(e->description));

        char entry[2048];
        int n = snprintf(entry, sizeof(entry),
                         "{\"name\":\"%s\",\"description\":\"%s\",\"available\":%s}",
                         name_esc ? name_esc : "",
                         desc_esc ? desc_esc : "",
                         e->available ? "true" : "false");
        free(name_esc);
        free(desc_esc);

        if (n > 0) sb_append(&buf, entry, (size_t)n);
    }

    sb_append(&buf, "]}", 2);
    protocol_send_response(adapter, req_id, buf.data ? buf.data : "{\"tools\":[]}");
    sb_free(&buf);
}

/* ===== Server main loop ===== */

static void send_done_notification(ProtocolAdapter *adapter, AgentResult result)
{
    const char *result_str;
    switch (result) {
    case AGENT_OK:                  result_str = "ok"; break;
    case AGENT_ERROR_API:           result_str = "api_error"; break;
    case AGENT_ERROR_CANCELLED:     result_str = "cancelled"; break;
    case AGENT_ERROR_MAX_ITERATIONS: result_str = "max_iterations"; break;
    default:                        result_str = "unknown"; break;
    }

    char params[128];
    int n = snprintf(params, sizeof(params),
                     "{\"type\":\"done\",\"result\":\"%s\"}", result_str);
    if (n > 0 && (size_t)n < sizeof(params))
        protocol_send_notification(adapter, params);
}

int run_server_mode(AgentSession *session, const char *transport_name)
{
    init_transports();

    const TransportModule *mod = find_transport(transport_name);
    if (!mod) {
        fprintf(stderr, "Unknown transport: %s\n", transport_name);
        fprintf(stderr, "Available transports:");
        for (int i = 0; i < g_transport_count; i++)
            fprintf(stderr, " %s", g_transports[i]->name);
        fprintf(stderr, "\n");
        return 1;
    }

    Transport *transport = mod->create();
    if (!transport) {
        fprintf(stderr, "Failed to create %s transport\n", transport_name);
        return 1;
    }

    if (transport->init(transport, NULL) != 0) {
        fprintf(stderr, "Failed to initialize %s transport\n", transport_name);
        transport->cleanup(transport);
        free(transport);
        return 1;
    }

    fprintf(stderr, "[c-agent server] transport=%s ready\n", transport_name);

    ProtocolAdapter adapter;
    protocol_adapter_init(&adapter, transport);

    volatile int agent_state = SRV_IDLE;
    pthread_t agent_thread = 0;
    ServerThreadArg thread_arg;

    /* ===== Main event loop ===== */
    while (1) {
        /* Check if agent thread finished */
        if (agent_state == SRV_DONE) {
            pthread_join(agent_thread, NULL);
            agent_thread = 0;

            send_done_notification(&adapter, thread_arg.result);

            free(thread_arg.user_msg);
            thread_arg.user_msg = NULL;
            agent_state = SRV_IDLE;
        }

        /* Block on next client request */
        TransportReadResult rr = transport->read_message(transport);
        if (rr.eof) {
            if (rr.data) free(rr.data);
            break;
        }
        if (!rr.data) continue;

        /* Parse JSON-RPC request */
        int req_id = 0;
        char *method = NULL;
        char *params_json = NULL;

        if (protocol_parse_request(rr.data, &req_id, &method, &params_json) != 0) {
            protocol_send_error(&adapter, 0, -32700, "Parse error");
            free(rr.data);
            continue;
        }
        free(rr.data);

        cJSON *params = cJSON_Parse(params_json);
        free(params_json);

        /* Dispatch request */
        if (strcmp(method, "chat/send") == 0) {
            dispatch_chat_send(session, &adapter, params, req_id,
                               &agent_state, &agent_thread, &thread_arg);
        } else if (strcmp(method, "chat/cancel") == 0) {
            dispatch_chat_cancel(session, &adapter, req_id, agent_state);
        } else if (strcmp(method, "session/reset") == 0) {
            agent_session_reset(session);
            protocol_send_response(&adapter, req_id, "{\"reset\":true}");
        } else if (strcmp(method, "session/status") == 0) {
            dispatch_session_status(session, &adapter, req_id, agent_state);
        } else if (strcmp(method, "tools/list") == 0) {
            dispatch_tools_list(session->reg, &adapter, req_id);
        } else if (strcmp(method, "config/list_models") == 0) {
            dispatch_config_list_models(&adapter, req_id);
        } else if (strcmp(method, "config/set_model") == 0) {
            dispatch_config_set_model(session, &adapter, params, req_id);
        } else {
            protocol_send_error(&adapter, req_id, -32601, "Method not found");
        }

        free(method);
        if (params) cJSON_Delete(params);
    }

    /* ===== Cleanup ===== */
    if (agent_state == SRV_RUNNING) {
        atomic_store(&session->cancelled, true);
        pthread_join(agent_thread, NULL);
        free(thread_arg.user_msg);
    }

    protocol_adapter_free(&adapter);
    transport->cleanup(transport);
    free(transport);

    return 0;
}
