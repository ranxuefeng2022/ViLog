#include "config.h"
#include "llm_client.h"
#include "tool_engine.h"
#include "tools/file_ops.h"
#include "tools/project_analyzer.h"
#include "tools/compiler.h"
#include "tools/math_ops.h"
#include "prompt.h"
#include "agent.h"
#include "app.h"
#include "server.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    bool server_mode = false;
    const char *transport_name = "stdio";
    const char *cfg_path = NULL;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--server") == 0) {
            server_mode = true;
        } else if (strcmp(argv[i], "--transport") == 0 && i + 1 < argc) {
            transport_name = argv[++i];
        } else if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            printf("Usage: %s [options] [config_path]\n", argv[0]);
            printf("Options:\n");
            printf("  --server              Run as protocol server\n");
            printf("  --transport <name>    Transport: stdio, unix (default: stdio)\n");
            printf("  --help                Show this help\n");
            printf("\nWithout --server: auto-detect TUI or stdio mode\n");
            return 0;
        } else {
            cfg_path = argv[i];
        }
    }

    AgentConfig cfg;
    if (config_load(&cfg, cfg_path) != 0) {
        fprintf(stderr, "Usage: %s [options] [config_path]\n", argv[0]);
        return 1;
    }

    ToolRegistry reg;
    tool_registry_init(&reg);
    init_modules();
    register_all_modules(&reg, cfg.workspace_dir);

    LLMContext *ctx = llm_context_create(&cfg);
    sync_tools_to_llm(ctx, &reg);

    char *system_prompt = build_system_prompt(&reg);
    ctx->system_prompt = system_prompt;

    AgentSession session;
    agent_session_init(&session, ctx, &reg);

    int result;
    if (server_mode) {
        result = run_server_mode(&session, transport_name);
    } else if (isatty(STDIN_FILENO) && isatty(STDOUT_FILENO)) {
        result = run_tui_mode(&session);
    } else {
        int available = tool_registry_check(&reg);
        fprintf(stderr, "Tool check: %d/%d available\n", available, reg.count);
        for (int i = 0; i < reg.count; i++) {
            fprintf(stderr, "  [%s] %s\n",
                   reg.entries[i].available ? "OK" : "  ",
                   reg.entries[i].name);
        }
        result = run_stdio_mode(&session);
    }

    agent_session_free(&session);
    tool_registry_free(&reg);
    llm_context_free(ctx);
    config_free(&cfg);
    free(system_prompt);
    return result;
}
