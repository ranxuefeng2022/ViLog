#ifndef APP_H
#define APP_H

#include "agent.h"

void init_modules(void);
void register_all_modules(ToolRegistry *reg, const char *workspace);
void sync_tools_to_llm(LLMContext *ctx, ToolRegistry *reg);

int run_stdio_mode(AgentSession *session);
int run_tui_mode(AgentSession *session);

#endif
