#ifndef LINUX_CMDS_H
#define LINUX_CMDS_H
#include "cJSON.h"
#include "tools/tool_module.h"

ToolResult tool_find(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_fd(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_grep(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_rg(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_sed(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_awk(const char *name, cJSON *params, const ToolContext *ctx);

TOOL_MODULE_DECL(linux_cmds_module);

#endif
