#ifndef COMPILER_H
#define COMPILER_H
#include "cJSON.h"
#include "tools/tool_module.h"

ToolResult tool_compile(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_run_tests(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_shell(const char *name, cJSON *params, const ToolContext *ctx);

TOOL_MODULE_DECL(compiler_module);

#endif
