#include "file_ops.h"
#include "string_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>

static void resolve_path(char *out, size_t size, const char *workspace, const char *path)
{
    if (path[0] == '/')
        snprintf(out, size, "%s", path);
    else
        snprintf(out, size, "%s/%s", workspace, path);
}

static void ensure_parent_dirs(const char *filepath) {
    char tmp[1024];
    strncpy(tmp, filepath, sizeof(tmp) - 1);
    tmp[sizeof(tmp) - 1] = '\0';
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            mkdir(tmp, 0755);
            *p = '/';
        }
    }
}

ToolResult tool_read_file(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    cJSON *p = cJSON_GetObjectItem(params, "path");
    if (!p || !p->valuestring)
        return tool_err("Error: 'path' parameter is required");

    char full[1024];
    resolve_path(full, sizeof(full), ctx->workspace, p->valuestring);

    FILE *f = fopen(full, "rb");
    if (!f)
        return tool_err("Error: File not found");

    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);

    long read_len = (len > 65536) ? 65536 : len;
    char *content = malloc(read_len + 1);
    fread(content, 1, read_len, f);
    content[read_len] = '\0';
    fclose(f);

    StringBuffer buf;
    sb_init(&buf);
    sb_append(&buf, "File: ", 6);
    sb_append(&buf, p->valuestring, strlen(p->valuestring));

    char size_info[64];
    snprintf(size_info, sizeof(size_info), " (%ld bytes)\n", len);
    sb_append(&buf, size_info, strlen(size_info));

    if (len > 65536) {
        sb_append(&buf, "[Showing first 64KB]\n", 21);
    }

    int lineno = 1;
    char lineno_buf[16];
    char *line = content;
    while (line && *line) {
        snprintf(lineno_buf, sizeof(lineno_buf), "%4d | ", lineno++);
        sb_append(&buf, lineno_buf, strlen(lineno_buf));
        char *nl = strchr(line, '\n');
        if (nl) {
            sb_append(&buf, line, (size_t)(nl - line + 1));
            line = nl + 1;
        } else {
            sb_append(&buf, line, strlen(line));
            sb_append(&buf, "\n", 1);
            break;
        }
    }

    free(content);
    return tool_ok(buf.data);
}

ToolResult tool_write_file(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    cJSON *p = cJSON_GetObjectItem(params, "path");
    cJSON *c = cJSON_GetObjectItem(params, "content");
    if (!p || !p->valuestring)
        return tool_err("Error: 'path' parameter is required");
    if (!c || !c->valuestring)
        return tool_err("Error: 'content' parameter is required");

    char full[1024];
    resolve_path(full, sizeof(full), ctx->workspace, p->valuestring);

    ensure_parent_dirs(full);

    FILE *f = fopen(full, "w");
    if (!f) {
        char err[256];
        snprintf(err, sizeof(err), "Error: Cannot write to %s (%s)", full, strerror(errno));
        return tool_err(err);
    }

    size_t written = fwrite(c->valuestring, 1, strlen(c->valuestring), f);
    fclose(f);

    char result[256];
    snprintf(result, sizeof(result), "OK: Written %zu bytes to %s", written, p->valuestring);
    return tool_ok(strdup(result));
}

ToolResult tool_edit_file(const char *name, cJSON *params, const ToolContext *ctx)
{
    (void)name;
    cJSON *p = cJSON_GetObjectItem(params, "path");
    cJSON *old_obj = cJSON_GetObjectItem(params, "old_string");
    cJSON *new_obj = cJSON_GetObjectItem(params, "new_string");

    if (!p || !p->valuestring)
        return tool_err("Error: 'path' is required");
    if (!old_obj || !old_obj->valuestring || !old_obj->valuestring[0])
        return tool_err("Error: 'old_string' is required");
    if (!new_obj || !new_obj->valuestring)
        return tool_err("Error: 'new_string' is required");

    char full[1024];
    resolve_path(full, sizeof(full), ctx->workspace, p->valuestring);

    FILE *f = fopen(full, "rb");
    if (!f)
        return tool_err("Error: File not found");

    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *content = malloc(len + 1);
    if (!content) { fclose(f); return tool_err("Error: Out of memory"); }
    fread(content, 1, len, f);
    content[len] = '\0';
    fclose(f);

    const char *old_str = old_obj->valuestring;
    const char *new_str = new_obj->valuestring;
    size_t old_len = strlen(old_str);
    size_t new_len = strlen(new_str);

    /* Find first occurrence */
    char *pos = strstr(content, old_str);
    if (!pos) {
        free(content);
        return tool_err("Error: old_string not found in file");
    }

    /* Check for duplicate matches */
    if (strstr(pos + old_len, old_str)) {
        free(content);
        return tool_err("Error: old_string matches multiple locations — provide more context");
    }

    /* Calculate line number of match */
    int line = 1;
    for (char *c = content; c < pos; c++) {
        if (*c == '\n') line++;
    }

    /* Build new content */
    size_t before = (size_t)(pos - content);
    size_t after = len - before - old_len;
    size_t new_size = before + new_len + after;
    char *out = malloc(new_size + 1);
    if (!out) { free(content); return tool_err("Error: Out of memory"); }

    memcpy(out, content, before);
    memcpy(out + before, new_str, new_len);
    memcpy(out + before + new_len, pos + old_len, after);
    out[new_size] = '\0';

    f = fopen(full, "w");
    if (!f) {
        char err[256];
        snprintf(err, sizeof(err), "Error: Cannot write %s (%s)", full, strerror(errno));
        free(content);
        free(out);
        return tool_err(err);
    }
    fwrite(out, 1, new_size, f);
    fclose(f);

    free(content);
    free(out);

    char result[256];
    snprintf(result, sizeof(result),
             "OK: Replaced at line %d (%zu→%zu bytes)", line, old_len, new_len);
    return tool_ok(strdup(result));
}

ToolResult tool_delete_file(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    cJSON *p = cJSON_GetObjectItem(params, "path");
    if (!p || !p->valuestring)
        return tool_err("Error: 'path' parameter is required");

    char full[1024];
    resolve_path(full, sizeof(full), ctx->workspace, p->valuestring);

    if (remove(full) != 0) {
        char err[256];
        snprintf(err, sizeof(err), "Error: Cannot delete %s (%s)", full, strerror(errno));
        return tool_err(err);
    }

    char result[256];
    snprintf(result, sizeof(result), "OK: Deleted %s", p->valuestring);
    return tool_ok(strdup(result));
}

ToolResult tool_list_files(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    const char *dir_path = ".";
    cJSON *p = cJSON_GetObjectItem(params, "path");
    if (p && p->valuestring) dir_path = p->valuestring;

    char full[1024];
    resolve_path(full, sizeof(full), ctx->workspace, dir_path);

    DIR *d = opendir(full);
    if (!d) {
        char err[256];
        snprintf(err, sizeof(err), "Error: Cannot open directory %s", full);
        return tool_err(err);
    }

    StringBuffer buf;
    sb_init(&buf);
    sb_append(&buf, "Directory: ", 11);
    sb_append(&buf, dir_path, strlen(dir_path));
    sb_append(&buf, "\n", 1);

    struct dirent *ent;
    while ((ent = readdir(d)) != NULL) {
        if (ent->d_name[0] == '.') continue;
        const char *dot = strrchr(ent->d_name, '.');
        if (dot && (strcmp(dot, ".o") == 0 || strcmp(dot, ".d") == 0))
            continue;
        const char *type_str = (ent->d_type == DT_DIR) ? "[DIR]  " : "[FILE] ";
        sb_append(&buf, type_str, 7);
        sb_append(&buf, ent->d_name, strlen(ent->d_name));
        sb_append(&buf, "\n", 1);
    }
    closedir(d);

    return tool_ok(buf.data);
}

ToolResult tool_search_in_file(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    cJSON *p = cJSON_GetObjectItem(params, "path");
    cJSON *pat = cJSON_GetObjectItem(params, "pattern");
    if (!p || !p->valuestring || !pat || !pat->valuestring)
        return tool_err("Error: 'path' and 'pattern' are required");

    char full[1024];
    resolve_path(full, sizeof(full), ctx->workspace, p->valuestring);

    FILE *f = fopen(full, "r");
    if (!f)
        return tool_err("Error: File not found");

    StringBuffer buf;
    sb_init(&buf);
    sb_append(&buf, "Search '", 8);
    sb_append(&buf, pat->valuestring, strlen(pat->valuestring));
    sb_append(&buf, "' in ", 5);
    sb_append(&buf, p->valuestring, strlen(p->valuestring));
    sb_append(&buf, ":\n", 2);

    char line[4096];
    int lineno = 0, matches = 0;
    while (fgets(line, sizeof(line), f)) {
        lineno++;
        if (strstr(line, pat->valuestring)) {
            matches++;
            char prefix[32];
            snprintf(prefix, sizeof(prefix), "  L%d: ", lineno);
            sb_append(&buf, prefix, strlen(prefix));
            line[strcspn(line, "\n")] = '\0';
            sb_append(&buf, line, strlen(line));
            sb_append(&buf, "\n", 1);
        }
    }
    fclose(f);

    if (matches == 0) {
        sb_append(&buf, "  (no matches found)\n", 21);
    } else {
        char summary[64];
        snprintf(summary, sizeof(summary), "Found %d matches\n", matches);
        sb_append(&buf, summary, strlen(summary));
    }

    return tool_ok(buf.data);
}

static const ToolDesc file_ops_tools[] = {
    {
        .name = "read_file",
        .description = "Read file with line numbers. Output capped at 64KB — "
                       "for large files use grep/search_in_file instead. "
                       "Returns '[Showing first 64KB]' if truncated.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"path\":{\"type\":\"string\",\"description\":\"Relative file path\"}"
            "},\"required\":[\"path\"]}",
        .handler = tool_read_file,
    },
    {
        .name = "write_file",
        .description = "Write complete file content. Creates parent directories "
                       "automatically. WARNING: overwrites entire file. "
                       "For editing existing files prefer edit_file to preserve formatting.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"path\":{\"type\":\"string\",\"description\":\"File path\"},"
            "\"content\":{\"type\":\"string\",\"description\":\"Complete file content\"}"
            "},\"required\":[\"path\",\"content\"]}",
        .handler = tool_write_file,
    },
    {
        .name = "edit_file",
        .description = "Replace exact old_string with new_string in a file. "
                       "Fails if old_string not found or matches multiple locations. "
                       "PREFERRED over write_file for edits — preserves surrounding code formatting.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"path\":{\"type\":\"string\",\"description\":\"File path\"},"
            "\"old_string\":{\"type\":\"string\",\"description\":\"Exact text to find (must be unique in file)\"},"
            "\"new_string\":{\"type\":\"string\",\"description\":\"Replacement text\"}"
            "},\"required\":[\"path\",\"old_string\",\"new_string\"]}",
        .handler = tool_edit_file,
    },
    {
        .name = "delete_file",
        .description = "Delete a file or empty directory.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"path\":{\"type\":\"string\",\"description\":\"File path\"}"
            "},\"required\":[\"path\"]}",
        .handler = tool_delete_file,
    },
    {
        .name = "list_files",
        .description = "List directory. Shows [DIR]/[FILE] prefix. "
                       "Filters dotfiles and .o/.d files. Default: workspace root.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"path\":{\"type\":\"string\",\"description\":\"Directory path\"}"
            "},\"required\":[]}",
        .handler = tool_list_files,
    },
    {
        .name = "search_in_file",
        .description = "Literal substring search in one file (NOT regex). "
                       "Shows matching lines with line numbers and total match count. "
                       "For regex or cross-file search use grep/rg/grep_project.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"path\":{\"type\":\"string\",\"description\":\"File to search\"},"
            "\"pattern\":{\"type\":\"string\",\"description\":\"Pattern\"}"
            "},\"required\":[\"path\",\"pattern\"]}",
        .handler = tool_search_in_file,
    },
};

TOOL_MODULE(file_ops_module, file_ops_tools);
