#ifndef EXEC_UTIL_H
#define EXEC_UTIL_H

#include <stddef.h>

typedef struct {
    char *output;
    int   exit_code;
} CmdResult;

CmdResult exec_capture(const char *cwd, char *const argv[], int timeout_secs);
void      append_truncated(void *buf, const char *output, size_t max_output);

#endif
