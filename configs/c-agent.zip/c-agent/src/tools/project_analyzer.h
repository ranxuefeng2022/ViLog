#ifndef PROJECT_ANALYZER_H
#define PROJECT_ANALYZER_H
#include "cJSON.h"
#include "tools/tool_module.h"

ToolResult tool_analyze_project(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_grep_project(const char *name, cJSON *params, const ToolContext *ctx);

TOOL_MODULE_DECL(project_analyzer_module);

#endif
