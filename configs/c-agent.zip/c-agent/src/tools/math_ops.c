#include "math_ops.h"
#include "string_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

static double get_number(const cJSON *obj, const char *key, double default_val) {
    cJSON *item = cJSON_GetObjectItem(obj, key);
    if (!item) return default_val;
    if (cJSON_IsNumber(item)) return item->valuedouble;
    return default_val;
}

static char *format_result(double value) {
    char buffer[256];
    if (fabs(value - (long long)value) < 1e-12) {
        snprintf(buffer, sizeof(buffer), "%.0f", value);
    } else {
        snprintf(buffer, sizeof(buffer), "%.10g", value);
    }
    return strdup(buffer);
}

ToolResult tool_math_add(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name; (void)ctx;
    double a = get_number(params, "a", 0.0);
    double b = get_number(params, "b", 0.0);
    return tool_ok(format_result(a + b));
}

ToolResult tool_math_subtract(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name; (void)ctx;
    double a = get_number(params, "a", 0.0);
    double b = get_number(params, "b", 0.0);
    return tool_ok(format_result(a - b));
}

ToolResult tool_math_multiply(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name; (void)ctx;
    double a = get_number(params, "a", 1.0);
    double b = get_number(params, "b", 1.0);
    return tool_ok(format_result(a * b));
}

ToolResult tool_math_divide(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name; (void)ctx;
    double a = get_number(params, "a", 0.0);
    double b = get_number(params, "b", 1.0);
    if (fabs(b) < 1e-15) {
        return tool_err("Error: Division by zero");
    }
    return tool_ok(format_result(a / b));
}

static const ToolDesc math_ops_tools[] = {
    {
        .name = "math_add",
        .description = "Add two numbers.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"a\":{\"type\":\"number\"},\"b\":{\"type\":\"number\"}"
            "},\"required\":[\"a\",\"b\"]}",
        .handler = tool_math_add,
    },
    {
        .name = "math_subtract",
        .description = "Subtract b from a.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"a\":{\"type\":\"number\"},\"b\":{\"type\":\"number\"}"
            "},\"required\":[\"a\",\"b\"]}",
        .handler = tool_math_subtract,
    },
    {
        .name = "math_multiply",
        .description = "Multiply two numbers.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"a\":{\"type\":\"number\"},\"b\":{\"type\":\"number\"}"
            "},\"required\":[\"a\",\"b\"]}",
        .handler = tool_math_multiply,
    },
    {
        .name = "math_divide",
        .description = "Divide a by b (b must be non-zero).",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"a\":{\"type\":\"number\"},\"b\":{\"type\":\"number\"}"
            "},\"required\":[\"a\",\"b\"]}",
        .handler = tool_math_divide,
    },
};

TOOL_MODULE(math_ops_module, math_ops_tools);
