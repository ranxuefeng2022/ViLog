#include "compiler.h"
#include "exec_util.h"
#include "string_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

ToolResult tool_compile(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    cJSON *cp = cJSON_GetObjectItem(params, "command");
    const char *cmd = (cp && cp->valuestring) ? cp->valuestring : "make 2>&1";

    char *argv[] = {"/bin/sh", "-c", (char *)cmd, NULL};
    CmdResult r = exec_capture(ctx->workspace, argv, 60);

    StringBuffer buf;
    sb_init(&buf);

    if (r.exit_code == 0) {
        sb_append(&buf, "COMPILE SUCCESS\n", 16);
    } else {
        sb_append(&buf, "COMPILE FAILED (exit code: ", 28);
        char code_str[16];
        snprintf(code_str, sizeof(code_str), "%d)\n", r.exit_code);
        sb_append(&buf, code_str, strlen(code_str));
    }

    append_truncated(&buf, r.output, 8192);
    free(r.output);

    return tool_ok(buf.data);
}

ToolResult tool_run_tests(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    cJSON *cp = cJSON_GetObjectItem(params, "command");
    const char *cmd = (cp && cp->valuestring) ? cp->valuestring : "make test 2>&1";

    char *argv[] = {"/bin/sh", "-c", (char *)cmd, NULL};
    CmdResult r = exec_capture(ctx->workspace, argv, 60);

    StringBuffer buf;
    sb_init(&buf);

    if (r.exit_code == 0) {
        sb_append(&buf, "TESTS PASSED\n", 13);
    } else {
        sb_append(&buf, "TESTS FAILED (exit code: ", 25);
        char code_str[16];
        snprintf(code_str, sizeof(code_str), "%d)\n", r.exit_code);
        sb_append(&buf, code_str, strlen(code_str));
    }

    append_truncated(&buf, r.output, 8192);
    free(r.output);

    return tool_ok(buf.data);
}

ToolResult tool_shell(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    cJSON *cp = cJSON_GetObjectItem(params, "command");
    if (!cp || !cp->valuestring)
        return tool_err("Missing 'command' parameter");

    cJSON *timeout_p = cJSON_GetObjectItem(params, "timeout");
    int timeout = (timeout_p && timeout_p->valueint > 0) ? timeout_p->valueint : 120;

    const char *shell = getenv("SHELL");
    if (!shell) shell = "/bin/sh";

    char *argv[] = {(char *)shell, "-c", cp->valuestring, NULL};
    CmdResult r = exec_capture(ctx->workspace, argv, timeout);

    StringBuffer buf;
    sb_init(&buf);

    char header[64];
    snprintf(header, sizeof(header), "Exit code: %d", r.exit_code);
    sb_append(&buf, header, strlen(header));

    if (r.exit_code == 124) {
        sb_append(&buf, " (timed out)", 12);
    }
    sb_append(&buf, "\n", 1);

    append_truncated(&buf, r.output, 32768);
    free(r.output);

    return tool_ok(buf.data);
}

static const ToolDesc compiler_tools[] = {
    {
        .name = "compile",
        .description = "Build project via shell. Default: 'make 2>&1'. "
                       "60s timeout, output capped at 8KB. Pass 'command' to override "
                       "(e.g. 'gcc main.c -o app'). If truncated, use shell to redirect "
                       "to file then read_file.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"command\":{\"type\":\"string\",\"description\":\"Build command\"}"
            "},\"required\":[]}",
        .handler = tool_compile,
    },
    {
        .name = "run_tests",
        .description = "Run test suite via shell. Default: 'make test 2>&1'. "
                       "60s timeout, output capped at 8KB. Pass 'command' to override.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"command\":{\"type\":\"string\",\"description\":\"Test command\"}"
            "},\"required\":[]}",
        .handler = tool_run_tests,
    },
    {
        .name = "shell",
        .description = "Execute any shell command with full Linux environment access. "
                       "Supports pipes, redirections, environment variables, and all system utilities. "
                       "You are a Linux user — use any command you need (apt, pip, npm, curl, git, etc.). "
                       "120s timeout (configurable via timeout param), output capped at 32KB.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"command\":{\"type\":\"string\",\"description\":\"Shell command to execute\"},"
            "\"timeout\":{\"type\":\"integer\",\"description\":\"Timeout in seconds (default: 120)\"}"
            "},\"required\":[\"command\"]}",
        .handler = tool_shell,
    },
};

TOOL_MODULE(compiler_module, compiler_tools);
