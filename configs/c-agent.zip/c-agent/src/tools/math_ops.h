#ifndef MATH_OPS_H
#define MATH_OPS_H
#include "cJSON.h"
#include "tools/tool_module.h"

ToolResult tool_math_add(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_math_subtract(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_math_multiply(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_math_divide(const char *name, cJSON *params, const ToolContext *ctx);

TOOL_MODULE_DECL(math_ops_module);

#endif
