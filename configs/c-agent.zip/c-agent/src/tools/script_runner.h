#ifndef SCRIPT_RUNNER_H
#define SCRIPT_RUNNER_H
#include "cJSON.h"
#include "tools/tool_module.h"

TOOL_MODULE_DECL(script_runner_module);

bool check_python(void);
bool check_node(void);

#endif
