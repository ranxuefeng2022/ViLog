#include "exec_util.h"
#include "string_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

CmdResult exec_capture(const char *cwd, char *const argv[], int timeout_secs) {
    int pipefd[2];
    if (pipe(pipefd) != 0)
        return (CmdResult){.output = strdup("Error: pipe failed"), .exit_code = -1};

    pid_t pid = fork();
    if (pid < 0) {
        close(pipefd[0]); close(pipefd[1]);
        return (CmdResult){.output = strdup("Error: fork failed"), .exit_code = -1};
    }

    if (pid == 0) {
        close(pipefd[0]);
        dup2(pipefd[1], STDOUT_FILENO);
        dup2(pipefd[1], STDERR_FILENO);
        close(pipefd[1]);
        if (cwd && chdir(cwd) != 0) _exit(126);
        if (timeout_secs > 0) alarm((unsigned)timeout_secs);
        execvp(argv[0], argv);
        _exit(127);
    }

    close(pipefd[1]);

    StringBuffer buf;
    sb_init(&buf);
    char rbuf[4096];
    ssize_t n;
    while ((n = read(pipefd[0], rbuf, sizeof(rbuf))) > 0)
        sb_append(&buf, rbuf, (size_t)n);
    close(pipefd[0]);

    int status;
    waitpid(pid, &status, 0);

    int code = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
    if (WIFSIGNALED(status) && WTERMSIG(status) == SIGALRM) code = 124;

    return (CmdResult){
        .output = buf.data ? buf.data : strdup(""),
        .exit_code = code
    };
}

void append_truncated(void *vbuf, const char *output, size_t max_output) {
    if (!output) return;
    StringBuffer *buf = (StringBuffer *)vbuf;
    size_t len = strlen(output);
    if (len > max_output) {
        sb_append(buf, output, max_output);
        sb_append(buf, "\n... (output truncated)", 23);
    } else {
        sb_append(buf, output, len);
    }
}
