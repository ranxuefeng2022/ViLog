#ifndef TOOL_MODULE_H
#define TOOL_MODULE_H

#include "cJSON.h"
#include <stdbool.h>
#include <stddef.h>
#include <string.h>

typedef struct {
    char workspace[1024];
} ToolContext;

typedef struct {
    bool  success;
    char *text;
} ToolResult;

static inline ToolResult tool_ok(char *text) {
    return (ToolResult){.success = true, .text = text};
}

static inline ToolResult tool_err(const char *msg) {
    return (ToolResult){.success = false, .text = strdup(msg)};
}

typedef ToolResult (*ToolFunc)(const char *tool_name, cJSON *params, const ToolContext *ctx);

typedef bool (*ToolCheck)(void);

typedef struct {
    const char *name;
    const char *description;
    const char *param_schema;
    ToolFunc    handler;
    ToolCheck   check;
} ToolDesc;

typedef struct {
    const char     *name;
    const ToolDesc *tools;
    int             tool_count;
} ToolModule;

#define TOOL_MODULE(mod_name, tool_array) \
    static const ToolModule mod_name = {   \
        .name       = #mod_name,           \
        .tools      = tool_array,          \
        .tool_count = sizeof(tool_array) / sizeof(tool_array[0]), \
    }; \
    const ToolModule *mod_name##_get_module(void) { return &mod_name; }

#define TOOL_MODULE_DECL(mod_name) \
    const ToolModule *mod_name##_get_module(void)

#endif
