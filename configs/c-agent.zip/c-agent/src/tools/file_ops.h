#ifndef FILE_OPS_H
#define FILE_OPS_H
#include "cJSON.h"
#include "tools/tool_module.h"

ToolResult tool_read_file(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_write_file(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_delete_file(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_list_files(const char *name, cJSON *params, const ToolContext *ctx);
ToolResult tool_search_in_file(const char *name, cJSON *params, const ToolContext *ctx);

TOOL_MODULE_DECL(file_ops_module);

#endif
