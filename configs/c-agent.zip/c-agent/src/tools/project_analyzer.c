#include "project_analyzer.h"
#include "string_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

typedef struct {
    int files, dirs, total_lines, total_bytes;
    StringBuffer tree_buf;
} ProjectStats;

static void scan_recursive(const char *base, const char *rel, ProjectStats *stats, int depth) {
    char full[2048];
    snprintf(full, sizeof(full), "%s/%s", base, rel);

    DIR *d = opendir(full);
    if (!d) return;

    struct dirent *ent;
    while ((ent = readdir(d)) != NULL) {
        if (ent->d_name[0] == '.') continue;

        const char *dot = strrchr(ent->d_name, '.');
        if (dot) {
            if (strcmp(dot, ".o") == 0 || strcmp(dot, ".d") == 0 ||
                strcmp(dot, ".a") == 0 || strcmp(dot, ".so") == 0)
                continue;
        }
        if (!dot && ent->d_type == DT_REG) {
            if (strcmp(ent->d_name, "c-agent") == 0 ||
                strcmp(ent->d_name, "demo") == 0 ||
                strcmp(ent->d_name, "a.out") == 0)
                continue;
        }

        char child[2048];
        snprintf(child, sizeof(child), "%s%s%s", rel, (rel[0] ? "/" : ""), ent->d_name);

        char child_full[2048];
        snprintf(child_full, sizeof(child_full), "%s/%s", base, child);

        struct stat st;
        if (stat(child_full, &st) != 0) continue;

        for (int i = 0; i < depth; i++) sb_append(&stats->tree_buf, "  ", 2);

        if (S_ISDIR(st.st_mode)) {
            stats->dirs++;
            sb_append(&stats->tree_buf, "[DIR] ", 6);
            sb_append(&stats->tree_buf, ent->d_name, strlen(ent->d_name));
            sb_append(&stats->tree_buf, "/\n", 2);
            scan_recursive(base, child, stats, depth + 1);
        } else {
            stats->files++;
            stats->total_bytes += st.st_size;

            FILE *f = fopen(child_full, "r");
            if (f) {
                int lines = 0;
                int ch;
                while ((ch = fgetc(f)) != EOF) { if (ch == '\n') lines++; }
                fclose(f);
                stats->total_lines += lines;
            }

            char size_str[32];
            snprintf(size_str, sizeof(size_str), " (%lld bytes)", (long long)st.st_size);
            sb_append(&stats->tree_buf, ent->d_name, strlen(ent->d_name));
            sb_append(&stats->tree_buf, size_str, strlen(size_str));
            sb_append(&stats->tree_buf, "\n", 1);
        }
    }
    closedir(d);
}

ToolResult tool_analyze_project(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    const char *path = ".";
    cJSON *p = cJSON_GetObjectItem(params, "path");
    if (p && p->valuestring) path = p->valuestring;

    char base[1024];
    if (path[0] == '/')
        snprintf(base, sizeof(base), "%s", path);
    else
        snprintf(base, sizeof(base), "%s/%s", ctx->workspace, path);

    ProjectStats stats = {0};
    sb_init(&stats.tree_buf);

    scan_recursive(base, "", &stats, 0);

    StringBuffer buf;
    sb_init(&buf);

    sb_append(&buf, "Project Analysis: ", 18);
    sb_append(&buf, path, strlen(path));
    sb_append(&buf, "\n", 1);

    char summary[256];
    snprintf(summary, sizeof(summary),
             "Files: %d | Dirs: %d | Lines: %d | Size: %d bytes\n\n",
             stats.files, stats.dirs, stats.total_lines, stats.total_bytes);
    sb_append(&buf, summary, strlen(summary));

    sb_append(&buf, stats.tree_buf.data, stats.tree_buf.len);
    free(stats.tree_buf.data);

    return tool_ok(buf.data);
}

ToolResult tool_grep_project(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    cJSON *pat = cJSON_GetObjectItem(params, "pattern");
    if (!pat || !pat->valuestring)
        return tool_err("Error: 'pattern' is required");

    cJSON *fp = cJSON_GetObjectItem(params, "file_pattern");
    const char *ext = (fp && fp->valuestring) ? fp->valuestring : NULL;

    /* Build argv — no shell interpolation */
    char *argv[10];
    int ai = 0;
    argv[ai++] = "grep";
    argv[ai++] = "-rn";
    if (ext) {
        argv[ai++] = "--include";
        char glob[256];
        snprintf(glob, sizeof(glob), "*%s", ext);
        argv[ai++] = glob;
    }
    argv[ai++] = pat->valuestring;
    argv[ai++] = ".";
    argv[ai] = NULL;

    int pipefd[2];
    if (pipe(pipefd) != 0)
        return tool_err("Error: pipe failed");

    pid_t pid = fork();
    if (pid < 0) {
        close(pipefd[0]); close(pipefd[1]);
        return tool_err("Error: fork failed");
    }

    if (pid == 0) {
        close(pipefd[0]);
        dup2(pipefd[1], STDOUT_FILENO);
        dup2(pipefd[1], STDERR_FILENO);
        close(pipefd[1]);
        chdir(ctx->workspace);
        execvp("grep", argv);
        _exit(127);
    }

    close(pipefd[1]);

    StringBuffer buf;
    sb_init(&buf);
    char rbuf[4096];
    ssize_t n;
    while ((n = read(pipefd[0], rbuf, sizeof(rbuf))) > 0) {
        sb_append(&buf, rbuf, (size_t)n);
    }
    close(pipefd[0]);

    int status;
    waitpid(pid, &status, 0);

    if (buf.data == NULL || buf.len == 0) {
        return tool_ok(strdup("No matches found"));
    }

    /* Trim to first 50 matches */
    int line_count = 0;
    size_t cut = 0;
    for (size_t i = 0; i < buf.len; i++) {
        if (buf.data[i] == '\n') {
            line_count++;
            if (line_count >= 50) { cut = i + 1; break; }
        }
    }
    if (cut > 0) buf.data[cut] = '\0';

    return tool_ok(buf.data);
}

static const ToolDesc project_analyzer_tools[] = {
    {
        .name = "analyze_project",
        .description = "Get recursive directory tree with file/directory counts, "
                       "total lines and bytes. Filters out binaries, .o/.a/.so files, "
                       "and dotfiles. Good starting point to understand project structure.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"path\":{\"type\":\"string\",\"description\":\"Project directory\"}"
            "},\"required\":[]}",
        .handler = tool_analyze_project,
    },
    {
        .name = "grep_project",
        .description = "Search text pattern across all project files using grep -rn. "
                       "Results capped at 50 matching lines. Optional file_pattern "
                       "filters by extension. For more control use the grep tool instead.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"pattern\":{\"type\":\"string\",\"description\":\"Search pattern\"},"
            "\"file_pattern\":{\"type\":\"string\",\"description\":\"File extension\"}"
            "},\"required\":[\"pattern\"]}",
        .handler = tool_grep_project,
    },
};

TOOL_MODULE(project_analyzer_module, project_analyzer_tools);
