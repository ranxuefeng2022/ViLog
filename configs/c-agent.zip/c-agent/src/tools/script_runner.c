#include "script_runner.h"
#include "exec_util.h"
#include "string_utils.h"
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <errno.h>

#define MAX_OUTPUT 16384
#define SCRIPTS_DIR ".scripts"

/* ===== Availability checks ===== */

static bool check_cmd_exists(const char *cmd) {
    char path_buf[4096];
    const char *path_env = getenv("PATH");
    if (!path_env) return false;
    strncpy(path_buf, path_env, sizeof(path_buf) - 1);
    path_buf[sizeof(path_buf) - 1] = '\0';
    char *dir = strtok(path_buf, ":");
    while (dir) {
        char full[4096 + 256];
        snprintf(full, sizeof(full), "%s/%s", dir, cmd);
        if (access(full, X_OK) == 0) return true;
        dir = strtok(NULL, ":");
    }
    return false;
}

bool check_python(void) {
    if (check_cmd_exists("python3")) return true;
    if (check_cmd_exists("python")) return true;
    return false;
}

bool check_node(void) {
    if (check_cmd_exists("node")) return true;
    return false;
}

/* ===== Helper: resolve python command ===== */

static const char *python_cmd(void) {
    if (check_cmd_exists("python3")) return "python3";
    if (check_cmd_exists("python")) return "python";
    return NULL;
}

/* ===== Helper: ensure .scripts dir ===== */

static void ensure_scripts_dir(const char *workspace) {
    char path[2048];
    snprintf(path, sizeof(path), "%s/%s", workspace, SCRIPTS_DIR);
    mkdir(path, 0755);
}

/* ===== Tool: run_python ===== */

ToolResult tool_run_python(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    const char *cmd = python_cmd();
    if (!cmd) return tool_err("Python is not installed");

    cJSON *code_p = cJSON_GetObjectItem(params, "code");
    if (!code_p || !code_p->valuestring)
        return tool_err("Missing 'code' parameter");

    const char *code = code_p->valuestring;

    char tmpfile[2048];
    snprintf(tmpfile, sizeof(tmpfile), "%s/%s/_tmp_py_%d.py",
             ctx->workspace, SCRIPTS_DIR, (int)getpid());

    FILE *f = fopen(tmpfile, "w");
    if (!f) return tool_err("Cannot create temp script file");
    fputs(code, f);
    fclose(f);

    char *argv[] = {(char *)cmd, tmpfile, NULL};
    CmdResult r = exec_capture(ctx->workspace, argv, 60);

    StringBuffer buf;
    sb_init(&buf);

    char header[32];
    snprintf(header, sizeof(header), "Exit code: %d\n", r.exit_code);
    sb_append(&buf, header, strlen(header));

    append_truncated(&buf, r.output, MAX_OUTPUT);
    free(r.output);
    unlink(tmpfile);

    return tool_ok(buf.data);
}

/* ===== Tool: run_node ===== */

ToolResult tool_run_node(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    if (!check_node()) return tool_err("Node.js is not installed");

    cJSON *code_p = cJSON_GetObjectItem(params, "code");
    if (!code_p || !code_p->valuestring)
        return tool_err("Missing 'code' parameter");

    const char *code = code_p->valuestring;

    char tmpfile[2048];
    snprintf(tmpfile, sizeof(tmpfile), "%s/%s/_tmp_node_%d.js",
             ctx->workspace, SCRIPTS_DIR, (int)getpid());

    FILE *f = fopen(tmpfile, "w");
    if (!f) return tool_err("Cannot create temp script file");
    fputs(code, f);
    fclose(f);

    char *argv[] = {"node", tmpfile, NULL};
    CmdResult r = exec_capture(ctx->workspace, argv, 60);

    StringBuffer buf;
    sb_init(&buf);

    char header[32];
    snprintf(header, sizeof(header), "Exit code: %d\n", r.exit_code);
    sb_append(&buf, header, strlen(header));

    append_truncated(&buf, r.output, MAX_OUTPUT);
    free(r.output);
    unlink(tmpfile);

    return tool_ok(buf.data);
}

/* ===== Tool: create_script ===== */

ToolResult tool_create_script(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    ensure_scripts_dir(ctx->workspace);

    cJSON *name_p = cJSON_GetObjectItem(params, "name");
    if (!name_p || !name_p->valuestring)
        return tool_err("Missing 'name' parameter");

    cJSON *code_p = cJSON_GetObjectItem(params, "code");
    if (!code_p || !code_p->valuestring)
        return tool_err("Missing 'code' parameter");

    cJSON *lang_p = cJSON_GetObjectItem(params, "language");
    const char *lang = (lang_p && lang_p->valuestring) ? lang_p->valuestring : "python";

    const char *ext;
    if (strcmp(lang, "python") == 0)       ext = ".py";
    else if (strcmp(lang, "javascript") == 0) ext = ".js";
    else if (strcmp(lang, "shell") == 0)    ext = ".sh";
    else                                    ext = ".sh";

    char path[2048];
    snprintf(path, sizeof(path), "%s/%s/%s%s",
             ctx->workspace, SCRIPTS_DIR, name_p->valuestring, ext);

    FILE *f = fopen(path, "w");
    if (!f) {
        char err[256];
        snprintf(err, sizeof(err), "Cannot create script: %s", path);
        return tool_err(err);
    }

    if (strcmp(lang, "shell") == 0) fputs("#!/bin/sh\n", f);
    else if (strcmp(lang, "python") == 0) fputs("#!/usr/bin/env python3\n", f);
    else if (strcmp(lang, "javascript") == 0) fputs("#!/usr/bin/env node\n", f);
    fputs(code_p->valuestring, f);
    fputc('\n', f);
    fclose(f);

    chmod(path, 0755);

    char msg[2200];
    snprintf(msg, sizeof(msg), "Script created: %s/%s%s", SCRIPTS_DIR, name_p->valuestring, ext);
    return tool_ok(strdup(msg));
}

/* ===== Tool: run_script ===== */

ToolResult tool_run_script(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    cJSON *name_p = cJSON_GetObjectItem(params, "name");
    if (!name_p || !name_p->valuestring)
        return tool_err("Missing 'name' parameter");

    cJSON *args_p = cJSON_GetObjectItem(params, "args");

    const char *exts[] = {".py", ".js", ".sh", NULL};
    char script_path[2048];
    bool found = false;

    for (int i = 0; exts[i]; i++) {
        snprintf(script_path, sizeof(script_path), "%s/%s/%s%s",
                 ctx->workspace, SCRIPTS_DIR, name_p->valuestring, exts[i]);
        if (access(script_path, X_OK) == 0) { found = true; break; }
    }

    if (!found) {
        char err[256];
        snprintf(err, sizeof(err), "Script not found: %s/%s", SCRIPTS_DIR, name_p->valuestring);
        return tool_err(err);
    }

    int argc = 0;
    char *argv[32];
    argv[argc++] = script_path;

    if (args_p && cJSON_IsArray(args_p)) {
        cJSON *arg;
        cJSON_ArrayForEach(arg, args_p) {
            if (arg->valuestring && argc < 31)
                argv[argc++] = arg->valuestring;
        }
    }
    argv[argc] = NULL;

    CmdResult r = exec_capture(ctx->workspace, argv, 60);

    StringBuffer buf;
    sb_init(&buf);

    char header[32];
    snprintf(header, sizeof(header), "Exit code: %d\n", r.exit_code);
    sb_append(&buf, header, strlen(header));

    append_truncated(&buf, r.output, MAX_OUTPUT);
    free(r.output);

    return tool_ok(buf.data);
}

/* ===== Tool: list_scripts ===== */

ToolResult tool_list_scripts(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name; (void)params;
    char dir_path[2048];
    snprintf(dir_path, sizeof(dir_path), "%s/%s", ctx->workspace, SCRIPTS_DIR);

    DIR *d = opendir(dir_path);
    if (!d) return tool_ok(strdup("No scripts directory."));

    StringBuffer buf;
    sb_init(&buf);

    struct dirent *ent;
    while ((ent = readdir(d))) {
        if (ent->d_name[0] == '_') continue;
        size_t nlen = strlen(ent->d_name);
        if (nlen >= 3 && strcmp(ent->d_name + nlen - 3, ".py") == 0) {
            sb_append(&buf, "  python: ", 10);
            sb_append(&buf, ent->d_name, nlen);
            sb_append(&buf, "\n", 1);
        } else if (nlen >= 3 && strcmp(ent->d_name + nlen - 3, ".js") == 0) {
            sb_append(&buf, "  node:   ", 10);
            sb_append(&buf, ent->d_name, nlen);
            sb_append(&buf, "\n", 1);
        } else if (nlen >= 3 && strcmp(ent->d_name + nlen - 3, ".sh") == 0) {
            sb_append(&buf, "  shell:  ", 10);
            sb_append(&buf, ent->d_name, nlen);
            sb_append(&buf, "\n", 1);
        }
    }
    closedir(d);

    if (!buf.data || buf.data[0] == '\0')
        return tool_ok(strdup("No scripts found."));

    return tool_ok(buf.data);
}

/* ===== Module definition ===== */

static const ToolDesc script_runner_tools[] = {
    {
        .name = "run_python",
        .description = "Execute Python code snippet. Writes to temp file, runs in "
                       "workspace, auto-deleted after. 60s timeout, 16KB output cap. "
                       "For reusable scripts use create_script + run_script.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"code\":{\"type\":\"string\",\"description\":\"Python code to execute\"}"
            "},\"required\":[\"code\"]}",
        .handler = tool_run_python,
        .check = check_python,
    },
    {
        .name = "run_node",
        .description = "Execute JavaScript code snippet. 60s timeout, 16KB output cap. "
                       "For reusable scripts use create_script + run_script.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"code\":{\"type\":\"string\",\"description\":\"JavaScript code to execute\"}"
            "},\"required\":[\"code\"]}",
        .handler = tool_run_node,
        .check = check_node,
    },
    {
        .name = "create_script",
        .description = "Create reusable script in .scripts/ directory. Auto-adds shebang line. "
                       "Languages: python, javascript, shell (default: python). "
                       "Sets executable permission. Overwrites existing.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"name\":{\"type\":\"string\",\"description\":\"Script name (without extension)\"},"
            "\"code\":{\"type\":\"string\",\"description\":\"Script source code\"},"
            "\"language\":{\"type\":\"string\",\"description\":\"Language: python, javascript, shell (default: python)\",\"enum\":[\"python\",\"javascript\",\"shell\"]}"
            "},\"required\":[\"name\",\"code\"]}",
        .handler = tool_create_script,
        .check = NULL,
    },
    {
        .name = "run_script",
        .description = "Run a script created by create_script. Looks up by name "
                       "(without extension) in .scripts/. Pass args array for arguments. "
                       "60s timeout, 16KB output cap.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"name\":{\"type\":\"string\",\"description\":\"Script name (without extension)\"},"
            "\"args\":{\"type\":\"array\",\"items\":{\"type\":\"string\"},\"description\":\"Arguments to pass to the script\"}"
            "},\"required\":[\"name\"]}",
        .handler = tool_run_script,
        .check = NULL,
    },
    {
        .name = "list_scripts",
        .description = "List all reusable scripts in .scripts/, grouped by language. "
                       "Shows python/node/shell scripts.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{},\"required\":[]}",
        .handler = tool_list_scripts,
        .check = NULL,
    },
};

TOOL_MODULE(script_runner_module, script_runner_tools);
