#include "linux_cmds.h"
#include "exec_util.h"
#include "string_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_OUTPUT 16384
#define MAX_MATCHES 50

static bool check_cmd_exists(const char *cmd) {
    char path_buf[4096];
    const char *path_env = getenv("PATH");
    if (!path_env) return false;
    strncpy(path_buf, path_env, sizeof(path_buf) - 1);
    path_buf[sizeof(path_buf) - 1] = '\0';
    char *dir = strtok(path_buf, ":");
    while (dir) {
        char full[4096 + 256];
        snprintf(full, sizeof(full), "%s/%s", dir, cmd);
        if (access(full, X_OK) == 0) return true;
        dir = strtok(NULL, ":");
    }
    return false;
}

static bool check_fd(void)  { return check_cmd_exists("fd"); }
static bool check_rg(void)  { return check_cmd_exists("rg"); }

static ToolResult exec_tool(const char *cwd, char *const argv[], int timeout_secs) {
    CmdResult r = exec_capture(cwd, argv, timeout_secs);

    StringBuffer buf;
    sb_init(&buf);

    char header[32];
    snprintf(header, sizeof(header), "Exit code: %d\n", r.exit_code);
    sb_append(&buf, header, strlen(header));

    append_truncated(&buf, r.output, MAX_OUTPUT);
    free(r.output);

    return tool_ok(buf.data);
}

static const char *get_str(cJSON *params, const char *key) {
    cJSON *item = cJSON_GetObjectItem(params, key);
    return (item && item->valuestring) ? item->valuestring : NULL;
}

static int get_int(cJSON *params, const char *key, int default_val) {
    cJSON *item = cJSON_GetObjectItem(params, key);
    return (item && item->valueint) ? item->valueint : default_val;
}

static bool get_bool(cJSON *params, const char *key) {
    cJSON *item = cJSON_GetObjectItem(params, key);
    return (item && item->type == cJSON_True);
}

ToolResult tool_find(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    const char *path = get_str(params, "path");
    const char *name_pattern = get_str(params, "name");
    const char *type = get_str(params, "type");
    int max_depth = get_int(params, "max_depth", -1);

    char *argv[16];
    int ai = 0;
    argv[ai++] = "find";
    argv[ai++] = (char *)(path ? path : ".");

    if (name_pattern) {
        argv[ai++] = "-name";
        argv[ai++] = (char *)name_pattern;
    }
    if (type) {
        argv[ai++] = "-type";
        argv[ai++] = (char *)type;
    }
    if (max_depth >= 0) {
        argv[ai++] = "-maxdepth";
        char depth_str[16];
        snprintf(depth_str, sizeof(depth_str), "%d", max_depth);
        argv[ai++] = strdup(depth_str);
    }
    argv[ai] = NULL;

    ToolResult r = exec_tool(ctx->workspace, argv, 15);

    if (max_depth >= 0) free(argv[ai - 1]);
    return r;
}

ToolResult tool_fd(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    const char *pattern = get_str(params, "pattern");
    const char *path = get_str(params, "path");
    const char *extension = get_str(params, "extension");
    const char *type = get_str(params, "type");
    int max_depth = get_int(params, "max_depth", -1);
    bool case_insensitive = get_bool(params, "case_insensitive");

    char *argv[16];
    int ai = 0;
    argv[ai++] = "fd";

    if (case_insensitive) argv[ai++] = "-i";
    if (extension) {
        argv[ai++] = "-e";
        argv[ai++] = (char *)extension;
    }
    if (type) {
        argv[ai++] = "-t";
        argv[ai++] = (char *)type;
    }
    if (max_depth >= 0) {
        argv[ai++] = "-d";
        char depth_str[16];
        snprintf(depth_str, sizeof(depth_str), "%d", max_depth);
        argv[ai++] = strdup(depth_str);
    }
    if (pattern) argv[ai++] = (char *)pattern;
    if (path) argv[ai++] = (char *)path;
    argv[ai] = NULL;

    ToolResult r = exec_tool(ctx->workspace, argv, 15);

    if (max_depth >= 0) {
        for (int i = 0; i < ai; i++) {
            if (argv[i] && argv[i][0] >= '0' && argv[i][0] <= '9' && i > 0 && strcmp(argv[i-1], "-d") == 0) {
                free(argv[i]);
                break;
            }
        }
    }
    return r;
}

ToolResult tool_grep(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    const char *pattern = get_str(params, "pattern");
    if (!pattern)
        return tool_err("Error: 'pattern' is required");

    const char *path = get_str(params, "path");
    const char *include = get_str(params, "include");
    bool ignore_case = get_bool(params, "ignore_case");
    bool line_number = !get_bool(params, "no_line_number");
    int max_count = get_int(params, "max_count", 0);

    char *argv[16];
    int ai = 0;
    argv[ai++] = "grep";
    argv[ai++] = "-r";
    if (ignore_case) argv[ai++] = "-i";
    if (line_number) argv[ai++] = "-n";
    if (include) {
        argv[ai++] = "--include";
        char glob[256];
        snprintf(glob, sizeof(glob), "*%s", include);
        argv[ai++] = strdup(glob);
    }
    if (max_count > 0) {
        argv[ai++] = "-m";
        char count_str[16];
        snprintf(count_str, sizeof(count_str), "%d", max_count);
        argv[ai++] = strdup(count_str);
    }
    argv[ai++] = (char *)pattern;
    argv[ai++] = (char *)(path ? path : ".");
    argv[ai] = NULL;

    ToolResult r = exec_tool(ctx->workspace, argv, 15);

    for (int i = 0; i < ai; i++) {
        if (argv[i] && argv[i][0] == '*' && i > 0 && strcmp(argv[i-1], "--include") == 0)
            free(argv[i]);
        if (argv[i] && argv[i][0] >= '0' && argv[i][0] <= '9' && i > 0 && strcmp(argv[i-1], "-m") == 0)
            free(argv[i]);
    }
    return r;
}

ToolResult tool_rg(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    const char *pattern = get_str(params, "pattern");
    if (!pattern)
        return tool_err("Error: 'pattern' is required");

    const char *path = get_str(params, "path");
    const char *glob = get_str(params, "glob");
    const char *type = get_str(params, "type");
    bool ignore_case = get_bool(params, "ignore_case");
    int max_count = get_int(params, "max_count", 0);

    char *argv[16];
    int ai = 0;
    argv[ai++] = "rg";
    argv[ai++] = "-n";
    if (ignore_case) argv[ai++] = "-i";
    if (glob) {
        argv[ai++] = "-g";
        argv[ai++] = (char *)glob;
    }
    if (type) {
        argv[ai++] = "-t";
        argv[ai++] = (char *)type;
    }
    if (max_count > 0) {
        argv[ai++] = "-m";
        char count_str[16];
        snprintf(count_str, sizeof(count_str), "%d", max_count);
        argv[ai++] = strdup(count_str);
    }
    argv[ai++] = (char *)pattern;
    if (path) argv[ai++] = (char *)path;
    argv[ai] = NULL;

    ToolResult r = exec_tool(ctx->workspace, argv, 15);

    for (int i = 0; i < ai; i++) {
        if (argv[i] && argv[i][0] >= '0' && argv[i][0] <= '9' && i > 0 && strcmp(argv[i-1], "-m") == 0)
            free(argv[i]);
    }
    return r;
}

ToolResult tool_sed(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    const char *path = get_str(params, "path");
    if (!path)
        return tool_err("Error: 'path' is required");

    const char *expression = get_str(params, "expression");
    if (!expression)
        return tool_err("Error: 'expression' is required");

    bool in_place = get_bool(params, "in_place");

    char *argv[8];
    int ai = 0;
    argv[ai++] = "sed";
    if (in_place) argv[ai++] = "-i";
    argv[ai++] = (char *)expression;
    argv[ai++] = (char *)path;
    argv[ai] = NULL;

    return exec_tool(ctx->workspace, argv, 15);
}

ToolResult tool_awk(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)name;
    const char *program = get_str(params, "program");
    if (!program)
        return tool_err("Error: 'program' is required");

    const char *path = get_str(params, "path");
    const char *field_separator = get_str(params, "field_separator");

    char *argv[8];
    int ai = 0;
    argv[ai++] = "awk";
    if (field_separator) {
        argv[ai++] = "-F";
        argv[ai++] = (char *)field_separator;
    }
    argv[ai++] = (char *)program;
    if (path) argv[ai++] = (char *)path;
    argv[ai] = NULL;

    return exec_tool(ctx->workspace, argv, 15);
}

static const ToolDesc linux_cmds_tools[] = {
    {
        .name = "find",
        .description = "find command wrapper. 15s timeout, output capped at 16KB. "
                       "For faster regex-based search use fd (if available).",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"path\":{\"type\":\"string\",\"description\":\"Search directory (default: .)\"},"
            "\"name\":{\"type\":\"string\",\"description\":\"Filename pattern (e.g. *.c)\"},"
            "\"type\":{\"type\":\"string\",\"description\":\"File type: f (file), d (dir), l (symlink)\"},"
            "\"max_depth\":{\"type\":\"integer\",\"description\":\"Maximum search depth\"}"
            "},\"required\":[]}",
        .handler = tool_find,
    },
    {
        .name = "fd",
        .description = "fd command wrapper — fast find with regex support. "
                       "15s timeout, output capped at 16KB. Supports extension, "
                       "type, depth, case-insensitive filters.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"pattern\":{\"type\":\"string\",\"description\":\"Search pattern (regex)\"},"
            "\"path\":{\"type\":\"string\",\"description\":\"Search directory\"},"
            "\"extension\":{\"type\":\"string\",\"description\":\"File extension (e.g. c, h)\"},"
            "\"type\":{\"type\":\"string\",\"description\":\"File type: f (file), d (dir), l (symlink)\"},"
            "\"max_depth\":{\"type\":\"integer\",\"description\":\"Maximum search depth\"},"
            "\"case_insensitive\":{\"type\":\"boolean\",\"description\":\"Case-insensitive search\"}"
            "},\"required\":[]}",
        .handler = tool_fd,
        .check = check_fd,
    },
    {
        .name = "grep",
        .description = "Recursive grep wrapper. 15s timeout, output capped at 16KB. "
                       "Supports include filter, ignore_case, max_count. "
                       "For faster regex search use rg (if available).",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"pattern\":{\"type\":\"string\",\"description\":\"Search pattern\"},"
            "\"path\":{\"type\":\"string\",\"description\":\"Search directory or file (default: .)\"},"
            "\"include\":{\"type\":\"string\",\"description\":\"File extension filter (e.g. .c)\"},"
            "\"ignore_case\":{\"type\":\"boolean\",\"description\":\"Case-insensitive search\"},"
            "\"no_line_number\":{\"type\":\"boolean\",\"description\":\"Omit line numbers\"},"
            "\"max_count\":{\"type\":\"integer\",\"description\":\"Max matches per file\"}"
            "},\"required\":[\"pattern\"]}",
        .handler = tool_grep,
    },
    {
        .name = "rg",
        .description = "ripgrep wrapper — fast grep with regex, glob, and type filters. "
                       "15s timeout, output capped at 16KB. Supports max_count to limit results.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"pattern\":{\"type\":\"string\",\"description\":\"Search pattern (regex)\"},"
            "\"path\":{\"type\":\"string\",\"description\":\"Search directory or file\"},"
            "\"glob\":{\"type\":\"string\",\"description\":\"Glob filter (e.g. *.c)\"},"
            "\"type\":{\"type\":\"string\",\"description\":\"File type (e.g. c, rust, py)\"},"
            "\"ignore_case\":{\"type\":\"boolean\",\"description\":\"Case-insensitive search\"},"
            "\"max_count\":{\"type\":\"integer\",\"description\":\"Max matches per file\"}"
            "},\"required\":[\"pattern\"]}",
        .handler = tool_rg,
        .check = check_rg,
    },
    {
        .name = "sed",
        .description = "sed wrapper. Use in_place=true to edit files directly. "
                       "15s timeout, output capped at 16KB.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"path\":{\"type\":\"string\",\"description\":\"Input file path\"},"
            "\"expression\":{\"type\":\"string\",\"description\":\"sed expression (e.g. s/old/new/g)\"},"
            "\"in_place\":{\"type\":\"boolean\",\"description\":\"Edit file in place\"}"
            "},\"required\":[\"path\",\"expression\"]}",
        .handler = tool_sed,
    },
    {
        .name = "awk",
        .description = "awk wrapper. 15s timeout, output capped at 16KB. "
                       "Use field_separator for CSV/TSV processing.",
        .param_schema =
            "{\"type\":\"object\",\"properties\":{"
            "\"program\":{\"type\":\"string\",\"description\":\"awk program (e.g. '{print $1}')\"},"
            "\"path\":{\"type\":\"string\",\"description\":\"Input file path\"},"
            "\"field_separator\":{\"type\":\"string\",\"description\":\"Field separator (e.g. , or :)\"}"
            "},\"required\":[\"program\"]}",
        .handler = tool_awk,
    },
};

TOOL_MODULE(linux_cmds_module, linux_cmds_tools);
