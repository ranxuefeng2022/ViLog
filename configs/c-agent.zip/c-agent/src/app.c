#include "app.h"
#include "command.h"
#include "config.h"
#include "prompt.h"
#include "ringbuf.h"
#include "tui.h"
#include "termbox2.h"
#include "tools/file_ops.h"
#include "tools/project_analyzer.h"
#include "tools/compiler.h"
#include "tools/math_ops.h"
#include "tools/linux_cmds.h"
#include "tools/script_runner.h"
#include "string_utils.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* ===== Module Registry ===== */

static const ToolModule *g_modules[6];

void init_modules(void) {
    g_modules[0] = file_ops_module_get_module();
    g_modules[1] = project_analyzer_module_get_module();
    g_modules[2] = compiler_module_get_module();
    g_modules[3] = math_ops_module_get_module();
    g_modules[4] = linux_cmds_module_get_module();
    g_modules[5] = script_runner_module_get_module();
}
#define MODULE_COUNT (sizeof(g_modules) / sizeof(g_modules[0]))

void register_all_modules(ToolRegistry *reg, const char *workspace) {
    tool_registry_set_workspace(reg, workspace);
    for (int i = 0; i < (int)MODULE_COUNT; i++) {
        tool_register_module(reg, g_modules[i]);
    }
}

void sync_tools_to_llm(LLMContext *ctx, ToolRegistry *reg) {
    for (int i = 0; i < reg->count; i++) {
        if (!reg->entries[i].available) continue;
        llm_register_tool(ctx, reg->entries[i].name,
                          reg->entries[i].description,
                          reg->entries[i].param_schema);
    }
}

/* ===== Stdio Mode ===== */

static void stdio_on_text(void *ud, const char *text, size_t len) {
    (void)ud; fwrite(text, 1, len, stdout);
}

static void stdio_on_tool_call(void *ud, const char *name, const char *input_json) {
    (void)ud; printf("\n  [Tool Call] %s(%s)\n", name, input_json);
}

static void stdio_on_tool_result(void *ud, const char *result, bool truncated) {
    (void)ud;
    printf("  [Result] ");
    if (truncated || strlen(result) > 200) printf("%.200s...\n", result);
    else printf("%s\n", result);
}

int run_stdio_mode(AgentSession *session) {
    char line[4096];
    while (fgets(line, sizeof(line), stdin)) {
        size_t len = strlen(line);
        if (len > 0 && line[len - 1] == '\n') line[--len] = '\0';
        if (len == 0) continue;
        if (strcmp(line, "exit") == 0 || strcmp(line, "quit") == 0) break;

        session->output.user_data = NULL;
        session->output.on_text = stdio_on_text;
        session->output.on_tool_call = stdio_on_tool_call;
        session->output.on_tool_result = stdio_on_tool_result;

        AgentResult result = agent_run_turn(session, line);
        if (result == AGENT_ERROR_API) fprintf(stderr, "[API Error]\n");
        else if (result == AGENT_ERROR_MAX_ITERATIONS) fprintf(stderr, "[Max iterations reached]\n");
        printf("\n");
    }
    return 0;
}

/* ===== TUI Mode — AppContext + Event Handlers ===== */

enum { STATE_IDLE, STATE_STREAMING, STATE_DONE };

typedef struct {
    AgentSession *session;
    char         *user_msg;
    AgentResult   result;
    volatile int *agent_state;
} AgentThreadArg;

typedef struct {
    AgentSession *session;
    TUIState     *tui;
    RingBuffer   *ring;

    volatile int  agent_state;
    pthread_t     agent_thread;
    AgentThreadArg thread_arg;

    bool          paste_mode;
    CommandPopup  cmd_popup;
    int           sub_popup_mode;
    int           sub_popup_selected;

    long long     last_ctrl_c;
    bool          running;
    bool          clear_on_drain;   /* clear startup tool check on first message */
    bool          first_message;    /* true until first message is sent */
} AppContext;

/* ----- Ring buffer callbacks ----- */

static void on_stream_text(void *ud, const char *text, size_t len) {
    rb_push((RingBuffer *)ud, TAG_AGENT, text, len);
}

static void on_stream_thinking(void *ud, const char *text, size_t len) {
    rb_push((RingBuffer *)ud, TAG_THINKING, text, len);
}

static void tui_on_tool_call(void *ud, const char *name, const char *input_json) {
    RingBuffer *ring = (RingBuffer *)ud;
    cJSON *input = cJSON_Parse(input_json);
    cJSON *cmd  = input ? cJSON_GetObjectItem(input, "command") : NULL;
    cJSON *path = input ? cJSON_GetObjectItem(input, "path") : NULL;
    cJSON *pat  = input ? cJSON_GetObjectItem(input, "pattern") : NULL;

    char *header = NULL;
    int hlen;
    if (cmd && cmd->valuestring) {
        hlen = asprintf(&header, "$ %s\n", cmd->valuestring);
    } else if (path && path->valuestring) {
        if (pat && pat->valuestring)
            hlen = asprintf(&header, "[%s] %s / %s\n", name, path->valuestring, pat->valuestring);
        else
            hlen = asprintf(&header, "[%s] %s\n", name, path->valuestring);
    } else {
        hlen = asprintf(&header, "[%s] %s\n", name, input_json);
    }
    if (hlen > 0) rb_push(ring, TAG_TOOL_CALL, header, hlen);
    free(header);
    cJSON_Delete(input);
}

static void tui_on_tool_result(void *ud, const char *result, bool truncated) {
    RingBuffer *ring = (RingBuffer *)ud;
    int result_len = (int)strlen(result);
    if (truncated || result_len > 2000) {
        rb_push(ring, TAG_TOOL_RESULT, result, result_len > 2000 ? 2000 : result_len);
        rb_push(ring, TAG_TOOL_RESULT, "\n... (truncated)\n", 18);
    } else {
        rb_push(ring, TAG_TOOL_RESULT, result, result_len);
        rb_push(ring, TAG_TOOL_RESULT, "\n", 1);
    }
}

static void tui_on_status(void *ud, const char *status) {
    rb_push((RingBuffer *)ud, TAG_STATUS, status, strlen(status));
}

static void *agent_thread_func(void *arg) {
    AgentThreadArg *a = (AgentThreadArg *)arg;
    a->result = agent_run_turn(a->session, a->user_msg);
    *a->agent_state = STATE_DONE;
    return NULL;
}

static long long time_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

/* ----- Agent completion ----- */

static void process_agent_done(AppContext *c) {
    if (c->agent_state != STATE_DONE) return;

    pthread_join(c->agent_thread, NULL);
    c->agent_thread = 0;
    free(c->thread_arg.user_msg);
    c->thread_arg.user_msg = NULL;

    tui_consume_output(c->tui);
    tui_flush(c->tui);
    c->agent_state = STATE_IDLE;
    c->tui->agent_busy = false;
    c->tui->response_start_ms = 0;

    const char *ready = "Ready | /:commands Ctrl+P:model Ctrl+V:paste ESC:interrupt";
    if (c->thread_arg.result == AGENT_ERROR_CANCELLED) {
        rb_push(c->ring, TAG_SYSTEM, "\n[Interrupted]\n", 14);
    } else if (c->thread_arg.result == AGENT_ERROR_API) {
        rb_push(c->ring, TAG_ERROR, "\n[API Error]\n", 13);
    } else if (c->thread_arg.result == AGENT_ERROR_MAX_ITERATIONS) {
        rb_push(c->ring, TAG_SYSTEM, "\n[Max iterations reached]\n", 26);
    }
    tui_set_state_text(c->tui, "%s", ready);
}

/* ----- Render frame with popups ----- */

static void render_frame(AppContext *c) {
    tui_render(c->tui);

    /* Compute input row for popup positioning */
    int total_il = 0;
    for (int i = 0; i < c->tui->input.len; i++)
        if (c->tui->input.buf[i] == '\n') total_il++;
    total_il++;
    int max_ir = (c->tui->height - 4) / 2;
    if (max_ir < 1) max_ir = 1;
    int ir = total_il > max_ir ? max_ir : total_il;
    int out_rows = c->tui->height - 2 - ir - 2;
    if (out_rows < 3) out_rows = 3;
    int input_top = out_rows + 1;

    if (c->cmd_popup.active) {
        char labels[16][48];
        char scs[16][8];
        const char *label_ptrs[16];
        const char *sc_ptrs[16];
        for (int i = 0; i < c->cmd_popup.match_count; i++) {
            const SlashCommandDef *def = command_def(c->cmd_popup.match_indices[i]);
            snprintf(labels[i], sizeof(labels[i]), " /%-8s %s", def->name, def->desc);
            if (def->shortcut) snprintf(scs[i], sizeof(scs[i]), "[%s]", def->shortcut);
            else scs[i][0] = '\0';
            label_ptrs[i] = labels[i];
            sc_ptrs[i] = scs[i];
        }
        tui_render_menu_popup(c->tui, input_top, label_ptrs, sc_ptrs,
                              c->cmd_popup.match_count, c->cmd_popup.selected);
        tb_set_cursor(-1, -1);
    } else if (c->sub_popup_mode == SUB_THEME) {
        const char *names[16];
        for (int i = 0; i < tui_theme_count() && i < 16; i++)
            names[i] = tui_theme_name(i);
        tui_render_list_popup(c->tui, input_top, "Theme",
                              names, tui_theme_count(), c->sub_popup_selected);
        tb_set_cursor(-1, -1);
    } else if (c->sub_popup_mode == SUB_MODEL) {
        const char *names[16];
        int cnt = config_profile_count();
        for (int i = 0; i < cnt && i < 16; i++)
            names[i] = config_get_profile(i)->name;
        tui_render_list_popup(c->tui, input_top, "Model",
                              names, cnt, c->sub_popup_selected);
        tb_set_cursor(-1, -1);
    } else if (c->sub_popup_mode == SUB_SHORTCUTS) {
        int cnt = shortcut_count();
        char items[32][64];
        const char *item_ptrs[32];
        for (int i = 0; i < cnt && i < 32; i++) {
            const ShortcutInfo *si = shortcut_get(i);
            snprintf(items[i], sizeof(items[i]), " %-14s %s", si->key, si->desc);
            item_ptrs[i] = items[i];
        }
        tui_render_list_popup(c->tui, input_top, "Shortcuts",
                              item_ptrs, cnt, -1);
        tb_set_cursor(-1, -1);
    }

    tb_present();
}

/* ----- Key handlers ----- */

static bool handle_ctrl_c(AppContext *c) {
    long long now = time_ms();
    if (c->agent_state == STATE_STREAMING) {
        atomic_store(&c->session->cancelled, true);
        rb_push(c->ring, TAG_SYSTEM, "\n[Interrupting...]\n", 19);
    } else {
        if (now - c->last_ctrl_c < 1000) { c->running = false; return false; }
        c->last_ctrl_c = now;
        tui_set_state_text(c->tui, "Press Ctrl+C again to quit");
    }
    return true;
}

static bool handle_esc(AppContext *c) {
    if (c->sub_popup_mode != SUB_NONE) { c->sub_popup_mode = SUB_NONE; return true; }
    if (c->cmd_popup.active) {
        c->cmd_popup.active = false;
        tui_input_backspace(c->tui);
        return true;
    }
    if (c->agent_state == STATE_STREAMING) {
        atomic_store(&c->session->cancelled, true);
        rb_push(c->ring, TAG_SYSTEM, "\n[Interrupting...]\n", 19);
    }
    c->paste_mode = false;
    c->tui->paste_mode = false;
    return true;
}

static bool handle_sub_popup(AppContext *c, struct tb_event *ev) {
    if (c->sub_popup_mode == SUB_SHORTCUTS) {
        c->sub_popup_mode = SUB_NONE;
        return true;
    }
    if (ev->key == TB_KEY_ARROW_UP) {
        if (c->sub_popup_selected > 0) c->sub_popup_selected--;
        return true;
    }
    if (ev->key == TB_KEY_ARROW_DOWN) {
        int mx = (c->sub_popup_mode == SUB_THEME) ? tui_theme_count() - 1 : config_profile_count() - 1;
        if (c->sub_popup_selected < mx) c->sub_popup_selected++;
        return true;
    }
    if (ev->key == TB_KEY_ENTER) {
        if (c->sub_popup_mode == SUB_THEME) {
            c->tui->theme_index = c->sub_popup_selected;
            tui_set_state_text(c->tui, "Theme: %s", tui_theme_name(c->tui->theme_index));
        } else if (c->sub_popup_mode == SUB_MODEL) {
            config_switch_profile(c->session->ctx->config, c->sub_popup_selected);
            const ModelProfile *mp = config_get_profile(c->sub_popup_selected);
            snprintf(c->tui->model_name, sizeof(c->tui->model_name), "%s", mp->name);
            tui_set_state_text(c->tui, "Model: %s", mp->name);
        }
        c->sub_popup_mode = SUB_NONE;
        return true;
    }
    return true; /* consume all keys while sub-popup is open */
}

static bool handle_cmd_popup(AppContext *c, struct tb_event *ev) {
    if (ev->key == TB_KEY_ARROW_UP) {
        if (c->cmd_popup.selected > 0) c->cmd_popup.selected--;
        return true;
    }
    if (ev->key == TB_KEY_ARROW_DOWN) {
        if (c->cmd_popup.selected < c->cmd_popup.match_count - 1) c->cmd_popup.selected++;
        return true;
    }
    if (ev->key == TB_KEY_ENTER) {
        if (c->cmd_popup.match_count > 0) {
            const SlashCommandDef *def = command_def(c->cmd_popup.match_indices[c->cmd_popup.selected]);
            c->cmd_popup.active = false;
            c->tui->input.len = 0;
            c->tui->input.cursor = 0;
            c->tui->input.buf[0] = '\0';
            if (def->id == CMD_THEME)    { c->sub_popup_mode = SUB_THEME; c->sub_popup_selected = c->tui->theme_index; }
            if (def->id == CMD_MODEL)    { c->sub_popup_mode = SUB_MODEL; c->sub_popup_selected = c->session->ctx->config->profile_index; }
            if (def->id == CMD_SHORTCUTS) { c->sub_popup_mode = SUB_SHORTCUTS; }
        }
        return true;
    }
    if (ev->key == TB_KEY_BACKSPACE || ev->key == TB_KEY_BACKSPACE2) {
        tui_input_backspace(c->tui);
        if (c->tui->input.len == 0 || c->tui->input.buf[0] != '/')
            c->cmd_popup.active = false;
        else
            cmd_update_matches(&c->cmd_popup, c->tui->input.buf + 1);
        return true;
    }
    if (ev->ch && ev->ch != '/') {
        /* Check shortcut match */
        for (int si = 0; si < c->cmd_popup.match_count; si++) {
            const SlashCommandDef *def = command_def(c->cmd_popup.match_indices[si]);
            if (def->shortcut && ev->ch == (uint32_t)def->shortcut[0]) {
                c->cmd_popup.active = false;
                c->tui->input.len = 0;
                c->tui->input.cursor = 0;
                c->tui->input.buf[0] = '\0';
                if (def->id == CMD_THEME)    { c->sub_popup_mode = SUB_THEME; c->sub_popup_selected = c->tui->theme_index; }
                if (def->id == CMD_MODEL)    { c->sub_popup_mode = SUB_MODEL; c->sub_popup_selected = c->session->ctx->config->profile_index; }
                if (def->id == CMD_SHORTCUTS) { c->sub_popup_mode = SUB_SHORTCUTS; }
                return true;
            }
        }
        tui_input_insert(c->tui, ev->ch);
        cmd_update_matches(&c->cmd_popup, c->tui->input.buf + 1);
        return true;
    }
    return true;
}

static void launch_agent(AppContext *c, char *text) {
    if (c->tui->turn_number > 0)
        rb_push(c->ring, TAG_SEPARATOR, "\n", 1);

    int ulen = strlen(text) + 16;
    char *user_line = malloc(ulen);
    snprintf(user_line, ulen, "\xF0\x9F\x91\xA4 %s\n", text);
    rb_push(c->ring, TAG_USER, user_line, strlen(user_line));
    free(user_line);

    c->tui->turn_number++;
    c->tui->response_start_ms = time_ms();
    c->tui->needs_agent_label = true;

    c->session->output.user_data = c->ring;
    c->session->output.on_text = on_stream_text;
    c->session->output.on_thinking = on_stream_thinking;
    c->session->output.on_tool_call = tui_on_tool_call;
    c->session->output.on_tool_result = tui_on_tool_result;
    c->session->output.on_status = tui_on_status;
    c->session->output.cancel_flag = &c->session->cancelled;
    atomic_store(&c->session->cancelled, false);

    c->thread_arg = (AgentThreadArg){0};
    c->thread_arg.session = c->session;
    c->thread_arg.user_msg = text;
    c->thread_arg.agent_state = &c->agent_state;

    c->agent_state = STATE_STREAMING;
    c->tui->agent_busy = true;

    pthread_create(&c->agent_thread, NULL, agent_thread_func, &c->thread_arg);
    tui_set_state_text(c->tui, "Waiting for response... | ESC:interrupt");
}

static bool handle_enter(AppContext *c) {
    bool continuation = (c->tui->input.len > 0 && c->tui->input.buf[c->tui->input.len - 1] == '\\');

    if (c->paste_mode || continuation) {
        if (continuation) {
            c->tui->input.len--;
            c->tui->input.buf[c->tui->input.len] = '\0';
            if (c->tui->input.cursor > c->tui->input.len) c->tui->input.cursor = c->tui->input.len;
        }
        tui_input_insert(c->tui, '\n');
        return true;
    }

    /* Alt+Enter → newline */
    /* Handled via paste_mode or mod check; tb_event doesn't always pass mod for Enter */

    char *text = tui_input_steal(c->tui);
    c->paste_mode = false;
    c->tui->paste_mode = false;

    if (strlen(text) == 0) { free(text); return false; }

    if (strcmp(text, "quit") == 0 || strcmp(text, "exit") == 0) {
        free(text);
        if (c->agent_state == STATE_STREAMING) {
            atomic_store(&c->session->cancelled, true);
            rb_push(c->ring, TAG_SYSTEM, "\n[Interrupting...]\n", 19);
            tui_consume_output(c->tui);
            tui_render(c->tui);
            tb_present();
            pthread_join(c->agent_thread, NULL);
            c->agent_thread = 0;
            c->agent_state = STATE_IDLE;
        }
        c->running = false;
        return false;
    }

    if (c->agent_state == STATE_IDLE) {
        if (c->first_message) {
            c->clear_on_drain = true;
            c->first_message = false;
        }
        launch_agent(c, text);
        return true;
    }
    free(text);
    return false;
}

static bool handle_char(AppContext *c, struct tb_event *ev) {
    if ((ev->ch == 't' || ev->ch == 'T') && c->tui->input.len == 0) {
        tui_toggle_collapse(c->tui);
    } else if (ev->ch == '/' && c->tui->input.len == 0) {
        tui_input_insert(c->tui, '/');
        c->cmd_popup.active = true;
        cmd_update_matches(&c->cmd_popup, "");
    } else {
        tui_input_insert(c->tui, ev->ch);
        if (c->cmd_popup.active) {
            if (c->tui->input.len > 0 && c->tui->input.buf[0] == '/')
                cmd_update_matches(&c->cmd_popup, c->tui->input.buf + 1);
            else
                c->cmd_popup.active = false;
        }
    }
    return true;
}

static bool handle_key(AppContext *c, struct tb_event *ev) {
    if (ev->key == TB_KEY_CTRL_C) return handle_ctrl_c(c);
    if (ev->key == TB_KEY_ESC)    return handle_esc(c);
    if (ev->key == TB_KEY_CTRL_V) {
        c->paste_mode = !c->paste_mode;
        c->tui->paste_mode = c->paste_mode;
        return true;
    }
    if (c->sub_popup_mode != SUB_NONE) return handle_sub_popup(c, ev);
    if (ev->key == TB_KEY_CTRL_P) {
        int next = (c->session->ctx->config->profile_index + 1) % config_profile_count();
        config_switch_profile(c->session->ctx->config, next);
        const ModelProfile *mp = config_get_profile(next);
        snprintf(c->tui->model_name, sizeof(c->tui->model_name), "%s", mp->name);
        tui_set_state_text(c->tui, "Switched to %s | Ctrl+P:switch model", mp->name);
        return true;
    }
    if (ev->key == TB_KEY_CTRL_N) { tui_input_insert(c->tui, '\n'); return true; }
    if (c->cmd_popup.active) return handle_cmd_popup(c, ev);
    if (ev->key == TB_KEY_ENTER) return handle_enter(c);
    if (ev->ch) return handle_char(c, ev);

    TUIState *t = c->tui;
    if (ev->key == TB_KEY_BACKSPACE || ev->key == TB_KEY_BACKSPACE2) { tui_input_backspace(t); return true; }
    if (ev->key == TB_KEY_DELETE)                                    { tui_input_delete(t); return true; }
    if (ev->key == TB_KEY_ARROW_LEFT)                                { tui_input_move(t, -1); return true; }
    if (ev->key == TB_KEY_ARROW_RIGHT)                               { tui_input_move(t, 1); return true; }
    if (ev->key == TB_KEY_HOME)                                      { tui_input_home(t); return true; }
    if (ev->key == TB_KEY_END)                                       { tui_input_end(t); return true; }
    if (ev->key == TB_KEY_ARROW_UP) {
        if (ev->mod & TB_MOD_SHIFT) tui_scroll_up(t, 1);
        else if (t->input.len == 0 && t->input.cursor == 0 && t->history_count > 0) {
            if (t->history_index < 0) t->history_index = 0;
            else if (t->history_index < t->history_count - 1) t->history_index++;
            tui_history_load(t, t->history_index);
        } else tui_input_move_vertical(t, -1);
        return true;
    }
    if (ev->key == TB_KEY_ARROW_DOWN) {
        if (ev->mod & TB_MOD_SHIFT) tui_scroll_down(t, 1);
        else if (t->history_index >= 0) {
            t->history_index--;
            if (t->history_index < 0) { t->input.len = 0; t->input.cursor = 0; t->input.buf[0] = '\0'; t->history_index = -1; }
            else tui_history_load(t, t->history_index);
        } else tui_input_move_vertical(t, 1);
        return true;
    }
    if (ev->key == TB_KEY_PGUP) { tui_scroll_up(t, t->height / 2); return true; }
    if (ev->key == TB_KEY_PGDN) { tui_scroll_down(t, t->height / 2); return true; }

    return false;
}

/* ===== TUI Mode main loop ===== */

int run_tui_mode(AgentSession *session) {
    RingBuffer ring;
    rb_init(&ring, 4096);

    TUIState tui;
    tui_init(&tui, &ring);

    tb_init();
    tb_set_input_mode(TB_INPUT_ESC | TB_INPUT_MOUSE);
    tb_set_output_mode(TB_OUTPUT_TRUECOLOR);

    /* Sync TUI geometry with actual terminal size before tool check rendering */
    tui.width = tb_width();
    tui.height = tb_height();

    AppContext c = {
        .session = session,
        .tui = &tui,
        .ring = &ring,
        .agent_state = STATE_IDLE,
        .running = true,
        .clear_on_drain = false,
        .first_message = true,
    };

    {
        const ModelProfile *mp = config_get_profile(session->ctx->config->profile_index);
        snprintf(tui.model_name, sizeof(tui.model_name), "%s", mp ? mp->name : session->ctx->config->model);
    }
    tui_set_state_text(&tui, "Ready | /:commands Ctrl+P:model Ctrl+V:paste ESC:interrupt");

    {
        int available = tool_registry_check(session->reg);
        int total = session->reg->count;

        char header[256];
        int hlen = snprintf(header, sizeof(header), "Tool check: %d/%d available\n", available, total);
        rb_push(&ring, TAG_SYSTEM, header, (size_t)hlen);

        int screen_w = tb_width();
        if (screen_w < 40) screen_w = 80;
        int text_w = screen_w - 6;
        if (text_w < 20) text_w = 20;

        int cols = text_w / 20;
        if (cols < 1) cols = 1;
        if (cols > 4) cols = 4;
        int col_w = text_w / cols;
        int rows = (total + cols - 1) / cols;

        for (int row = 0; row < rows; row++) {
            char line[512];
            int pos = 0;
            for (int col = 0; col < cols; col++) {
                int idx = row + col * rows;
                if (idx >= total) break;
                const char *mark = session->reg->entries[idx].available
                                   ? "\xe2\x9c\x93" : "\xe2\x9c\x97";
                pos += snprintf(line + pos, sizeof(line) - pos, "%s ", mark);
                const char *name = session->reg->entries[idx].name;
                int name_len = 0;
                for (const char *p = name; *p && pos < (int)sizeof(line) - 2; p++) {
                    line[pos++] = (*p == '_') ? '-' : *p;
                    name_len++;
                }
                int pad = col_w - 3 - name_len;
                for (int s = 0; s < pad && pos < (int)sizeof(line) - 2; s++)
                    line[pos++] = ' ';
            }
            line[pos] = '\0';
            rb_push(&ring, TAG_SYSTEM, line, (size_t)pos);
        }

        rb_push(&ring, TAG_SYSTEM, "", 0);
    }

    tui_render(&tui);
    tb_present();

    long long last_spinner_ms = 0, last_render_ms = 0;
    bool need_render = true;

    while (c.running) {
        /* Geometry */
        int nw = tb_width(), nh = tb_height();
        if (nw != tui.width || nh != tui.height) {
            tui.width = nw; tui.height = nh;
            tui_clamp_scroll(&tui);
            need_render = true;
        }

        /* Spinner */
        long long now = time_ms();
        if (tui.agent_busy && now - last_spinner_ms >= 200) {
            tui_spinner_tick(&tui);
            last_spinner_ms = now;
            tui_render_statusbar_only(&tui);
            tb_present();
            last_render_ms = time_ms();
        } else if (!tui.agent_busy) {
            last_spinner_ms = now;
        }

        /* Drain output */
        if (rb_has_data(&ring)) {
            if (c.clear_on_drain) {
                tui_clear_output(&tui);
                c.clear_on_drain = false;
            }
            tui_consume_output(&tui);
            need_render = true;
        }

        /* Agent done */
        process_agent_done(&c);
        if (c.agent_state == STATE_IDLE && tui.agent_busy) need_render = true;

        /* Render (throttled) */
        if (need_render) {
            long long gap = time_ms() - last_render_ms;
            if (gap >= 50 || last_render_ms == 0) {
                render_frame(&c);
                need_render = false;
                last_render_ms = time_ms();
            }
        }

        /* Event */
        struct tb_event ev;
        if (tb_peek_event(&ev, 30) != TB_OK) continue;

        if (ev.type == TB_EVENT_RESIZE) {
            tui.width = ev.w; tui.height = ev.h;
            tui_clamp_scroll(&tui);
            need_render = true;
            continue;
        }
        if (ev.type == TB_EVENT_MOUSE) {
            if (ev.key == TB_KEY_MOUSE_WHEEL_UP)   { tui_scroll_up(&tui, 3); need_render = true; }
            if (ev.key == TB_KEY_MOUSE_WHEEL_DOWN) { tui_scroll_down(&tui, 3); need_render = true; }
            continue;
        }
        if (ev.type != TB_EVENT_KEY) continue;

        need_render = handle_key(&c, &ev);
    }

    /* Cleanup */
    if (c.agent_state == STATE_STREAMING && c.agent_thread) {
        atomic_store(&session->cancelled, true);
        pthread_join(c.agent_thread, NULL);
    }
    free(c.thread_arg.user_msg);

    tb_shutdown();
    tui_shutdown(&tui);
    rb_free(&ring);
    return 0;
}
