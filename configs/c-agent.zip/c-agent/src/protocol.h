#ifndef PROTOCOL_H
#define PROTOCOL_H

#include "agent.h"
#include "transports/transport.h"

#include <pthread.h>

/* ===== Protocol adapter ===== */

typedef struct {
    Transport      *transport;
    pthread_mutex_t write_mutex;
} ProtocolAdapter;

void protocol_adapter_init(ProtocolAdapter *adapter, Transport *transport);
void protocol_adapter_free(ProtocolAdapter *adapter);

/* Create an AgentOutput wired to this adapter's transport */
AgentOutput protocol_adapter_create_output(ProtocolAdapter *adapter);

/* ===== JSON-RPC messaging ===== */

/* Send a response: {"jsonrpc":"2.0","id":<id>,"result":<result_json>} */
void protocol_send_response(ProtocolAdapter *adapter, int id, const char *result_json);

/* Send an error: {"jsonrpc":"2.0","id":<id>,"error":{"code":<code>,"message":"<msg>"}} */
void protocol_send_error(ProtocolAdapter *adapter, int id, int code, const char *message);

/* Send a notification: {"jsonrpc":"2.0","method":"notify","params":<params_json>} */
void protocol_send_notification(ProtocolAdapter *adapter, const char *params_json);

/* Parse an incoming JSON-RPC request line.
   Returns 0 on success, -1 on parse error.
   Caller must free *out_method and *out_params_json. */
int protocol_parse_request(const char *line, int *out_id,
                           char **out_method, char **out_params_json);

/* JSON-escape a string for embedding in JSON values. Returns heap-allocated string. */
char *protocol_json_escape(const char *src, size_t len);

#endif
