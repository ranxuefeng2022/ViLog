#ifndef TUI_H
#define TUI_H

#include "ringbuf.h"
#include "termbox2.h"
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uintattr_t bg;
    uintattr_t status_bg;
    uintattr_t status_fg;
    uintattr_t status_fg_dim;
    uintattr_t input_border;
    uintattr_t input_prompt;
    uintattr_t input_prompt_paste;
    uintattr_t input_prompt_busy;
    uintattr_t scrollbar_track;
    uintattr_t scrollbar_thumb;
    uintattr_t line_number_fg;
    uintattr_t separator_fg;
    uintattr_t code_border;
    uintattr_t code_lang_fg;
    uintattr_t code_bg;
    uintattr_t card_border;
    uintattr_t user_fg;
    uintattr_t user_label_fg;
    uintattr_t agent_fg;
    uintattr_t agent_label_fg;
    uintattr_t thinking_fg;
    uintattr_t thinking_label_fg;
    uintattr_t tool_call_fg;
    uintattr_t tool_result_fg;
    uintattr_t error_fg;
    uintattr_t system_fg;
    /* Markdown rendering */
    uintattr_t header_fg;
    uintattr_t quote_fg;
    uintattr_t quote_bar_fg;
    uintattr_t list_marker_fg;
    uintattr_t inline_code_fg;
    uintattr_t inline_code_bg;
} TUITheme;

const TUITheme *tui_get_theme(int index);

enum MdLineType {
    MD_NONE = 0,
    MD_H1, MD_H2, MD_H3, MD_H4,
    MD_QUOTE,
    MD_LIST, MD_LIST_ORD,
    MD_TABLE, MD_TABLE_SEP,
    MD_TABLE_TOP, MD_TABLE_BOT,
    MD_HRULE,
    MD_TASK_OPEN, MD_TASK_DONE
};

typedef struct {
    OutputTag tag;
    char     *text;
    int       label_end;      // byte offset after role label "]", 0 = no label
    bool      in_code_block;
    bool      hidden;
    int       collapse_group; // 0 = not collapsible
    uint8_t   md_line;        // line-level markdown type
} DisplayLine;

typedef struct {
    char    *buf;
    int      len;
    int      cursor;
    int      cap;
    int      scroll;
} InputLine;

#define HISTORY_MAX 100

typedef struct {
    DisplayLine  *lines;
    int           line_count;
    int           line_cap;
    int           scroll_off;
    InputLine     input;
    char          status[256];
    bool          agent_busy;
    int           width;
    int           height;
    RingBuffer   *ring;
    // Line accumulator for streaming text
    char         *acc_buf;
    int           acc_len;
    int           acc_cap;
    OutputTag     acc_tag;
    bool          acc_in_code_block;
    bool          needs_agent_label;
    // Input history
    char         *history[HISTORY_MAX];
    int           history_count;
    int           history_index;   // -1 = not browsing
    // Spinner
    int           spinner_frame;
    // Status bar enrichment
    int           turn_number;
    long long     response_start_ms;
    char          model_name[64];
    char          state_text[64];
    bool          paste_mode;
    int           theme_index;
} TUIState;

void  tui_init(TUIState *tui, RingBuffer *ring);
void  tui_shutdown(TUIState *tui);
void  tui_render(TUIState *tui);
void  tui_render_statusbar_only(TUIState *tui);
void  tui_cycle_theme(TUIState *tui);
int   tui_theme_count(void);
const char *tui_theme_name(int index);
void  tui_consume_output(TUIState *tui);
void  tui_input_insert(TUIState *tui, uint32_t ch);
void  tui_input_backspace(TUIState *tui);
void  tui_input_delete(TUIState *tui);
void  tui_input_move(TUIState *tui, int delta);
void  tui_input_move_vertical(TUIState *tui, int delta);
void  tui_input_home(TUIState *tui);
void  tui_input_end(TUIState *tui);
char *tui_input_steal(TUIState *tui);
void  tui_scroll_up(TUIState *tui, int n);
void  tui_scroll_down(TUIState *tui, int n);
void  tui_scroll_to_bottom(TUIState *tui);
void  tui_clamp_scroll(TUIState *tui);
void  tui_set_status(TUIState *tui, const char *fmt, ...);
void  tui_set_state_text(TUIState *tui, const char *fmt, ...);
void  tui_push_line(TUIState *tui, OutputTag tag, const char *text);
void  tui_flush(TUIState *tui);
void  tui_history_load(TUIState *tui, int index);
void  tui_toggle_collapse(TUIState *tui);
void  tui_spinner_tick(TUIState *tui);
int   render_text(int x, int y, const char *text, int tlen, uintattr_t fg, uintattr_t bg, int bold_end);

/* Popup rendering (generic, no command knowledge) */
void tui_render_menu_popup(const TUIState *tui, int input_row,
                            const char **labels, const char **shortcuts,
                            int item_count, int selected);
void tui_render_list_popup(const TUIState *tui, int input_row,
                            const char *title, const char **items,
                            int item_count, int selected);
void tui_render_shortcuts_popup(const TUIState *tui, int input_row);

#endif
