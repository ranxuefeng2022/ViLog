#ifndef RINGBUF_H
#define RINGBUF_H

#include <pthread.h>
#include <stdbool.h>
#include <stddef.h>

typedef enum {
    TAG_USER,
    TAG_AGENT,
    TAG_THINKING,
    TAG_TOOL_CALL,
    TAG_TOOL_RESULT,
    TAG_ERROR,
    TAG_SYSTEM,
    TAG_SEPARATOR,
    TAG_STATUS
} OutputTag;

typedef struct {
    OutputTag tag;
    char     *text;
    size_t    len;
} OutputChunk;

typedef struct {
    OutputChunk    *slots;
    int             capacity;
    int             head;
    int             tail;
    int             count;
    pthread_mutex_t mutex;
} RingBuffer;

void rb_init(RingBuffer *rb, int capacity);
void rb_free(RingBuffer *rb);
void rb_push(RingBuffer *rb, OutputTag tag, const char *text, size_t len);
bool rb_has_data(RingBuffer *rb);
int  rb_drain(RingBuffer *rb, void (*callback)(OutputTag tag, const char *text, size_t len, void *ctx), void *ctx);

#endif
