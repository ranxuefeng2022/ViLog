#ifndef CONTEXT_H
#define CONTEXT_H

#include <stddef.h>

#define CTX_CHARS_PER_TOKEN        4

typedef struct LLMContext LLMContext;

typedef struct {
    int   total_estimated_tokens;
    int   message_count;
} ContextStats;

int    context_estimate_tokens(const char *text);
int    context_estimate_messages(LLMContext *ctx);
ContextStats context_compute_stats(LLMContext *ctx, const char *system_prompt);
void   context_dump_md(LLMContext *ctx, const char *system_prompt, int seq, const char *base_dir);
void   context_dump_request_json(const char *json, int seq, const char *base_dir);

#endif
