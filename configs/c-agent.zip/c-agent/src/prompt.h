#ifndef PROMPT_H
#define PROMPT_H

#include "tool_engine.h"

char *build_system_prompt(const ToolRegistry *reg);

#endif
