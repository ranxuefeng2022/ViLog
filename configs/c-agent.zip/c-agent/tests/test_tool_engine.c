#include "test_framework.h"
#include "cJSON.h"
#include "tool_engine.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static ToolResult dummy_handler(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)ctx;
    char buf[128];
    const char *val = "none";
    cJSON *v = cJSON_GetObjectItem(params, "val");
    if (v && v->valuestring) val = v->valuestring;
    snprintf(buf, sizeof(buf), "%s:%s", name, val);
    return tool_ok(strdup(buf));
}

static ToolResult echo_handler(const char *name, cJSON *params, const ToolContext *ctx) {
    (void)params; (void)ctx;
    return tool_ok(strdup(name));
}

void test_registry_init(void) {
    TEST_BEGIN("registry_init");
    ToolRegistry reg;
    tool_registry_init(&reg);
    ASSERT_INT_EQ(reg.count, 0, "count should be 0 after init");
    TEST_PASS("registry_init");
}

void test_register_and_execute(void) {
    TEST_BEGIN("register_and_execute");
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_register(&reg, "echo", "echo tool", "{}", dummy_handler);

    cJSON *params = cJSON_Parse("{\"val\":\"hello\"}");
    ToolResult result = tool_execute(&reg, "echo", params);
    ASSERT_TRUE(result.success, "tool succeeded");
    ASSERT_STR_EQ(result.text, "echo:hello", "dispatch to correct handler");
    free(result.text);
    cJSON_Delete(params);
    tool_registry_free(&reg);
    TEST_PASS("register_and_execute");
}

void test_execute_unknown(void) {
    TEST_BEGIN("execute_unknown");
    ToolRegistry reg;
    tool_registry_init(&reg);
    cJSON *params = cJSON_Parse("{}");
    ToolResult result = tool_execute(&reg, "nonexistent", params);
    ASSERT_FALSE(result.success, "unknown tool should fail");
    ASSERT_STR_CONTAINS(result.text, "Error: Unknown tool", "unknown tool error");
    free(result.text);
    cJSON_Delete(params);
    tool_registry_free(&reg);
    TEST_PASS("execute_unknown");
}

void test_register_multiple(void) {
    TEST_BEGIN("register_multiple");
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_register(&reg, "a", "tool a", "{}", echo_handler);
    tool_register(&reg, "b", "tool b", "{}", echo_handler);
    tool_register(&reg, "c", "tool c", "{}", echo_handler);

    cJSON *params = cJSON_Parse("{}");
    ToolResult ra = tool_execute(&reg, "a", params); ASSERT_TRUE(ra.success, "a ok"); ASSERT_STR_EQ(ra.text, "a", "dispatch a"); free(ra.text);
    ToolResult rb = tool_execute(&reg, "b", params); ASSERT_TRUE(rb.success, "b ok"); ASSERT_STR_EQ(rb.text, "b", "dispatch b"); free(rb.text);
    ToolResult rc = tool_execute(&reg, "c", params); ASSERT_TRUE(rc.success, "c ok"); ASSERT_STR_EQ(rc.text, "c", "dispatch c"); free(rc.text);
    cJSON_Delete(params);
    tool_registry_free(&reg);
    TEST_PASS("register_multiple");
}

void test_register_dynamic_growth(void) {
    TEST_BEGIN("register_dynamic_growth");
    ToolRegistry reg;
    tool_registry_init(&reg);
    char name[16];
    for (int i = 0; i < 64; i++) {
        snprintf(name, sizeof(name), "tool_%d", i);
        int rc = tool_register(&reg, name, "desc", "{}", echo_handler);
        ASSERT_INT_EQ(rc, 0, "register should succeed");
    }
    ASSERT_INT_EQ(reg.count, 64, "count should be 64");
    ASSERT_TRUE(reg.capacity >= 64, "capacity should be >= 64");
    tool_registry_free(&reg);
    TEST_PASS("register_dynamic_growth");
}

void test_registry_free_no_crash(void) {
    TEST_BEGIN("registry_free");
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_register(&reg, "x", "desc", "{}", echo_handler);
    tool_register(&reg, "y", "desc", "{}", echo_handler);
    tool_registry_free(&reg);
    ASSERT_TRUE(1, "no crash after free");
    TEST_PASS("registry_free");
}

void test_tool_receives_params(void) {
    TEST_BEGIN("tool_receives_params");
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_register(&reg, "check", "check", "{}", dummy_handler);
    cJSON *params = cJSON_Parse("{\"val\":\"world\"}");
    ToolResult result = tool_execute(&reg, "check", params);
    ASSERT_TRUE(result.success, "tool succeeded");
    ASSERT_STR_EQ(result.text, "check:world", "handler received correct params");
    free(result.text);
    cJSON_Delete(params);
    tool_registry_free(&reg);
    TEST_PASS("tool_receives_params");
}

void test_registry_check(void) {
    TEST_BEGIN("registry_check");
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_register(&reg, "a", "tool a", "{}", echo_handler);
    tool_register(&reg, "b", "tool b", "{}", echo_handler);
    int avail = tool_registry_check(&reg);
    ASSERT_INT_EQ(avail, 2, "all tools available without check fn");
    tool_registry_free(&reg);
    TEST_PASS("registry_check");
}

int main(void) {
    printf("=== test_tool_engine ===\n");
    test_registry_init();
    test_register_and_execute();
    test_execute_unknown();
    test_register_multiple();
    test_register_dynamic_growth();
    test_registry_free_no_crash();
    test_tool_receives_params();
    test_registry_check();
    printf("\n%d tests, %d failures\n", g_tests_run, g_tests_failed);
    return g_tests_failed > 0 ? 1 : 0;
}
