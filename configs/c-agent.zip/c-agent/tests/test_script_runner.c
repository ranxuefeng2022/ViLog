#include "test_framework.h"
#include "cJSON.h"
#include "tool_engine.h"
#include "tools/script_runner.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static const char *g_tmpdir;
static ToolRegistry g_reg;

static void mkdir_raw(const char *rel_path) {
    char full[1024];
    snprintf(full, sizeof(full), "%s/%s", g_tmpdir, rel_path);
    mkdir(full, 0755);
}

static int file_exists(const char *rel_path) {
    char full[1024];
    snprintf(full, sizeof(full), "%s/%s", g_tmpdir, rel_path);
    return access(full, F_OK) == 0;
}

static ToolResult exec_tool(const char *name, cJSON *params) {
    return tool_execute(&g_reg, name, params);
}

/* ===== run_python ===== */

static void test_run_python_basic(void) {
    TEST_BEGIN("run_python_basic");
    if (!check_python()) { printf("skipped (no python)\n"); return; }

    cJSON *p = cJSON_Parse("{\"code\":\"print('hello from python')\"}");
    ToolResult r = exec_tool("run_python", p);
    ASSERT_TRUE(r.success, "python succeeded");
    ASSERT_STR_CONTAINS(r.text, "hello from python", "python output");
    ASSERT_STR_CONTAINS(r.text, "Exit code: 0", "exit code 0");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_python_basic");
}

static void test_run_python_computation(void) {
    TEST_BEGIN("run_python_computation");
    if (!check_python()) { printf("skipped (no python)\n"); return; }

    cJSON *p = cJSON_Parse("{\"code\":\"print(2 ** 10)\"}");
    ToolResult r = exec_tool("run_python", p);
    ASSERT_TRUE(r.success, "python succeeded");
    ASSERT_STR_CONTAINS(r.text, "1024", "2**10 = 1024");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_python_computation");
}

static void test_run_python_error(void) {
    TEST_BEGIN("run_python_error");
    if (!check_python()) { printf("skipped (no python)\n"); return; }

    cJSON *p = cJSON_Parse("{\"code\":\"raise ValueError('test error')\"}");
    ToolResult r = exec_tool("run_python", p);
    ASSERT_TRUE(r.success, "tool executed (non-zero exit is still success)");
    ASSERT_STR_CONTAINS(r.text, "Exit code:", "has exit code");
    ASSERT_STR_NOT_CONTAINS(r.text, "Exit code: 0", "non-zero exit for error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_python_error");
}

static void test_run_python_missing_code(void) {
    TEST_BEGIN("run_python_missing_code");
    if (!check_python()) { printf("skipped (no python)\n"); return; }

    cJSON *p = cJSON_Parse("{}");
    ToolResult r = exec_tool("run_python", p);
    ASSERT_FALSE(r.success, "should fail");
    ASSERT_STR_CONTAINS(r.text, "Missing", "missing code error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_python_missing_code");
}

static void test_run_python_file_io(void) {
    TEST_BEGIN("run_python_file_io");
    if (!check_python()) { printf("skipped (no python)\n"); return; }

    cJSON *p = cJSON_Parse(
        "{\"code\":\""
        "f = open('py_output.txt', 'w')\\n"
        "f.write('python wrote this')\\n"
        "f.close()\\n"
        "print('file written')"
        "\"}");
    ToolResult r = exec_tool("run_python", p);
    ASSERT_TRUE(r.success, "python succeeded");
    ASSERT_STR_CONTAINS(r.text, "file written", "python confirmed write");

    ASSERT_TRUE(file_exists("py_output.txt"), "output file exists");

    char full[1024];
    snprintf(full, sizeof(full), "%s/py_output.txt", g_tmpdir);
    FILE *f = fopen(full, "r");
    ASSERT_NOT_NULL(f, "can open output file");
    char buf[256];
    if (fgets(buf, sizeof(buf), f)) {
        ASSERT_STR_CONTAINS(buf, "python wrote this", "file content correct");
    }
    fclose(f);

    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_python_file_io");
}

/* ===== run_node ===== */

static void test_run_node_basic(void) {
    TEST_BEGIN("run_node_basic");
    if (!check_node()) { printf("skipped (no node)\n"); return; }

    cJSON *p = cJSON_Parse("{\"code\":\"console.log('hello from node')\"}");
    ToolResult r = exec_tool("run_node", p);
    ASSERT_TRUE(r.success, "node succeeded");
    ASSERT_STR_CONTAINS(r.text, "hello from node", "node output");
    ASSERT_STR_CONTAINS(r.text, "Exit code: 0", "exit code 0");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_node_basic");
}

static void test_run_node_computation(void) {
    TEST_BEGIN("run_node_computation");
    if (!check_node()) { printf("skipped (no node)\n"); return; }

    cJSON *p = cJSON_Parse("{\"code\":\"console.log(Math.pow(2, 10))\"}");
    ToolResult r = exec_tool("run_node", p);
    ASSERT_TRUE(r.success, "node succeeded");
    ASSERT_STR_CONTAINS(r.text, "1024", "2^10 = 1024");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_node_computation");
}

static void test_run_node_error(void) {
    TEST_BEGIN("run_node_error");
    if (!check_node()) { printf("skipped (no node)\n"); return; }

    cJSON *p = cJSON_Parse("{\"code\":\"throw new Error('test error')\"}");
    ToolResult r = exec_tool("run_node", p);
    ASSERT_TRUE(r.success, "tool executed");
    ASSERT_STR_NOT_CONTAINS(r.text, "Exit code: 0", "non-zero exit for error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_node_error");
}

static void test_run_node_missing_code(void) {
    TEST_BEGIN("run_node_missing_code");
    if (!check_node()) { printf("skipped (no node)\n"); return; }

    cJSON *p = cJSON_Parse("{}");
    ToolResult r = exec_tool("run_node", p);
    ASSERT_FALSE(r.success, "should fail");
    ASSERT_STR_CONTAINS(r.text, "Missing", "missing code error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_node_missing_code");
}

/* ===== create_script ===== */

static void test_create_script_python(void) {
    TEST_BEGIN("create_script_python");
    cJSON *p = cJSON_Parse(
        "{\"name\":\"hello\",\"code\":\"print('hello script')\\n\",\"language\":\"python\"}");
    ToolResult r = exec_tool("create_script", p);
    ASSERT_TRUE(r.success, "create script succeeded");
    ASSERT_STR_CONTAINS(r.text, "Script created", "created message");
    ASSERT_TRUE(file_exists(".scripts/hello.py"), "python script file exists");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("create_script_python");
}

static void test_create_script_javascript(void) {
    TEST_BEGIN("create_script_javascript");
    cJSON *p = cJSON_Parse(
        "{\"name\":\"hello_js\",\"code\":\"console.log('hello js')\\n\",\"language\":\"javascript\"}");
    ToolResult r = exec_tool("create_script", p);
    ASSERT_TRUE(r.success, "create script succeeded");
    ASSERT_TRUE(file_exists(".scripts/hello_js.js"), "js script file exists");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("create_script_javascript");
}

static void test_create_script_shell(void) {
    TEST_BEGIN("create_script_shell");
    cJSON *p = cJSON_Parse(
        "{\"name\":\"hello_sh\",\"code\":\"echo hello shell\\n\",\"language\":\"shell\"}");
    ToolResult r = exec_tool("create_script", p);
    ASSERT_TRUE(r.success, "create script succeeded");
    ASSERT_TRUE(file_exists(".scripts/hello_sh.sh"), "shell script file exists");

    char full[1024];
    snprintf(full, sizeof(full), "%s/.scripts/hello_sh.sh", g_tmpdir);
    FILE *f = fopen(full, "r");
    ASSERT_NOT_NULL(f, "can open shell script");
    char buf[256];
    if (fgets(buf, sizeof(buf), f)) {
        ASSERT_STR_CONTAINS(buf, "#!/bin/sh", "has shebang");
    }
    fclose(f);

    free(r.text); cJSON_Delete(p);
    TEST_PASS("create_script_shell");
}

static void test_create_script_default_language(void) {
    TEST_BEGIN("create_script_default_language");
    cJSON *p = cJSON_Parse(
        "{\"name\":\"default_lang\",\"code\":\"print('default')\\n\"}");
    ToolResult r = exec_tool("create_script", p);
    ASSERT_TRUE(r.success, "create script succeeded");
    ASSERT_TRUE(file_exists(".scripts/default_lang.py"), "defaults to python");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("create_script_default_language");
}

static void test_create_script_missing_name(void) {
    TEST_BEGIN("create_script_missing_name");
    cJSON *p = cJSON_Parse("{\"code\":\"print('x')\"}");
    ToolResult r = exec_tool("create_script", p);
    ASSERT_FALSE(r.success, "should fail");
    ASSERT_STR_CONTAINS(r.text, "Missing", "missing name error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("create_script_missing_name");
}

static void test_create_script_missing_code(void) {
    TEST_BEGIN("create_script_missing_code");
    cJSON *p = cJSON_Parse("{\"name\":\"nocode\"}");
    ToolResult r = exec_tool("create_script", p);
    ASSERT_FALSE(r.success, "should fail");
    ASSERT_STR_CONTAINS(r.text, "Missing", "missing code error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("create_script_missing_code");
}

/* ===== run_script ===== */

static void test_run_script_python(void) {
    TEST_BEGIN("run_script_python");
    if (!check_python()) { printf("skipped (no python)\n"); return; }

    cJSON *cp = cJSON_Parse(
        "{\"name\":\"greet\",\"code\":\"import sys\\nname = sys.argv[1] if len(sys.argv) > 1 else 'world'\\nprint('Hello, ' + name + '!')\\n\"}");
    ToolResult cr = exec_tool("create_script", cp);
    ASSERT_TRUE(cr.success, "create script succeeded");
    free(cr.text); cJSON_Delete(cp);

    cJSON *rp = cJSON_Parse("{\"name\":\"greet\",\"args\":[\"Alice\"]}");
    ToolResult rr = exec_tool("run_script", rp);
    ASSERT_TRUE(rr.success, "run script succeeded");
    ASSERT_STR_CONTAINS(rr.text, "Hello, Alice!", "script output with arg");
    ASSERT_STR_CONTAINS(rr.text, "Exit code: 0", "exit code 0");
    free(rr.text); cJSON_Delete(rp);
    TEST_PASS("run_script_python");
}

static void test_run_script_shell(void) {
    TEST_BEGIN("run_script_shell");
    cJSON *cp = cJSON_Parse(
        "{\"name\":\"echo_args\",\"code\":\"echo got: $1 $2\\n\",\"language\":\"shell\"}");
    ToolResult cr = exec_tool("create_script", cp);
    ASSERT_TRUE(cr.success, "create script succeeded");
    free(cr.text); cJSON_Delete(cp);

    cJSON *rp = cJSON_Parse("{\"name\":\"echo_args\",\"args\":[\"foo\",\"bar\"]}");
    ToolResult rr = exec_tool("run_script", rp);
    ASSERT_TRUE(rr.success, "run script succeeded");
    ASSERT_STR_CONTAINS(rr.text, "got: foo bar", "shell args passed");
    free(rr.text); cJSON_Delete(rp);
    TEST_PASS("run_script_shell");
}

static void test_run_script_not_found(void) {
    TEST_BEGIN("run_script_not_found");
    cJSON *p = cJSON_Parse("{\"name\":\"nonexistent_script\"}");
    ToolResult r = exec_tool("run_script", p);
    ASSERT_FALSE(r.success, "should fail");
    ASSERT_STR_CONTAINS(r.text, "not found", "script not found error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_script_not_found");
}

static void test_run_script_missing_name(void) {
    TEST_BEGIN("run_script_missing_name");
    cJSON *p = cJSON_Parse("{}");
    ToolResult r = exec_tool("run_script", p);
    ASSERT_FALSE(r.success, "should fail");
    ASSERT_STR_CONTAINS(r.text, "Missing", "missing name error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_script_missing_name");
}

/* ===== list_scripts ===== */

static void test_list_scripts_after_create(void) {
    TEST_BEGIN("list_scripts_after_create");
    cJSON *cp1 = cJSON_Parse("{\"name\":\"script_a\",\"code\":\"print('a')\\n\",\"language\":\"python\"}");
    ToolResult cr1 = exec_tool("create_script", cp1);
    ASSERT_TRUE(cr1.success, "create a succeeded");
    free(cr1.text); cJSON_Delete(cp1);

    cJSON *cp2 = cJSON_Parse("{\"name\":\"script_b\",\"code\":\"console.log('b')\\n\",\"language\":\"javascript\"}");
    ToolResult cr2 = exec_tool("create_script", cp2);
    ASSERT_TRUE(cr2.success, "create b succeeded");
    free(cr2.text); cJSON_Delete(cp2);

    cJSON *lp = cJSON_Parse("{}");
    ToolResult lr = exec_tool("list_scripts", lp);
    ASSERT_TRUE(lr.success, "list succeeded");
    ASSERT_STR_CONTAINS(lr.text, "script_a.py", "python script listed");
    ASSERT_STR_CONTAINS(lr.text, "script_b.js", "js script listed");
    free(lr.text); cJSON_Delete(lp);
    TEST_PASS("list_scripts_after_create");
}

/* ===== Integration: create -> list -> run -> verify ===== */

static void test_full_script_lifecycle(void) {
    TEST_BEGIN("full_script_lifecycle");
    if (!check_python()) { printf("skipped (no python)\n"); return; }

    /* Create */
    cJSON *cp = cJSON_Parse(
        "{\"name\":\"adder\",\"code\":\"import sys\\nprint(int(sys.argv[1]) + int(sys.argv[2]))\\n\"}");
    ToolResult cr = exec_tool("create_script", cp);
    ASSERT_TRUE(cr.success, "create succeeded");
    free(cr.text); cJSON_Delete(cp);

    /* List */
    cJSON *lp = cJSON_Parse("{}");
    ToolResult lr = exec_tool("list_scripts", lp);
    ASSERT_TRUE(lr.success, "list succeeded");
    ASSERT_STR_CONTAINS(lr.text, "adder.py", "script in list");
    free(lr.text); cJSON_Delete(lp);

    /* Run */
    cJSON *rp = cJSON_Parse("{\"name\":\"adder\",\"args\":[\"7\",\"35\"]}");
    ToolResult rr = exec_tool("run_script", rp);
    ASSERT_TRUE(rr.success, "run succeeded");
    ASSERT_STR_CONTAINS(rr.text, "42", "7+35=42");
    free(rr.text); cJSON_Delete(rp);
    TEST_PASS("full_script_lifecycle");
}

/* ===== Advanced: Node file I/O ===== */

static void test_run_node_file_io(void) {
    TEST_BEGIN("run_node_file_io");
    if (!check_node()) { printf("skipped (no node)\n"); return; }

    cJSON *p = cJSON_Parse(
        "{\"code\":\"const fs = require('fs'); fs.writeFileSync('node_out.txt', 'node wrote this'); console.log('file written');\"}");
    ToolResult r = exec_tool("run_node", p);
    ASSERT_TRUE(r.success, "node file io succeeded");
    ASSERT_STR_CONTAINS(r.text, "file written", "node confirmed write");

    ASSERT_TRUE(file_exists("node_out.txt"), "node output file exists");
    char full[1024];
    snprintf(full, sizeof(full), "%s/node_out.txt", g_tmpdir);
    FILE *f = fopen(full, "r");
    ASSERT_NOT_NULL(f, "can open node output");
    char buf[256];
    if (fgets(buf, sizeof(buf), f)) {
        ASSERT_STR_CONTAINS(buf, "node wrote this", "node file content correct");
    }
    fclose(f);
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_node_file_io");
}

/* ===== Advanced: overwrite existing script ===== */

static void test_create_script_overwrite(void) {
    TEST_BEGIN("create_script_overwrite");
    /* Create first version */
    cJSON *p1 = cJSON_Parse("{\"name\":\"overwrite_test\",\"code\":\"print('v1')\\n\"}");
    ToolResult r1 = exec_tool("create_script", p1);
    ASSERT_TRUE(r1.success, "create v1 succeeded");
    free(r1.text); cJSON_Delete(p1);

    /* Overwrite with second version */
    cJSON *p2 = cJSON_Parse("{\"name\":\"overwrite_test\",\"code\":\"print('v2')\\n\"}");
    ToolResult r2 = exec_tool("create_script", p2);
    ASSERT_TRUE(r2.success, "create v2 overwrite succeeded");
    free(r2.text); cJSON_Delete(p2);

    /* Verify content is v2 */
    char full[1024];
    snprintf(full, sizeof(full), "%s/.scripts/overwrite_test.py", g_tmpdir);
    FILE *f = fopen(full, "r");
    ASSERT_NOT_NULL(f, "can open overwritten script");
    char buf[512];
    size_t n = fread(buf, 1, sizeof(buf) - 1, f);
    buf[n] = '\0';
    fclose(f);
    ASSERT_STR_CONTAINS(buf, "v2", "content is v2 after overwrite");
    ASSERT_STR_NOT_CONTAINS(buf, "v1", "v1 content gone");
    TEST_PASS("create_script_overwrite");
}

/* ===== Advanced: run_script with special chars in args ===== */

static void test_run_script_special_args(void) {
    TEST_BEGIN("run_script_special_args");
    cJSON *cp = cJSON_Parse(
        "{\"name\":\"special_args\",\"code\":\"echo arg: \\\"$1\\\"\\n\",\"language\":\"shell\"}");
    ToolResult cr = exec_tool("create_script", cp);
    ASSERT_TRUE(cr.success, "create succeeded");
    free(cr.text); cJSON_Delete(cp);

    cJSON *rp = cJSON_Parse("{\"name\":\"special_args\",\"args\":[\"hello world\"]}");
    ToolResult rr = exec_tool("run_script", rp);
    ASSERT_TRUE(rr.success, "run with special args succeeded");
    ASSERT_STR_CONTAINS(rr.text, "arg: hello world", "arg with space passed correctly");
    free(rr.text); cJSON_Delete(rp);
    TEST_PASS("run_script_special_args");
}

/* ===== Advanced: Python multiline with imports ===== */

static void test_run_python_multiline(void) {
    TEST_BEGIN("run_python_multiline");
    if (!check_python()) { printf("skipped (no python)\n"); return; }

    cJSON *p = cJSON_Parse(
        "{\"code\":\"import json\\ndata = {'name': 'test', 'value': 42}\\nprint(json.dumps(data))\"}");
    ToolResult r = exec_tool("run_python", p);
    ASSERT_TRUE(r.success, "python multiline succeeded");
    ASSERT_STR_CONTAINS(r.text, "\"name\"", "json output present");
    ASSERT_STR_CONTAINS(r.text, "42", "json value correct");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_python_multiline");
}

/* ===== Advanced: Python subprocess ===== */

static void test_run_python_subprocess(void) {
    TEST_BEGIN("run_python_subprocess");
    if (!check_python()) { printf("skipped (no python)\n"); return; }

    cJSON *p = cJSON_Parse(
        "{\"code\":\"import subprocess\\nresult = subprocess.run(['echo', 'subprocess works'], capture_output=True, text=True)\\nprint(result.stdout.strip())\"}");
    ToolResult r = exec_tool("run_python", p);
    ASSERT_TRUE(r.success, "python subprocess succeeded");
    ASSERT_STR_CONTAINS(r.text, "subprocess works", "subprocess output correct");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("run_python_subprocess");
}

/* ===== Advanced: Shell script with conditional ===== */

static void test_run_shell_conditional(void) {
    TEST_BEGIN("run_shell_conditional");
    cJSON *cp = cJSON_Parse(
        "{\"name\":\"cond\",\"code\":\"if [ $1 = 'yes' ]; then\\necho POSITIVE\\nelse\\necho NEGATIVE\\nfi\\n\",\"language\":\"shell\"}");
    ToolResult cr = exec_tool("create_script", cp);
    ASSERT_TRUE(cr.success, "create cond succeeded");
    free(cr.text); cJSON_Delete(cp);

    cJSON *rp1 = cJSON_Parse("{\"name\":\"cond\",\"args\":[\"yes\"]}");
    ToolResult rr1 = exec_tool("run_script", rp1);
    ASSERT_TRUE(rr1.success, "run cond yes succeeded");
    ASSERT_STR_CONTAINS(rr1.text, "POSITIVE", "if-true branch");
    free(rr1.text); cJSON_Delete(rp1);

    cJSON *rp2 = cJSON_Parse("{\"name\":\"cond\",\"args\":[\"no\"]}");
    ToolResult rr2 = exec_tool("run_script", rp2);
    ASSERT_TRUE(rr2.success, "run cond no succeeded");
    ASSERT_STR_CONTAINS(rr2.text, "NEGATIVE", "if-false branch");
    free(rr2.text); cJSON_Delete(rp2);
    TEST_PASS("run_shell_conditional");
}

/* ===== Advanced: Shell script with loop ===== */

static void test_run_shell_loop(void) {
    TEST_BEGIN("run_shell_loop");
    cJSON *cp = cJSON_Parse(
        "{\"name\":\"looper\",\"code\":\"for i in $1 $2 $3; do echo item:$i; done\\n\",\"language\":\"shell\"}");
    ToolResult cr = exec_tool("create_script", cp);
    ASSERT_TRUE(cr.success, "create loop succeeded");
    free(cr.text); cJSON_Delete(cp);

    cJSON *rp = cJSON_Parse("{\"name\":\"looper\",\"args\":[\"a\",\"b\",\"c\"]}");
    ToolResult rr = exec_tool("run_script", rp);
    ASSERT_TRUE(rr.success, "run loop succeeded");
    ASSERT_STR_CONTAINS(rr.text, "item:a", "loop item a");
    ASSERT_STR_CONTAINS(rr.text, "item:b", "loop item b");
    ASSERT_STR_CONTAINS(rr.text, "item:c", "loop item c");
    free(rr.text); cJSON_Delete(rp);
    TEST_PASS("run_shell_loop");
}

/* ===== main ===== */

int main(void) {
    g_tmpdir = test_create_temp_dir();
    printf("=== test_script_runner ===\n");
    printf("  workspace: %s\n", g_tmpdir);

    tool_registry_init(&g_reg);
    tool_registry_set_workspace(&g_reg, g_tmpdir);
    tool_register_module(&g_reg, script_runner_module_get_module());

    mkdir_raw(".scripts");

    test_run_python_basic();
    test_run_python_computation();
    test_run_python_error();
    test_run_python_missing_code();
    test_run_python_file_io();

    test_run_node_basic();
    test_run_node_computation();
    test_run_node_error();
    test_run_node_missing_code();

    test_create_script_python();
    test_create_script_javascript();
    test_create_script_shell();
    test_create_script_default_language();
    test_create_script_missing_name();
    test_create_script_missing_code();

    test_run_script_python();
    test_run_script_shell();
    test_run_script_not_found();
    test_run_script_missing_name();

    test_list_scripts_after_create();

    test_run_node_file_io();
    test_create_script_overwrite();
    test_run_script_special_args();
    test_run_python_multiline();
    test_run_python_subprocess();
    test_run_shell_conditional();
    test_run_shell_loop();

    test_full_script_lifecycle();


    printf("\n%d tests, %d failures\n", g_tests_run, g_tests_failed);
    tool_registry_free(&g_reg);
    test_cleanup_temp_dir();
    return g_tests_failed > 0 ? 1 : 0;
}
