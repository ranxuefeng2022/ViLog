#include "test_framework.h"
#include "cJSON.h"
#include "config.h"
#include "llm_client.h"
#include "tool_engine.h"
#include "tools/file_ops.h"
#include "tools/compiler.h"
#include "tools/project_analyzer.h"
#include "tools/math_ops.h"
#include "context.h"
#include "agent.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *g_tmpdir;
static ToolContext g_file_ctx;

// === Plan Management ===

static void test_plan_parse_numbered(void) {
    TEST_BEGIN("plan_parse_numbered");
    AgentPlan *plan = agent_plan_parse(
        "1. Read the source file\n"
        "2. Identify the bug\n"
        "3. Fix the bug\n"
        "4. Compile and test\n");
    ASSERT_NOT_NULL(plan, "plan created");
    ASSERT_TRUE(plan->step_count == 4, "4 steps");
    ASSERT_TRUE(plan->active, "plan is active");
    ASSERT_STR_EQ(plan->steps[0].description, "Read the source file", "step 1 desc");
    ASSERT_STR_EQ(plan->steps[3].description, "Compile and test", "step 4 desc");
    ASSERT_TRUE(plan->steps[0].status == STEP_PENDING, "step 1 pending");
    agent_plan_free(plan);
    free(plan);
    TEST_PASS("plan_parse_numbered");
}

static void test_plan_parse_bullet(void) {
    TEST_BEGIN("plan_parse_bullet");
    AgentPlan *plan = agent_plan_parse(
        "- Read file\n"
        "- Fix bug\n"
        "- Test\n");
    ASSERT_NOT_NULL(plan, "plan created");
    ASSERT_TRUE(plan->step_count == 3, "3 steps");
    ASSERT_STR_EQ(plan->steps[0].description, "Read file", "step 1");
    agent_plan_free(plan);
    free(plan);
    TEST_PASS("plan_parse_bullet");
}

static void test_plan_parse_empty(void) {
    TEST_BEGIN("plan_parse_empty");
    AgentPlan *plan = agent_plan_parse("");
    ASSERT_NULL(plan, "null for empty input");
    AgentPlan *plan2 = agent_plan_parse(NULL);
    ASSERT_NULL(plan2, "null for NULL input");
    TEST_PASS("plan_parse_empty");
}

static void test_plan_parse_mixed(void) {
    TEST_BEGIN("plan_parse_mixed");
    AgentPlan *plan = agent_plan_parse(
        "1. First step\n"
        "\n"
        "2. Second step\n"
        "   With extra detail\n"
        "3) Third step\n");
    ASSERT_NOT_NULL(plan, "plan created");
    ASSERT_TRUE(plan->step_count >= 3, "at least 3 steps");
    agent_plan_free(plan);
    free(plan);
    TEST_PASS("plan_parse_mixed");
}

static void test_plan_update_step(void) {
    TEST_BEGIN("plan_update_step");
    AgentPlan *plan = agent_plan_parse("1. Step one\n2. Step two\n3. Step three\n");
    ASSERT_NOT_NULL(plan, "plan created");

    agent_plan_update_step(plan, 0, STEP_IN_PROGRESS, NULL);
    ASSERT_TRUE(plan->steps[0].status == STEP_IN_PROGRESS, "step 0 in progress");
    ASSERT_TRUE(plan->current_step == 0, "current step is 0");

    agent_plan_update_step(plan, 0, STEP_DONE, "completed successfully");
    ASSERT_TRUE(plan->steps[0].status == STEP_DONE, "step 0 done");
    ASSERT_STR_EQ(plan->steps[0].result_summary, "completed successfully", "summary set");

    agent_plan_update_step(plan, 1, STEP_FAILED, "file not found");
    ASSERT_TRUE(plan->steps[1].status == STEP_FAILED, "step 1 failed");
    ASSERT_STR_EQ(plan->steps[1].result_summary, "file not found", "error summary");

    agent_plan_update_step(plan, 2, STEP_SKIPPED, NULL);
    ASSERT_TRUE(plan->steps[2].status == STEP_SKIPPED, "step 2 skipped");

    agent_plan_free(plan);
    free(plan);
    TEST_PASS("plan_update_step");
}

static void test_plan_format(void) {
    TEST_BEGIN("plan_format");
    AgentPlan *plan = agent_plan_parse("1. Read file\n2. Fix bug\n3. Test\n");
    ASSERT_NOT_NULL(plan, "plan created");

    agent_plan_update_step(plan, 0, STEP_DONE, "read main.c");
    agent_plan_update_step(plan, 1, STEP_IN_PROGRESS, NULL);

    char *fmt = agent_plan_format(plan);
    ASSERT_NOT_NULL(fmt, "format returned");
    ASSERT_TRUE(strstr(fmt, "[x]") != NULL, "shows done marker");
    ASSERT_TRUE(strstr(fmt, "[>]") != NULL, "shows in-progress marker");
    ASSERT_TRUE(strstr(fmt, "[ ]") != NULL, "shows pending marker");
    ASSERT_TRUE(strstr(fmt, "read main.c") != NULL, "shows summary");
    free(fmt);

    agent_plan_free(plan);
    free(plan);
    TEST_PASS("plan_format");
}

static void test_plan_format_empty(void) {
    TEST_BEGIN("plan_format_empty");
    AgentPlan empty = {0};
    char *fmt = agent_plan_format(&empty);
    ASSERT_NOT_NULL(fmt, "format returned");
    ASSERT_TRUE(strstr(fmt, "No active plan") != NULL, "empty plan message");
    free(fmt);
    TEST_PASS("plan_format_empty");
}

static void test_plan_max_steps(void) {
    TEST_BEGIN("plan_max_steps");
    char buf[2048];
    buf[0] = '\0';
    for (int i = 0; i < 30; i++) {
        char line[64];
        snprintf(line, sizeof(line), "%d. Step %d\n", i + 1, i + 1);
        strcat(buf, line);
    }
    AgentPlan *plan = agent_plan_parse(buf);
    ASSERT_NOT_NULL(plan, "plan created");
    ASSERT_TRUE(plan->step_count == AGENT_MAX_PLAN_STEPS, "capped at max steps");
    agent_plan_free(plan);
    free(plan);
    TEST_PASS("plan_max_steps");
}

// === Reflection ===

static void test_reflection_init(void) {
    TEST_BEGIN("reflection_init");
    ReflectionState r;
    reflection_init(&r);
    ASSERT_TRUE(r.consecutive_errors == 0, "no errors initially");
    ASSERT_TRUE(r.total_tool_calls == 0, "no tool calls initially");
    ASSERT_TRUE(r.total_retries == 0, "no retries initially");
    ASSERT_TRUE(r.last_tool_failed == false, "no failure initially");
    ASSERT_NULL(r.last_error, "no error message initially");
    reflection_reset(&r);
    TEST_PASS("reflection_init");
}

static void test_reflection_success(void) {
    TEST_BEGIN("reflection_success");
    ReflectionState r;
    reflection_init(&r);
    reflection_record_tool_result(&r, true, "File content here");
    ASSERT_TRUE(r.total_tool_calls == 1, "1 tool call");
    ASSERT_TRUE(r.consecutive_errors == 0, "no errors");
    ASSERT_TRUE(r.last_tool_failed == false, "not failed");
    reflection_reset(&r);
    TEST_PASS("reflection_success");
}

static void test_reflection_error(void) {
    TEST_BEGIN("reflection_error");
    ReflectionState r;
    reflection_init(&r);
    reflection_record_tool_result(&r, false, "Error: file not found");
    ASSERT_TRUE(r.total_tool_calls == 1, "1 tool call");
    ASSERT_TRUE(r.consecutive_errors == 1, "1 consecutive error");
    ASSERT_TRUE(r.last_tool_failed == true, "failed");
    ASSERT_NOT_NULL(r.last_error, "error message set");
    ASSERT_TRUE(strstr(r.last_error, "Error:") != NULL, "error starts with Error:");
    reflection_reset(&r);
    TEST_PASS("reflection_error");
}

static void test_reflection_consecutive_errors(void) {
    TEST_BEGIN("reflection_consecutive_errors");
    ReflectionState r;
    reflection_init(&r);
    reflection_record_tool_result(&r, false, "Error: first");
    reflection_record_tool_result(&r, false, "Error: second");
    reflection_record_tool_result(&r, false, "Error: third");
    ASSERT_TRUE(r.consecutive_errors == 3, "3 consecutive errors");
    ASSERT_TRUE(reflection_should_retry(&r) == false, "should not retry after 3 errors");
    reflection_reset(&r);
    TEST_PASS("reflection_consecutive_errors");
}

static void test_reflection_retry_eligible(void) {
    TEST_BEGIN("reflection_retry_eligible");
    ReflectionState r;
    reflection_init(&r);
    reflection_record_tool_result(&r, false, "Error: first");
    ASSERT_TRUE(reflection_should_retry(&r) == true, "should retry after 1 error");
    reflection_record_tool_result(&r, false, "Error: second");
    ASSERT_TRUE(reflection_should_retry(&r) == true, "should retry after 2 errors");
    reflection_reset(&r);
    TEST_PASS("reflection_retry_eligible");
}

static void test_reflection_reset_after_success(void) {
    TEST_BEGIN("reflection_reset_after_success");
    ReflectionState r;
    reflection_init(&r);
    reflection_record_tool_result(&r, false, "Error: first");
    ASSERT_TRUE(r.consecutive_errors == 1, "1 error");
    reflection_record_tool_result(&r, true, "OK: success");
    ASSERT_TRUE(r.consecutive_errors == 0, "reset after success");
    ASSERT_TRUE(r.last_tool_failed == false, "not failed after success");
    reflection_reset(&r);
    TEST_PASS("reflection_reset_after_success");
}

static void test_reflection_retry_resets(void) {
    TEST_BEGIN("reflection_retry_resets");
    ReflectionState r;
    reflection_init(&r);
    reflection_record_tool_result(&r, false, "Error: first");
    reflection_record_retry(&r);
    ASSERT_TRUE(r.total_retries == 1, "1 retry recorded");
    ASSERT_TRUE(r.consecutive_errors == 0, "consecutive errors reset");
    reflection_reset(&r);
    TEST_PASS("reflection_retry_resets");
}

static void test_reflection_build_prompt(void) {
    TEST_BEGIN("reflection_build_prompt");
    ReflectionState r;
    reflection_init(&r);
    char *p1 = reflection_build_prompt(&r);
    ASSERT_NOT_NULL(p1, "prompt returned");
    free(p1);

    reflection_record_tool_result(&r, false, "Error: something failed");
    char *p2 = reflection_build_prompt(&r);
    ASSERT_TRUE(p2 != NULL && p2[0] != '\0', "non-empty after error");
    ASSERT_TRUE(strstr(p2, "Reflection") != NULL, "contains reflection header");
    ASSERT_TRUE(strstr(p2, "Error:") != NULL, "contains error info");
    free(p2);
    reflection_reset(&r);
    TEST_PASS("reflection_build_prompt");
}

static void test_reflection_full_reset(void) {
    TEST_BEGIN("reflection_full_reset");
    ReflectionState r;
    reflection_init(&r);
    reflection_record_tool_result(&r, false, "Error: fail");
    reflection_record_tool_result(&r, false, "Error: fail again");
    reflection_record_retry(&r);
    ASSERT_TRUE(r.total_tool_calls == 2, "2 calls");
    ASSERT_TRUE(r.total_retries == 1, "1 retry");
    reflection_reset(&r);
    ASSERT_TRUE(r.total_tool_calls == 0, "reset: 0 calls");
    ASSERT_TRUE(r.total_retries == 0, "reset: 0 retries");
    ASSERT_TRUE(r.consecutive_errors == 0, "reset: 0 errors");
    TEST_PASS("reflection_full_reset");
}

// === Agent Session ===

static void test_session_init(void) {
    TEST_BEGIN("session_init");
    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test");

    LLMContext *ctx = llm_context_create(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);

    AgentSession session;
    agent_session_init(&session, ctx, &reg);
    ASSERT_TRUE(session.ctx == ctx, "ctx set");
    ASSERT_TRUE(session.reg == &reg, "reg set");
    ASSERT_TRUE(session.max_iterations == AGENT_MAX_ITERATIONS, "default max iterations");
    ASSERT_TRUE(session.iteration_count == 0, "0 iterations initially");
    ASSERT_TRUE(session.cancelled == false, "not cancelled");

    agent_session_free(&session);
    llm_context_free(ctx);
    config_free(&cfg);
    tool_registry_free(&reg);
    TEST_PASS("session_init");
}

static void test_session_reset(void) {
    TEST_BEGIN("session_reset");
    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test");

    LLMContext *ctx = llm_context_create(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);

    AgentSession session;
    agent_session_init(&session, ctx, &reg);
    session.iteration_count = 5;
    session.reflection.total_tool_calls = 10;

    agent_session_reset(&session);
    ASSERT_TRUE(session.iteration_count == 0, "iterations reset");
    ASSERT_TRUE(session.reflection.total_tool_calls == 0, "reflection reset");
    ASSERT_TRUE(session.plan.step_count == 0, "plan reset");

    agent_session_free(&session);
    llm_context_free(ctx);
    config_free(&cfg);
    tool_registry_free(&reg);
    TEST_PASS("session_reset");
}

// === Integration: Plan + Reflection ===

static void test_plan_with_reflection(void) {
    TEST_BEGIN("plan_with_reflection");
    AgentPlan *plan = agent_plan_parse("1. Read file\n2. Fix bug\n3. Compile\n4. Test\n");
    ASSERT_NOT_NULL(plan, "plan created");

    ReflectionState refl;
    reflection_init(&refl);

    agent_plan_update_step(plan, 0, STEP_IN_PROGRESS, NULL);

    reflection_record_tool_result(&refl, true, "File content: int main() {}");
    agent_plan_update_step(plan, 0, STEP_DONE, "read main.c");

    agent_plan_update_step(plan, 1, STEP_IN_PROGRESS, NULL);
    reflection_record_tool_result(&refl, false, "Error: write failed - permission denied");
    ASSERT_TRUE(refl.last_tool_failed == true, "tool failed");
    ASSERT_TRUE(reflection_should_retry(&refl) == true, "can retry");

    agent_plan_update_step(plan, 1, STEP_FAILED, refl.last_error);

    char *fmt = agent_plan_format(plan);
    ASSERT_TRUE(strstr(fmt, "[x]") != NULL, "step 1 done");
    ASSERT_TRUE(strstr(fmt, "[!]") != NULL, "step 2 failed");
    ASSERT_TRUE(strstr(fmt, "[ ]") != NULL, "step 3 pending");
    free(fmt);

    char *rp = reflection_build_prompt(&refl);
    ASSERT_TRUE(strstr(rp, "Reflection") != NULL, "has reflection prompt");
    free(rp);

    agent_plan_free(plan);
    free(plan);
    reflection_reset(&refl);
    TEST_PASS("plan_with_reflection");
}

// === Integration: Full agent session with math tools ===

static void test_session_with_math_tools(void) {
    TEST_BEGIN("session_with_math_tools");
    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test");

    LLMContext *ctx = llm_context_create(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_register_module(&reg, math_ops_module_get_module());

    AgentSession session;
    agent_session_init(&session, ctx, &reg);

    cJSON *params = cJSON_Parse("{\"a\":3,\"b\":4}");
    ToolResult result = tool_execute(&reg, "math_add", params);
    ASSERT_TRUE(result.success, "math_add succeeded");
    ASSERT_TRUE(strstr(result.text, "7") != NULL, "3+4=7");
    reflection_record_tool_result(&session.reflection, result.success, result.text);
    ASSERT_TRUE(session.reflection.last_tool_failed == false, "math tool succeeded");
    free(result.text);
    cJSON_Delete(params);

    params = cJSON_Parse("{\"a\":10,\"b\":3}");
    result = tool_execute(&reg, "math_divide", params);
    ASSERT_TRUE(result.success, "divide succeeded");
    reflection_record_tool_result(&session.reflection, result.success, result.text);
    ASSERT_TRUE(session.reflection.consecutive_errors == 0, "no errors");
    free(result.text);
    cJSON_Delete(params);

    ASSERT_TRUE(session.reflection.total_tool_calls == 2, "2 tool calls recorded");

    agent_session_free(&session);
    llm_context_free(ctx);
    config_free(&cfg);
    tool_registry_free(&reg);
    TEST_PASS("session_with_math_tools");
}

// === Integration: Session with file tools and workspace ===

static void test_session_with_file_tools(void) {
    TEST_BEGIN("session_with_file_tools");
    g_tmpdir = test_create_temp_dir();

    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test");

    LLMContext *ctx = llm_context_create(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_registry_set_workspace(&reg, g_tmpdir);
    tool_register_module(&reg, file_ops_module_get_module());

    AgentSession session;
    agent_session_init(&session, ctx, &reg);

    cJSON *wp = cJSON_Parse("{\"path\":\"test.txt\",\"content\":\"hello world\"}");
    ToolResult result = tool_execute(&reg, "write_file", wp);
    ASSERT_TRUE(result.success, "write succeeded");
    reflection_record_tool_result(&session.reflection, result.success, result.text);
    free(result.text);
    cJSON_Delete(wp);

    wp = cJSON_Parse("{\"path\":\"test.txt\"}");
    result = tool_execute(&reg, "read_file", wp);
    ASSERT_TRUE(result.success, "read succeeded");
    ASSERT_TRUE(strstr(result.text, "hello world") != NULL, "read correct content");
    reflection_record_tool_result(&session.reflection, result.success, result.text);
    free(result.text);
    cJSON_Delete(wp);

    ASSERT_TRUE(session.reflection.total_tool_calls == 2, "2 tool calls");
    ASSERT_TRUE(session.reflection.consecutive_errors == 0, "no errors");

    agent_session_free(&session);
    llm_context_free(ctx);
    config_free(&cfg);
    tool_registry_free(&reg);
    test_cleanup_temp_dir();
    TEST_PASS("session_with_file_tools");
}

// === Integration: Reflection with error recovery flow ===

static void test_reflection_error_recovery(void) {
    TEST_BEGIN("reflection_error_recovery");
    ReflectionState r;
    reflection_init(&r);

    reflection_record_tool_result(&r, false, "Error: file not found");
    ASSERT_TRUE(r.consecutive_errors == 1, "1 error");
    ASSERT_TRUE(reflection_should_retry(&r) == true, "can retry");

    reflection_record_tool_result(&r, true, "OK: file found on retry");
    ASSERT_TRUE(r.consecutive_errors == 0, "errors reset after success");
    ASSERT_TRUE(r.last_tool_failed == false, "not failed");

    char *prompt = reflection_build_prompt(&r);
    ASSERT_NOT_NULL(prompt, "prompt generated");
    free(prompt);

    reflection_reset(&r);
    TEST_PASS("reflection_error_recovery");
}

// === Stress: Plan edge cases ===

static void test_plan_parse_whitespace_only(void) {
    TEST_BEGIN("plan_parse_whitespace_only");
    AgentPlan *plan = agent_plan_parse("   \n  \n  \t\n");
    ASSERT_NULL(plan, "null for whitespace-only input");
    TEST_PASS("plan_parse_whitespace_only");
}

static void test_plan_parse_single_step(void) {
    TEST_BEGIN("plan_parse_single_step");
    AgentPlan *plan = agent_plan_parse("1. Do something\n");
    ASSERT_NOT_NULL(plan, "plan created");
    ASSERT_TRUE(plan->step_count == 1, "1 step");
    ASSERT_STR_EQ(plan->steps[0].description, "Do something", "step desc");
    agent_plan_free(plan);
    free(plan);
    TEST_PASS("plan_parse_single_step");
}

static void test_plan_parse_paren_numbered(void) {
    TEST_BEGIN("plan_parse_paren_numbered");
    AgentPlan *plan = agent_plan_parse("1) First\n2) Second\n3) Third\n");
    ASSERT_NOT_NULL(plan, "plan created");
    ASSERT_TRUE(plan->step_count == 3, "3 steps");
    ASSERT_STR_EQ(plan->steps[0].description, "First", "step 1");
    agent_plan_free(plan);
    free(plan);
    TEST_PASS("plan_parse_paren_numbered");
}

static void test_plan_update_invalid_index(void) {
    TEST_BEGIN("plan_update_invalid_index");
    AgentPlan *plan = agent_plan_parse("1. Step one\n2. Step two\n");
    ASSERT_NOT_NULL(plan, "plan created");
    agent_plan_update_step(plan, -1, STEP_DONE, "bad");
    agent_plan_update_step(plan, 99, STEP_DONE, "bad");
    ASSERT_TRUE(plan->steps[0].status == STEP_PENDING, "step 0 unchanged");
    ASSERT_TRUE(plan->steps[1].status == STEP_PENDING, "step 1 unchanged");
    agent_plan_free(plan);
    free(plan);
    TEST_PASS("plan_update_invalid_index");
}

static void test_plan_format_null(void) {
    TEST_BEGIN("plan_format_null");
    char *fmt = agent_plan_format(NULL);
    ASSERT_NOT_NULL(fmt, "returns string for NULL");
    ASSERT_TRUE(strstr(fmt, "No active plan") != NULL, "no plan message");
    free(fmt);
    TEST_PASS("plan_format_null");
}

static void test_plan_update_step_replaces_summary(void) {
    TEST_BEGIN("plan_update_step_replaces_summary");
    AgentPlan *plan = agent_plan_parse("1. Step one\n");
    agent_plan_update_step(plan, 0, STEP_DONE, "first summary");
    ASSERT_STR_EQ(plan->steps[0].result_summary, "first summary", "first summary");
    agent_plan_update_step(plan, 0, STEP_DONE, "second summary");
    ASSERT_STR_EQ(plan->steps[0].result_summary, "second summary", "summary replaced");
    agent_plan_free(plan);
    free(plan);
    TEST_PASS("plan_update_step_replaces_summary");
}

// === Stress: Reflection state machine ===

static void test_reflection_alternating_errors_success(void) {
    TEST_BEGIN("reflection_alternating_errors_success");
    ReflectionState r;
    reflection_init(&r);
    reflection_record_tool_result(&r, false, "Error: fail 1");
    ASSERT_TRUE(r.consecutive_errors == 1, "1 error");
    reflection_record_tool_result(&r, true, "OK: success");
    ASSERT_TRUE(r.consecutive_errors == 0, "reset");
    reflection_record_tool_result(&r, false, "Error: fail 2");
    ASSERT_TRUE(r.consecutive_errors == 1, "1 error again");
    reflection_record_tool_result(&r, false, "Error: fail 3");
    ASSERT_TRUE(r.consecutive_errors == 2, "2 consecutive");
    ASSERT_TRUE(reflection_should_retry(&r) == true, "can retry at 2");
    reflection_record_tool_result(&r, false, "Error: fail 4");
    ASSERT_TRUE(reflection_should_retry(&r) == false, "cannot retry at 3");
    reflection_reset(&r);
    TEST_PASS("reflection_alternating_errors_success");
}

static void test_reflection_many_tool_calls(void) {
    TEST_BEGIN("reflection_many_tool_calls");
    ReflectionState r;
    reflection_init(&r);
    for (int i = 0; i < 10; i++) {
        reflection_record_tool_result(&r, true, "OK: success");
    }
    ASSERT_TRUE(r.total_tool_calls == 10, "10 calls");
    ASSERT_TRUE(r.consecutive_errors == 0, "no errors");
    char *prompt = reflection_build_prompt(&r);
    ASSERT_NOT_NULL(prompt, "prompt returned");
    ASSERT_TRUE(strstr(prompt, "Progress") != NULL, "shows progress for 10+ calls");
    free(prompt);
    reflection_reset(&r);
    TEST_PASS("reflection_many_tool_calls");
}

static void test_reflection_error_after_many_successes(void) {
    TEST_BEGIN("reflection_error_after_many_successes");
    ReflectionState r;
    reflection_init(&r);
    for (int i = 0; i < 8; i++) {
        reflection_record_tool_result(&r, true, "OK: success");
    }
    reflection_record_tool_result(&r, false, "Error: sudden failure");
    ASSERT_TRUE(r.consecutive_errors == 1, "1 error after successes");
    ASSERT_TRUE(r.total_tool_calls == 9, "9 total calls");
    ASSERT_TRUE(reflection_should_retry(&r) == true, "can retry");
    char *prompt = reflection_build_prompt(&r);
    ASSERT_TRUE(strstr(prompt, "Reflection") != NULL, "has reflection");
    ASSERT_TRUE(strstr(prompt, "Progress") != NULL, "has progress");
    free(prompt);
    reflection_reset(&r);
    TEST_PASS("reflection_error_after_many_successes");
}

static void test_reflection_last_error_updated(void) {
    TEST_BEGIN("reflection_last_error_updated");
    ReflectionState r;
    reflection_init(&r);
    reflection_record_tool_result(&r, false, "Error: first error");
    ASSERT_STR_EQ(r.last_error, "Error: first error", "first error stored");
    reflection_record_tool_result(&r, false, "Error: second error");
    ASSERT_STR_EQ(r.last_error, "Error: second error", "second error replaces first");
    reflection_record_tool_result(&r, true, "OK: success");
    ASSERT_TRUE(r.last_tool_failed == false, "success clears fail flag");
    reflection_reset(&r);
    TEST_PASS("reflection_last_error_updated");
}

static void test_reflection_null_and_empty_result(void) {
    TEST_BEGIN("reflection_null_and_empty_result");
    ReflectionState r;
    reflection_init(&r);
    reflection_record_tool_result(&r, true, NULL);
    ASSERT_TRUE(r.total_tool_calls == 1, "null counted");
    ASSERT_TRUE(r.consecutive_errors == 0, "null not error");
    reflection_record_tool_result(&r, true, "");
    ASSERT_TRUE(r.total_tool_calls == 2, "empty counted");
    ASSERT_TRUE(r.consecutive_errors == 0, "empty not error");
    reflection_reset(&r);
    TEST_PASS("reflection_null_and_empty_result");
}

// === Stress: Callbacks integration ===

typedef struct {
    int text_calls;
    int thinking_calls;
    int tool_call_calls;
    int tool_result_calls;
    char last_tool_name[64];
    bool last_result_truncated;
} CallbackTracker;

static void tracker_on_text(void *ud, const char *text, size_t len) {
    CallbackTracker *t = (CallbackTracker *)ud;
    t->text_calls++;
    (void)text; (void)len;
}

static void tracker_on_thinking(void *ud, const char *text, size_t len) {
    CallbackTracker *t = (CallbackTracker *)ud;
    t->thinking_calls++;
    (void)text; (void)len;
}

static void tracker_on_tool_call(void *ud, const char *name, const char *input_json) {
    CallbackTracker *t = (CallbackTracker *)ud;
    t->tool_call_calls++;
    snprintf(t->last_tool_name, sizeof(t->last_tool_name), "%s", name);
    (void)input_json;
}

static void tracker_on_tool_result(void *ud, const char *result, bool truncated) {
    CallbackTracker *t = (CallbackTracker *)ud;
    t->tool_result_calls++;
    t->last_result_truncated = truncated;
    (void)result;
}

static void test_session_callbacks_with_tools(void) {
    TEST_BEGIN("session_callbacks_with_tools");
    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test");

    LLMContext *ctx = llm_context_create(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_register_module(&reg, math_ops_module_get_module());

    AgentSession session;
    agent_session_init(&session, ctx, &reg);

    CallbackTracker tracker = {0};
    session.output.on_tool_call = tracker_on_tool_call;
    session.output.on_tool_result = tracker_on_tool_result;
    session.output.user_data = &tracker;

    cJSON *params = cJSON_Parse("{\"a\":5,\"b\":3}");
    ToolResult result = tool_execute(&reg, "math_add", params);
    ASSERT_TRUE(result.success, "execute succeeded");

    cJSON *fake_tool_call = cJSON_CreateArray();
    cJSON *item = cJSON_CreateObject();
    cJSON_AddStringToObject(item, "id", "call_1");
    cJSON_AddStringToObject(item, "name", "math_add");
    cJSON_AddItemToObject(item, "input", cJSON_Duplicate(params, 1));
    cJSON_AddItemToArray(fake_tool_call, item);

    llm_append_assistant_tool_calls(ctx, "", fake_tool_call);

    cJSON *id_field = cJSON_GetObjectItem(item, "id");
    llm_append_tool_result(ctx, id_field->valuestring, result.text);
    free(result.text);
    cJSON_Delete(params);
    cJSON_Delete(fake_tool_call);

    agent_session_free(&session);
    llm_context_free(ctx);
    config_free(&cfg);
    tool_registry_free(&reg);
    TEST_PASS("session_callbacks_with_tools");
}

// === Stress: Cancellation ===

static void test_session_cancel_flag(void) {
    TEST_BEGIN("session_cancel_flag");
    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test");

    LLMContext *ctx = llm_context_create(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);

    AgentSession session;
    agent_session_init(&session, ctx, &reg);

    ASSERT_TRUE(session.cancelled == false, "not cancelled initially");
    atomic_store(&session.cancelled, true);
    ASSERT_TRUE(atomic_load(&session.cancelled) == true, "cancelled flag set");
    atomic_store(&session.cancelled, false);
    ASSERT_TRUE(atomic_load(&session.cancelled) == false, "cancelled flag cleared");

    agent_session_free(&session);
    llm_context_free(ctx);
    config_free(&cfg);
    tool_registry_free(&reg);
    TEST_PASS("session_cancel_flag");
}

// === Stress: Multiple sessions lifecycle ===

static void test_session_lifecycle_multiple(void) {
    TEST_BEGIN("session_lifecycle_multiple");
    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test");

    LLMContext *ctx = llm_context_create(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_register_module(&reg, math_ops_module_get_module());

    for (int round = 0; round < 5; round++) {
        AgentSession session;
        agent_session_init(&session, ctx, &reg);

        cJSON *params = cJSON_Parse("{\"a\":1,\"b\":2}");
        ToolResult result = tool_execute(&reg, "math_add", params);
        reflection_record_tool_result(&session.reflection, result.success, result.text);
        ASSERT_TRUE(session.reflection.total_tool_calls == 1, "1 call per round");
        free(result.text);
        cJSON_Delete(params);

        agent_session_free(&session);
    }

    llm_context_free(ctx);
    config_free(&cfg);
    tool_registry_free(&reg);
    TEST_PASS("session_lifecycle_multiple");
}

// === Stress: Plan + Reflection full flow ===

static void test_full_plan_reflection_flow(void) {
    TEST_BEGIN("full_plan_reflection_flow");
    AgentPlan *plan = agent_plan_parse(
        "1. Read source file\n"
        "2. Identify bug\n"
        "3. Fix the bug\n"
        "4. Compile\n"
        "5. Run tests\n");
    ASSERT_NOT_NULL(plan, "plan created");
    ASSERT_TRUE(plan->step_count == 5, "5 steps");

    ReflectionState refl;
    reflection_init(&refl);

    agent_plan_update_step(plan, 0, STEP_IN_PROGRESS, NULL);
    reflection_record_tool_result(&refl, true, "File content: int main() { return 1; }");
    ASSERT_TRUE(refl.consecutive_errors == 0, "no errors on read");
    agent_plan_update_step(plan, 0, STEP_DONE, "read main.c");

    agent_plan_update_step(plan, 1, STEP_IN_PROGRESS, NULL);
    reflection_record_tool_result(&refl, true, "Bug found: returns 1 instead of 0");
    agent_plan_update_step(plan, 1, STEP_DONE, "bug: return value");

    agent_plan_update_step(plan, 2, STEP_IN_PROGRESS, NULL);
    reflection_record_tool_result(&refl, true, "OK: file written");
    agent_plan_update_step(plan, 2, STEP_DONE, "fixed return value");

    agent_plan_update_step(plan, 3, STEP_IN_PROGRESS, NULL);
    reflection_record_tool_result(&refl, false, "Error: compilation error - missing semicolon");
    ASSERT_TRUE(refl.consecutive_errors == 1, "1 error");
    ASSERT_TRUE(reflection_should_retry(&refl) == true, "can retry");
    agent_plan_update_step(plan, 3, STEP_FAILED, "compilation error");

    char *refl_prompt = reflection_build_prompt(&refl);
    ASSERT_TRUE(strstr(refl_prompt, "Reflection") != NULL, "has reflection");
    ASSERT_TRUE(strstr(refl_prompt, "compilation error") != NULL, "has error detail");
    free(refl_prompt);

    reflection_record_tool_result(&refl, true, "OK: compiled successfully");
    ASSERT_TRUE(refl.consecutive_errors == 0, "errors reset after success");
    agent_plan_update_step(plan, 3, STEP_DONE, "compiled after fix");

    agent_plan_update_step(plan, 4, STEP_IN_PROGRESS, NULL);
    reflection_record_tool_result(&refl, true, "OK: all tests pass");
    agent_plan_update_step(plan, 4, STEP_DONE, "tests pass");

    char *fmt = agent_plan_format(plan);
    ASSERT_TRUE(strstr(fmt, "[x]") != NULL, "has done markers");
    ASSERT_TRUE(strstr(fmt, "[!]") == NULL, "no failed markers after recovery");
    free(fmt);

    agent_plan_free(plan);
    free(plan);
    reflection_reset(&refl);
    TEST_PASS("full_plan_reflection_flow");
}

// === Stress: Session reset preserves context ===

static void test_session_reset_preserves_context(void) {
    TEST_BEGIN("session_reset_preserves_context");
    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test");

    LLMContext *ctx = llm_context_create(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);

    AgentSession session;
    agent_session_init(&session, ctx, &reg);

    llm_append_user_message(ctx, "first message");
    llm_append_assistant_text(ctx, "first response");

    session.iteration_count = 10;
    session.reflection.total_tool_calls = 5;
    session.reflection.consecutive_errors = 3;

    agent_session_reset(&session);
    ASSERT_TRUE(session.iteration_count == 0, "iterations reset");
    ASSERT_TRUE(session.reflection.total_tool_calls == 0, "reflection reset");
    ASSERT_TRUE(ctx->msg_count == 2, "LLM context preserved across reset");

    agent_session_free(&session);
    llm_context_free(ctx);
    config_free(&cfg);
    tool_registry_free(&reg);
    TEST_PASS("session_reset_preserves_context");
}

// === Stress: Streaming callback setup ===

static void test_session_output_setup(void) {
    TEST_BEGIN("session_output_setup");
    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test");

    LLMContext *ctx = llm_context_create(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);

    AgentSession session;
    agent_session_init(&session, ctx, &reg);

    ASSERT_TRUE(session.output.on_text == NULL, "no output callback initially");

    session.output.on_text = tracker_on_text;
    session.output.on_thinking = tracker_on_thinking;
    session.output.user_data = &session;

    ASSERT_TRUE(session.output.on_text != NULL, "output callback set");

    agent_session_free(&session);
    llm_context_free(ctx);
    config_free(&cfg);
    tool_registry_free(&reg);
    TEST_PASS("session_output_setup");
}

// === Stress: Tool result with large content ===

static void test_session_large_tool_result_handling(void) {
    TEST_BEGIN("session_large_tool_result_handling");
    g_tmpdir = test_create_temp_dir();

    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test");

    LLMContext *ctx = llm_context_create(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_registry_set_workspace(&reg, g_tmpdir);
    tool_register_module(&reg, file_ops_module_get_module());

    AgentSession session;
    agent_session_init(&session, ctx, &reg);

    char path_buf[512];
    snprintf(path_buf, sizeof(path_buf), "%s/big.txt", g_tmpdir);
    FILE *f = fopen(path_buf, "w");
    ASSERT_NOT_NULL(f, "file created");
    char big_line[201];
    memset(big_line, 'A', 200);
    big_line[200] = '\n';
    big_line[201] = '\0';
    for (int i = 0; i < 10; i++) {
        fwrite(big_line, 1, 201, f);
    }
    fclose(f);

    cJSON *rp = cJSON_Parse("{\"path\":\"big.txt\"}");
    ToolResult result = tool_execute(&reg, "read_file", rp);
    ASSERT_TRUE(result.success, "read succeeded");
    reflection_record_tool_result(&session.reflection, result.success, result.text);
    free(result.text);
    cJSON_Delete(rp);

    agent_session_free(&session);
    llm_context_free(ctx);
    config_free(&cfg);
    tool_registry_free(&reg);
    test_cleanup_temp_dir();
    TEST_PASS("session_large_tool_result_handling");
}

// ============================================================

int main(void) {
    g_tmpdir = test_create_temp_dir();

    test_plan_parse_numbered();
    test_plan_parse_bullet();
    test_plan_parse_empty();
    test_plan_parse_mixed();
    test_plan_update_step();
    test_plan_format();
    test_plan_format_empty();
    test_plan_max_steps();

    test_reflection_init();
    test_reflection_success();
    test_reflection_error();
    test_reflection_consecutive_errors();
    test_reflection_retry_eligible();
    test_reflection_reset_after_success();
    test_reflection_retry_resets();
    test_reflection_build_prompt();
    test_reflection_full_reset();

    test_session_init();
    test_session_reset();
    test_plan_with_reflection();
    test_session_with_math_tools();
    test_session_with_file_tools();
    test_reflection_error_recovery();

    test_plan_parse_whitespace_only();
    test_plan_parse_single_step();
    test_plan_parse_paren_numbered();
    test_plan_update_invalid_index();
    test_plan_format_null();
    test_plan_update_step_replaces_summary();

    test_reflection_alternating_errors_success();
    test_reflection_many_tool_calls();
    test_reflection_error_after_many_successes();
    test_reflection_last_error_updated();
    test_reflection_null_and_empty_result();

    test_session_callbacks_with_tools();
    test_session_cancel_flag();
    test_session_lifecycle_multiple();
    test_full_plan_reflection_flow();
    test_session_reset_preserves_context();
    test_session_output_setup();
    test_session_large_tool_result_handling();

    printf("\n%d tests, %d failures\n", g_tests_run, g_tests_failed);
    test_cleanup_temp_dir();
    return g_tests_failed > 0 ? 1 : 0;
}
