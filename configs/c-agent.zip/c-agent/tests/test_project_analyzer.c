#include "test_framework.h"
#include "cJSON.h"
#include "tools/file_ops.h"
#include "tools/project_analyzer.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *g_tmpdir;
static ToolContext g_ctx;

static void write_raw(const char *rel_path, const char *content) {
    char full[1024];
    snprintf(full, sizeof(full), "%s/%s", g_tmpdir, rel_path);
    FILE *f = fopen(full, "w");
    if (f) { fputs(content, f); fclose(f); }
}

int main(void) {
    g_tmpdir = test_create_temp_dir();
    snprintf(g_ctx.workspace, sizeof(g_ctx.workspace), "%s", g_tmpdir);
    printf("=== test_project_analyzer ===\n");
    printf("  workspace: %s\n", g_tmpdir);

    /* analyze basic project */
    TEST_BEGIN("analyze_basic");
    {
        write_raw("main.c", "int main() { return 0; }\n");
        write_raw("util.c", "void util() {}\n");
        write_raw("README.md", "# Test\n");

        cJSON *p = cJSON_Parse("{}");
        ToolResult r = tool_analyze_project("analyze_project", p, &g_ctx);
        ASSERT_TRUE(r.success, "analyze succeeded");
        ASSERT_STR_CONTAINS(r.text, "Files: 3", "3 files counted");
        ASSERT_STR_CONTAINS(r.text, "main.c", "main.c in tree");
        ASSERT_STR_CONTAINS(r.text, "util.c", "util.c in tree");
        ASSERT_STR_CONTAINS(r.text, "README.md", "README.md in tree");
        ASSERT_STR_CONTAINS(r.text, "Lines:", "line count present");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("analyze_basic");

    /* analyze subdirectory */
    TEST_BEGIN("analyze_subdir");
    {
        char cmd[512];
        snprintf(cmd, sizeof(cmd), "mkdir -p %s/src", g_tmpdir);
        system(cmd);
        write_raw("src/app.c", "void app() {}\n");

        cJSON *p = cJSON_Parse("{\"path\":\"src\"}");
        ToolResult r = tool_analyze_project("analyze_project", p, &g_ctx);
        ASSERT_TRUE(r.success, "analyze subdir succeeded");
        ASSERT_STR_CONTAINS(r.text, "Files: 1", "1 file in subdir");
        ASSERT_STR_CONTAINS(r.text, "app.c", "app.c in tree");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("analyze_subdir");

    /* analyze empty directory */
    TEST_BEGIN("analyze_empty");
    {
        char empty_path[512];
        snprintf(empty_path, sizeof(empty_path), "%s/empty_proj", g_tmpdir);
        mkdir(empty_path, 0755);

        cJSON *p = cJSON_Parse("{\"path\":\"empty_proj\"}");
        ToolResult r = tool_analyze_project("analyze_project", p, &g_ctx);
        ASSERT_TRUE(r.success, "analyze empty succeeded");
        ASSERT_STR_CONTAINS(r.text, "Files: 0", "0 files in empty dir");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("analyze_empty");

    /* analyze skips artifacts */
    TEST_BEGIN("analyze_skips_artifacts");
    {
        write_raw("good.c", "int x;\n");
        write_raw("build.o", "binary\n");
        write_raw("deps.d", "deps\n");

        char mkdir_cmd[512];
        snprintf(mkdir_cmd, sizeof(mkdir_cmd), "mkdir -p %s/artifact_test", g_tmpdir);
        system(mkdir_cmd);
        char path[1024];
        snprintf(path, sizeof(path), "%s/artifact_test/good.c", g_tmpdir);
        FILE *f = fopen(path, "w"); fputs("int x;\n", f); fclose(f);
        snprintf(path, sizeof(path), "%s/artifact_test/build.o", g_tmpdir);
        f = fopen(path, "wb"); fwrite("\x00\x01\x02", 1, 3, f); fclose(f);
        snprintf(path, sizeof(path), "%s/artifact_test/deps.d", g_tmpdir);
        f = fopen(path, "w"); fputs("deps\n", f); fclose(f);

        cJSON *p = cJSON_Parse("{\"path\":\"artifact_test\"}");
        ToolResult r = tool_analyze_project("analyze_project", p, &g_ctx);
        ASSERT_TRUE(r.success, "analyze succeeded");
        ASSERT_STR_CONTAINS(r.text, "good.c", "source file listed");
        ASSERT_STR_NOT_CONTAINS(r.text, "build.o", ".o files skipped");
        ASSERT_STR_NOT_CONTAINS(r.text, "deps.d", ".d files skipped");
        ASSERT_STR_CONTAINS(r.text, "Files: 1", "only 1 file counted");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("analyze_skips_artifacts");

    /* grep basic */
    TEST_BEGIN("grep_basic");
    {
        write_raw("grep_a.c", "void hello() {}\nvoid world() {}\n");
        write_raw("grep_b.c", "int hello = 1;\n");

        cJSON *p = cJSON_Parse("{\"pattern\":\"hello\"}");
        ToolResult r = tool_grep_project("grep_project", p, &g_ctx);
        ASSERT_TRUE(r.success, "grep succeeded");
        ASSERT_STR_CONTAINS(r.text, "hello", "match found");
        ASSERT_STR_CONTAINS(r.text, ":", "file:line format");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("grep_basic");

    /* grep no matches */
    TEST_BEGIN("grep_no_matches");
    {
        cJSON *p = cJSON_Parse("{\"pattern\":\"zzzzz_no_such_thing\"}");
        ToolResult r = tool_grep_project("grep_project", p, &g_ctx);
        ASSERT_TRUE(r.success, "grep no matches succeeded");
        ASSERT_STR_CONTAINS(r.text, "No matches found", "no matches message");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("grep_no_matches");

    /* grep with file_pattern */
    TEST_BEGIN("grep_file_pattern");
    {
        write_raw("search_me.txt", "hello in text file\n");
        write_raw("search_me.c", "hello in c file\n");

        cJSON *p = cJSON_Parse("{\"pattern\":\"hello\",\"file_pattern\":\".c\"}");
        ToolResult r = tool_grep_project("grep_project", p, &g_ctx);
        ASSERT_TRUE(r.success, "grep with pattern succeeded");
        ASSERT_STR_CONTAINS(r.text, "search_me.c", ".c file matched");
        ASSERT_STR_NOT_CONTAINS(r.text, "search_me.txt", ".txt file excluded");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("grep_file_pattern");

    printf("\n%d tests, %d failures\n", g_tests_run, g_tests_failed);
    test_cleanup_temp_dir();
    return g_tests_failed > 0 ? 1 : 0;
}
