#include "test_framework.h"
#include "cJSON.h"
#include "tools/math_ops.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

static const ToolContext dummy_ctx = {.workspace = "/tmp"};

void test_add_positive(void) {
    TEST_BEGIN("add_positive");
    cJSON *p = cJSON_Parse("{\"a\":3,\"b\":4}");
    ToolResult r = tool_math_add("math_add", p, &dummy_ctx);
    ASSERT_TRUE(r.success, "succeeded");
    ASSERT_STR_EQ(r.text, "7", "3+4=7");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("add_positive");
}

void test_add_negative(void) {
    TEST_BEGIN("add_negative");
    cJSON *p = cJSON_Parse("{\"a\":-5,\"b\":3}");
    ToolResult r = tool_math_add("math_add", p, &dummy_ctx);
    ASSERT_TRUE(r.success, "succeeded");
    ASSERT_STR_EQ(r.text, "-2", "-5+3=-2");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("add_negative");
}

void test_add_zero(void) {
    TEST_BEGIN("add_zero");
    cJSON *p = cJSON_Parse("{\"a\":0,\"b\":0}");
    ToolResult r = tool_math_add("math_add", p, &dummy_ctx);
    ASSERT_TRUE(r.success, "succeeded");
    ASSERT_STR_EQ(r.text, "0", "0+0=0");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("add_zero");
}

void test_add_floats(void) {
    TEST_BEGIN("add_floats");
    cJSON *p = cJSON_Parse("{\"a\":1.5,\"b\":2.5}");
    ToolResult r = tool_math_add("math_add", p, &dummy_ctx);
    ASSERT_TRUE(r.success, "succeeded");
    ASSERT_STR_EQ(r.text, "4", "1.5+2.5=4 (integral result)");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("add_floats");
}

void test_subtract(void) {
    TEST_BEGIN("subtract");
    cJSON *p = cJSON_Parse("{\"a\":10,\"b\":3}");
    ToolResult r = tool_math_subtract("math_subtract", p, &dummy_ctx);
    ASSERT_TRUE(r.success, "succeeded");
    ASSERT_STR_EQ(r.text, "7", "10-3=7");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("subtract");
}

void test_multiply(void) {
    TEST_BEGIN("multiply");
    cJSON *p = cJSON_Parse("{\"a\":6,\"b\":7}");
    ToolResult r = tool_math_multiply("math_multiply", p, &dummy_ctx);
    ASSERT_TRUE(r.success, "succeeded");
    ASSERT_STR_EQ(r.text, "42", "6*7=42");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("multiply");
}

void test_multiply_default(void) {
    TEST_BEGIN("multiply_default_b");
    cJSON *p = cJSON_Parse("{\"a\":5}");
    ToolResult r = tool_math_multiply("math_multiply", p, &dummy_ctx);
    ASSERT_TRUE(r.success, "succeeded");
    ASSERT_STR_EQ(r.text, "5", "5*1=5 (b defaults to 1)");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("multiply_default_b");
}

void test_divide(void) {
    TEST_BEGIN("divide");
    cJSON *p = cJSON_Parse("{\"a\":10,\"b\":2}");
    ToolResult r = tool_math_divide("math_divide", p, &dummy_ctx);
    ASSERT_TRUE(r.success, "succeeded");
    ASSERT_STR_EQ(r.text, "5", "10/2=5");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("divide");
}

void test_divide_non_integral(void) {
    TEST_BEGIN("divide_non_integral");
    cJSON *p = cJSON_Parse("{\"a\":10,\"b\":3}");
    ToolResult r = tool_math_divide("math_divide", p, &dummy_ctx);
    ASSERT_TRUE(r.success, "succeeded");
    ASSERT_TRUE(strstr(r.text, "3.3") != NULL, "10/3 should be ~3.33");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("divide_non_integral");
}

void test_divide_by_zero(void) {
    TEST_BEGIN("divide_by_zero");
    cJSON *p = cJSON_Parse("{\"a\":5,\"b\":0}");
    ToolResult r = tool_math_divide("math_divide", p, &dummy_ctx);
    ASSERT_FALSE(r.success, "should fail");
    ASSERT_STR_CONTAINS(r.text, "Division by zero", "divide by zero error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("divide_by_zero");
}

void test_missing_params(void) {
    TEST_BEGIN("missing_params_defaults");
    cJSON *p = cJSON_Parse("{}");
    ToolResult r = tool_math_add("math_add", p, &dummy_ctx);
    ASSERT_TRUE(r.success, "succeeded");
    ASSERT_STR_EQ(r.text, "0", "add with no params = 0+0=0");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("missing_params_defaults");
}

int main(void) {
    printf("=== test_math_ops ===\n");
    test_add_positive();
    test_add_negative();
    test_add_zero();
    test_add_floats();
    test_subtract();
    test_multiply();
    test_multiply_default();
    test_divide();
    test_divide_non_integral();
    test_divide_by_zero();
    test_missing_params();
    printf("\n%d tests, %d failures\n", g_tests_run, g_tests_failed);
    return g_tests_failed > 0 ? 1 : 0;
}
