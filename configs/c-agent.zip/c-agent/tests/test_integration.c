#include "test_framework.h"
#include "cJSON.h"
#include "tools/file_ops.h"
#include "tools/compiler.h"
#include "tools/math_ops.h"
#include "tools/project_analyzer.h"
#include "tool_engine.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *g_tmpdir;
static ToolContext g_ctx;

static void write_raw(const char *rel_path, const char *content) {
    char full[1024];
    snprintf(full, sizeof(full), "%s/%s", g_tmpdir, rel_path);
    FILE *f = fopen(full, "w");
    if (f) { fputs(content, f); fclose(f); }
}

static void write_via_tool(const char *path, const char *content) {
    cJSON *p = cJSON_Parse("{}");
    cJSON_AddStringToObject(p, "path", path);
    cJSON_AddStringToObject(p, "content", content);
    ToolResult r = tool_write_file("write_file", p, &g_ctx);
    free(r.text);
    cJSON_Delete(p);
}

/* 1. Hello World C */
void test_hello_world_c(void) {
    TEST_BEGIN("hello_world_c");
    write_via_tool("hello.c",
        "#include <stdio.h>\n"
        "int main(void) {\n"
        "    printf(\"Hello, World!\\n\");\n"
        "    return 0;\n"
        "}\n");

    cJSON *cp = cJSON_Parse("{\"command\":\"gcc hello.c -o hello\"}");
    ToolResult cr = tool_compile("compile", cp, &g_ctx);
    ASSERT_TRUE(cr.success, "compile succeeded");
    ASSERT_STR_CONTAINS(cr.text, "COMPILE SUCCESS", "compile hello.c");
    free(cr.text); cJSON_Delete(cp);

    cJSON *rp = cJSON_Parse("{\"command\":\"./hello\"}");
    ToolResult rr = tool_shell("shell", rp, &g_ctx);
    ASSERT_STR_CONTAINS(rr.text, "Hello, World!", "correct output");
    free(rr.text); cJSON_Delete(rp);
    TEST_PASS("hello_world_c");
}

/* 2. Multi-file C project with Makefile */
void test_multifile_c(void) {
    TEST_BEGIN("multifile_c_project");
    write_via_tool("greeter.h",
        "#ifndef GREETER_H\n"
        "#define GREETER_H\n"
        "void greet(const char *name);\n"
        "#endif\n");
    write_via_tool("greeter.c",
        "#include <stdio.h>\n"
        "#include \"greeter.h\"\n"
        "void greet(const char *name) {\n"
        "    printf(\"Hello, %s!\\n\", name);\n"
        "}\n");
    write_via_tool("main.c",
        "#include \"greeter.h\"\n"
        "int main(void) {\n"
        "    greet(\"World\");\n"
        "    return 0;\n"
        "}\n");
    write_via_tool("Makefile",
        "CC=gcc\n"
        "CFLAGS=-Wall\n"
        "app: main.o greeter.o\n"
        "\t$(CC) $(CFLAGS) -o app main.o greeter.o\n"
        "main.o: main.c greeter.h\n"
        "\t$(CC) $(CFLAGS) -c main.c\n"
        "greeter.o: greeter.c greeter.h\n"
        "\t$(CC) $(CFLAGS) -c greeter.c\n"
        "clean:\n"
        "\trm -f *.o app\n");

    cJSON *cp = cJSON_Parse("{}");
    ToolResult cr = tool_compile("compile", cp, &g_ctx);
    ASSERT_TRUE(cr.success, "make succeeded");
    ASSERT_STR_CONTAINS(cr.text, "COMPILE SUCCESS", "make multi-file project");
    free(cr.text); cJSON_Delete(cp);

    cJSON *rp = cJSON_Parse("{\"command\":\"./app\"}");
    ToolResult rr = tool_shell("shell", rp, &g_ctx);
    ASSERT_STR_CONTAINS(rr.text, "Hello, World!", "multi-file output correct");
    free(rr.text); cJSON_Delete(rp);
    TEST_PASS("multifile_c_project");
}

/* 3. C++ project */
void test_cpp_project(void) {
    TEST_BEGIN("cpp_project");
    write_via_tool("hello.cpp",
        "#include <iostream>\n"
        "int main() {\n"
        "    std::cout << \"C++ works!\" << std::endl;\n"
        "    return 0;\n"
        "}\n");

    cJSON *cp = cJSON_Parse("{\"command\":\"g++ hello.cpp -o hello_cpp\"}");
    ToolResult cr = tool_compile("compile", cp, &g_ctx);
    ASSERT_TRUE(cr.success, "C++ compile succeeded");
    ASSERT_STR_CONTAINS(cr.text, "COMPILE SUCCESS", "compile C++");
    free(cr.text); cJSON_Delete(cp);

    cJSON *rp = cJSON_Parse("{\"command\":\"./hello_cpp\"}");
    ToolResult rr = tool_shell("shell", rp, &g_ctx);
    ASSERT_STR_CONTAINS(rr.text, "C++ works!", "C++ output correct");
    free(rr.text); cJSON_Delete(rp);
    TEST_PASS("cpp_project");
}

/* 4. Error detection and fix */
void test_error_detect_and_fix(void) {
    TEST_BEGIN("error_detect_and_fix");
    write_via_tool("calc.c",
        "#include <stdio.h>\n"
        "int main(void) {\n"
        "    int result = 2 + 3;\n"
        "    printf(\"Result: %d\\n\", result);\n"
        "    return 0;\n"
        "}\n");

    cJSON *cp = cJSON_Parse("{\"command\":\"gcc calc.c -o calc\"}");
    ToolResult cr = tool_compile("compile", cp, &g_ctx);
    ASSERT_TRUE(cr.success, "compile succeeded");
    ASSERT_STR_CONTAINS(cr.text, "COMPILE SUCCESS", "initial compile ok");
    free(cr.text); cJSON_Delete(cp);

    cJSON *rp = cJSON_Parse("{\"command\":\"./calc\"}");
    ToolResult rr = tool_shell("shell", rp, &g_ctx);
    ASSERT_STR_CONTAINS(rr.text, "Result: 5", "correct result 5");
    free(rr.text); cJSON_Delete(rp);

    cJSON *sp = cJSON_Parse("{\"path\":\"calc.c\",\"pattern\":\"result\"}");
    ToolResult sr = tool_search_in_file("search_in_file", sp, &g_ctx);
    ASSERT_TRUE(sr.success, "search succeeded");
    ASSERT_STR_CONTAINS(sr.text, "Found", "search found result variable");
    free(sr.text); cJSON_Delete(sp);
    TEST_PASS("error_detect_and_fix");
}

/* 5. Full development workflow */
void test_full_workflow(void) {
    TEST_BEGIN("full_workflow");
    write_via_tool("counter.c",
        "#include <stdio.h>\n"
        "int counter = 0;\n"
        "void increment(void) { counter++; }\n"
        "void print_counter(void) { printf(\"%d\\n\", counter); }\n");
    write_via_tool("main2.c",
        "#include <stdio.h>\n"
        "extern int counter;\n"
        "extern void increment(void);\n"
        "extern void print_counter(void);\n"
        "int main(void) {\n"
        "    increment();\n"
        "    increment();\n"
        "    increment();\n"
        "    print_counter();\n"
        "    return 0;\n"
        "}\n");

    /* Analyze project */
    cJSON *ap = cJSON_Parse("{}");
    ToolResult ar = tool_analyze_project("analyze_project", ap, &g_ctx);
    ASSERT_TRUE(ar.success, "analyze succeeded");
    ASSERT_STR_CONTAINS(ar.text, "counter.c", "counter.c found");
    ASSERT_STR_CONTAINS(ar.text, "main2.c", "main2.c found");
    free(ar.text); cJSON_Delete(ap);

    /* Grep for function */
    cJSON *gp = cJSON_Parse("{\"pattern\":\"increment\",\"file_pattern\":\".c\"}");
    ToolResult gr = tool_grep_project("grep_project", gp, &g_ctx);
    ASSERT_TRUE(gr.success, "grep succeeded");
    ASSERT_STR_CONTAINS(gr.text, "increment", "increment found in grep");
    free(gr.text); cJSON_Delete(gp);

    /* Compile and run */
    cJSON *cp = cJSON_Parse("{\"command\":\"gcc main2.c counter.c -o counter_app\"}");
    ToolResult cr = tool_compile("compile", cp, &g_ctx);
    ASSERT_TRUE(cr.success, "compile workflow succeeded");
    ASSERT_STR_CONTAINS(cr.text, "COMPILE SUCCESS", "compile workflow project");
    free(cr.text); cJSON_Delete(cp);

    cJSON *rp = cJSON_Parse("{\"command\":\"./counter_app\"}");
    ToolResult rr = tool_shell("shell", rp, &g_ctx);
    ASSERT_STR_CONTAINS(rr.text, "3", "counter at 3 after 3 increments");
    free(rr.text); cJSON_Delete(rp);
    TEST_PASS("full_workflow");
}

/* 6. File lifecycle */
void test_file_lifecycle(void) {
    TEST_BEGIN("file_lifecycle");
    /* Write */
    cJSON *wp = cJSON_Parse("{\"path\":\"life.txt\",\"content\":\"lifecycle test\"}");
    ToolResult wr = tool_write_file("write_file", wp, &g_ctx);
    ASSERT_TRUE(wr.success, "write ok");
    ASSERT_STR_CONTAINS(wr.text, "OK", "write ok");
    free(wr.text);

    /* Read */
    ToolResult rr = tool_read_file("read_file", wp, &g_ctx);
    ASSERT_TRUE(rr.success, "read ok");
    ASSERT_STR_CONTAINS(rr.text, "lifecycle test", "read content ok");
    free(rr.text);

    /* List */
    cJSON *lp = cJSON_Parse("{}");
    ToolResult lr = tool_list_files("list_files", lp, &g_ctx);
    ASSERT_TRUE(lr.success, "list ok");
    ASSERT_STR_CONTAINS(lr.text, "life.txt", "listed ok");
    free(lr.text); cJSON_Delete(lp);

    /* Search */
    cJSON *sp = cJSON_Parse("{\"path\":\"life.txt\",\"pattern\":\"cycle\"}");
    ToolResult sr = tool_search_in_file("search_in_file", sp, &g_ctx);
    ASSERT_TRUE(sr.success, "search ok");
    ASSERT_STR_CONTAINS(sr.text, "Found 1 matches", "search found");
    free(sr.text); cJSON_Delete(sp);

    /* Delete */
    ToolResult dr = tool_delete_file("delete_file", wp, &g_ctx);
    ASSERT_TRUE(dr.success, "delete ok");
    ASSERT_STR_CONTAINS(dr.text, "OK: Deleted", "delete ok");
    free(dr.text);

    /* Verify gone */
    ToolResult rr2 = tool_read_file("read_file", wp, &g_ctx);
    ASSERT_FALSE(rr2.success, "should fail");
    ASSERT_STR_CONTAINS(rr2.text, "Error: File not found", "file gone after delete");
    free(rr2.text);
    cJSON_Delete(wp);
    TEST_PASS("file_lifecycle");
}

/* 7. Math + code */
void test_math_in_code(void) {
    TEST_BEGIN("math_in_code");
    static const ToolContext math_ctx = {.workspace = "/tmp"};
    cJSON *mp = cJSON_Parse("{\"a\":7,\"b\":6}");
    ToolResult mr = tool_math_multiply("math_multiply", mp, &math_ctx);
    ASSERT_TRUE(mr.success, "math succeeded");
    ASSERT_STR_EQ(mr.text, "42", "7*6=42");
    cJSON_Delete(mp);

    char code[256];
    snprintf(code, sizeof(code),
        "#include <stdio.h>\n"
        "int main(void) {\n"
        "    printf(\"%%d\\n\", %s);\n"
        "    return 0;\n"
        "}\n", mr.text);
    free(mr.text);

    write_via_tool("computed.c", code);
    cJSON *cp = cJSON_Parse("{\"command\":\"gcc computed.c -o computed\"}");
    ToolResult cr = tool_compile("compile", cp, &g_ctx);
    ASSERT_TRUE(cr.success, "compile computed");
    ASSERT_STR_CONTAINS(cr.text, "COMPILE SUCCESS", "compile computed");
    free(cr.text); cJSON_Delete(cp);

    cJSON *rp = cJSON_Parse("{\"command\":\"./computed\"}");
    ToolResult rr = tool_shell("shell", rp, &g_ctx);
    ASSERT_STR_CONTAINS(rr.text, "42", "computed value matches");
    free(rr.text); cJSON_Delete(rp);
    TEST_PASS("math_in_code");
}

/* 8. Header dependency chain */
void test_header_deps(void) {
    TEST_BEGIN("header_deps");
    write_via_tool("config.h",
        "#define VERSION \"1.0\"\n"
        "#define MAX_SIZE 100\n");
    write_via_tool("utils.h",
        "#ifndef UTILS_H\n"
        "#define UTILS_H\n"
        "#include \"config.h\"\n"
        "int get_max(void);\n"
        "#endif\n");
    write_via_tool("utils.c",
        "#include \"utils.h\"\n"
        "int get_max(void) { return MAX_SIZE; }\n");
    write_via_tool("dep_main.c",
        "#include <stdio.h>\n"
        "#include \"config.h\"\n"
        "#include \"utils.h\"\n"
        "int main(void) {\n"
        "    printf(\"v%s max=%d\\n\", VERSION, get_max());\n"
        "    return 0;\n"
        "}\n");

    cJSON *cp = cJSON_Parse("{\"command\":\"gcc dep_main.c utils.c -o dep_app\"}");
    ToolResult cr = tool_compile("compile", cp, &g_ctx);
    ASSERT_TRUE(cr.success, "compile deps succeeded");
    ASSERT_STR_CONTAINS(cr.text, "COMPILE SUCCESS", "compile with header deps");
    free(cr.text); cJSON_Delete(cp);

    cJSON *rp = cJSON_Parse("{\"command\":\"./dep_app\"}");
    ToolResult rr = tool_shell("shell", rp, &g_ctx);
    ASSERT_STR_CONTAINS(rr.text, "v1.0 max=100", "header deps output correct");
    free(rr.text); cJSON_Delete(rp);
    TEST_PASS("header_deps");
}

int main(void) {
    g_tmpdir = test_create_temp_dir();
    snprintf(g_ctx.workspace, sizeof(g_ctx.workspace), "%s", g_tmpdir);
    printf("=== test_integration ===\n");
    printf("  workspace: %s\n", g_tmpdir);

    test_hello_world_c();
    test_multifile_c();
    test_cpp_project();
    test_error_detect_and_fix();
    test_full_workflow();
    test_file_lifecycle();
    test_math_in_code();
    test_header_deps();

    printf("\n%d tests, %d failures\n", g_tests_run, g_tests_failed);
    test_cleanup_temp_dir();
    return g_tests_failed > 0 ? 1 : 0;
}
