#include "test_framework.h"
#include "cJSON.h"
#include "tools/file_ops.h"
#include "tools/compiler.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *g_tmpdir;
static ToolContext g_ctx;

static void write_raw(const char *rel_path, const char *content) {
    char full[1024];
    snprintf(full, sizeof(full), "%s/%s", g_tmpdir, rel_path);
    FILE *f = fopen(full, "w");
    if (f) { fputs(content, f); fclose(f); }
}

int main(void) {
    g_tmpdir = test_create_temp_dir();
    snprintf(g_ctx.workspace, sizeof(g_ctx.workspace), "%s", g_tmpdir);
    printf("=== test_compiler ===\n");
    printf("  workspace: %s\n", g_tmpdir);

    /* compile simple C */
    TEST_BEGIN("compile_simple_c");
    {
        write_raw("hello.c",
            "#include <stdio.h>\n"
            "int main(void) {\n"
            "    printf(\"Hello!\\n\");\n"
            "    return 0;\n"
            "}\n");
        cJSON *p = cJSON_Parse("{\"command\":\"gcc hello.c -o hello\"}");
        ToolResult r = tool_compile("compile", p, &g_ctx);
        ASSERT_TRUE(r.success, "compile succeeded");
        ASSERT_STR_CONTAINS(r.text, "COMPILE SUCCESS", "compile success");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("compile_simple_c");

    /* compile error */
    TEST_BEGIN("compile_error");
    {
        write_raw("bad.c",
            "#include <stdio.h>\n"
            "int main(void) {\n"
            "    this is not valid C\n"
            "    return 0;\n"
            "}\n");
        cJSON *p = cJSON_Parse("{\"command\":\"gcc bad.c -o bad 2>&1\"}");
        ToolResult r = tool_compile("compile", p, &g_ctx);
        ASSERT_STR_CONTAINS(r.text, "COMPILE FAILED", "compile failed");
        ASSERT_STR_CONTAINS(r.text, "exit code:", "exit code reported");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("compile_error");

    /* compile with Makefile */
    TEST_BEGIN("compile_makefile");
    {
        write_raw("main.c",
            "#include <stdio.h>\n"
            "int main(void) { printf(\"make!\\n\"); return 0; }\n");
        write_raw("Makefile",
            "CC=gcc\n"
            "all:\n"
            "\t$(CC) main.c -o myapp\n");
        cJSON *p = cJSON_Parse("{}");
        ToolResult r = tool_compile("compile", p, &g_ctx);
        ASSERT_TRUE(r.success, "make succeeded");
        ASSERT_STR_CONTAINS(r.text, "COMPILE SUCCESS", "make default target");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("compile_makefile");

    /* shell simple */
    TEST_BEGIN("shell_simple");
    {
        write_raw("data.txt", "test content here");
        cJSON *p = cJSON_Parse("{\"command\":\"cat data.txt\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell succeeded");
        ASSERT_STR_CONTAINS(r.text, "Exit code: 0", "exit code 0");
        ASSERT_STR_CONTAINS(r.text, "test content here", "output contains data");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_simple");

    /* shell missing command */
    TEST_BEGIN("shell_missing");
    {
        cJSON *p = cJSON_Parse("{}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_FALSE(r.success, "should fail");
        ASSERT_STR_CONTAINS(r.text, "Missing", "missing command error");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_missing");

    /* shell exit code */
    TEST_BEGIN("shell_exit_code");
    {
        cJSON *p = cJSON_Parse("{\"command\":\"exit 42\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell executed");
        ASSERT_STR_CONTAINS(r.text, "Exit code: 42", "non-zero exit code");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_exit_code");

    /* run_tests pass */
    TEST_BEGIN("run_tests_pass");
    {
        write_raw("Makefile",
            "test:\n"
            "\t@echo 'All tests passed'\n");
        cJSON *p = cJSON_Parse("{}");
        ToolResult r = tool_run_tests("run_tests", p, &g_ctx);
        ASSERT_TRUE(r.success, "tests passed");
        ASSERT_STR_CONTAINS(r.text, "TESTS PASSED", "tests pass");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("run_tests_pass");

    /* run_tests fail */
    TEST_BEGIN("run_tests_fail");
    {
        write_raw("Makefile",
            "test:\n"
            "\t@echo 'FAIL' && exit 1\n");
        cJSON *p = cJSON_Parse("{}");
        ToolResult r = tool_run_tests("run_tests", p, &g_ctx);
        ASSERT_STR_CONTAINS(r.text, "TESTS FAILED", "tests fail");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("run_tests_fail");

    /* shell pipe */
    TEST_BEGIN("shell_pipe");
    {
        write_raw("pipe_test.txt", "banana\napple\ncherry\napple pie\n");
        cJSON *p = cJSON_Parse("{\"command\":\"cat pipe_test.txt | grep apple | sort\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell pipe succeeded");
        ASSERT_STR_CONTAINS(r.text, "apple", "grep found apple");
        ASSERT_STR_CONTAINS(r.text, "apple pie", "grep found apple pie");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_pipe");

    /* shell redirect write */
    TEST_BEGIN("shell_redirect_write");
    {
        cJSON *p = cJSON_Parse("{\"command\":\"echo redirected_content > redir_out.txt\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell redirect succeeded");
        ASSERT_STR_CONTAINS(r.text, "Exit code: 0", "redirect exit 0");
        free(r.text); cJSON_Delete(p);

        char full[1024];
        snprintf(full, sizeof(full), "%s/redir_out.txt", g_tmpdir);
        FILE *f = fopen(full, "r");
        ASSERT_NOT_NULL(f, "redirected file exists");
        char buf[256];
        if (fgets(buf, sizeof(buf), f)) {
            ASSERT_STR_CONTAINS(buf, "redirected_content", "file has redirected content");
        }
        fclose(f);
    }
    TEST_PASS("shell_redirect_write");

    /* shell redirect append */
    TEST_BEGIN("shell_redirect_append");
    {
        write_raw("append.txt", "first line\n");
        cJSON *p = cJSON_Parse("{\"command\":\"echo 'second line' >> append.txt\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell append succeeded");
        free(r.text); cJSON_Delete(p);

        char full[1024];
        snprintf(full, sizeof(full), "%s/append.txt", g_tmpdir);
        FILE *f = fopen(full, "r");
        ASSERT_NOT_NULL(f, "append file exists");
        char buf[512];
        buf[0] = '\0';
        size_t n = fread(buf, 1, sizeof(buf) - 1, f);
        buf[n] = '\0';
        fclose(f);
        ASSERT_STR_CONTAINS(buf, "first line", "original content preserved");
        ASSERT_STR_CONTAINS(buf, "second line", "appended content present");
    }
    TEST_PASS("shell_redirect_append");

    /* shell command chaining with && */
    TEST_BEGIN("shell_chain_and");
    {
        cJSON *p = cJSON_Parse("{\"command\":\"mkdir -p chain_test && echo chain_dir > chain_test/flag.txt && cat chain_test/flag.txt\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell chain succeeded");
        ASSERT_STR_CONTAINS(r.text, "chain_dir", "chained output correct");
        ASSERT_STR_CONTAINS(r.text, "Exit code: 0", "chain exit 0");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_chain_and");

    /* shell chain stops on failure */
    TEST_BEGIN("shell_chain_failure");
    {
        cJSON *p = cJSON_Parse("{\"command\":\"false && echo should_not_appear\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell executed");
        ASSERT_STR_NOT_CONTAINS(r.text, "should_not_appear", "&& stops on failure");
        ASSERT_STR_NOT_CONTAINS(r.text, "Exit code: 0", "non-zero exit");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_chain_failure");

    /* shell environment variable */
    TEST_BEGIN("shell_env_var");
    {
        cJSON *p = cJSON_Parse("{\"command\":\"MY_VAR=hello_agent && echo $MY_VAR\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell env succeeded");
        ASSERT_STR_CONTAINS(r.text, "hello_agent", "env var expanded");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_env_var");

    /* shell command substitution */
    TEST_BEGIN("shell_cmd_subst");
    {
        cJSON *p = cJSON_Parse("{\"command\":\"echo result_$(echo nested)\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell cmd subst succeeded");
        ASSERT_STR_CONTAINS(r.text, "result_nested", "command substitution works");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_cmd_subst");

    /* shell multiple commands with ; */
    TEST_BEGIN("shell_semicolon");
    {
        cJSON *p = cJSON_Parse("{\"command\":\"echo first; echo second\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell semicolon succeeded");
        ASSERT_STR_CONTAINS(r.text, "first", "first command output");
        ASSERT_STR_CONTAINS(r.text, "second", "second command output");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_semicolon");

    /* shell heredoc */
    TEST_BEGIN("shell_heredoc");
    {
        cJSON *p = cJSON_Parse("{\"command\":\"cat << 'EOF'\\nline one\\nline two\\nEOF\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell heredoc succeeded");
        ASSERT_STR_CONTAINS(r.text, "line one", "heredoc content line 1");
        ASSERT_STR_CONTAINS(r.text, "line two", "heredoc content line 2");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_heredoc");

    /* shell glob expansion */
    TEST_BEGIN("shell_glob");
    {
        write_raw("glob_a.txt", "a");
        write_raw("glob_b.txt", "b");
        write_raw("glob_c.c", "c");
        cJSON *p = cJSON_Parse("{\"command\":\"ls *.txt | sort\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell glob succeeded");
        ASSERT_STR_CONTAINS(r.text, "glob_a.txt", "glob matched a");
        ASSERT_STR_CONTAINS(r.text, "glob_b.txt", "glob matched b");
        ASSERT_STR_NOT_CONTAINS(r.text, "glob_c.c", "glob excluded .c");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_glob");

    /* shell tar create and extract */
    TEST_BEGIN("shell_tar");
    {
        char mkdir_cmd[512];
        snprintf(mkdir_cmd, sizeof(mkdir_cmd), "mkdir -p %s/tar_src", g_tmpdir);
        system(mkdir_cmd);
        write_raw("tar_src/file1.txt", "content1");
        write_raw("tar_src/file2.txt", "content2");
        cJSON *p1 = cJSON_Parse("{\"command\":\"tar cf archive.tar -C tar_src . && tar tf archive.tar\"}");
        ToolResult r1 = tool_shell("shell", p1, &g_ctx);
        ASSERT_TRUE(r1.success, "tar create succeeded");
        ASSERT_STR_CONTAINS(r1.text, "file1.txt", "tar contains file1");
        ASSERT_STR_CONTAINS(r1.text, "file2.txt", "tar contains file2");
        free(r1.text); cJSON_Delete(p1);

        cJSON *p2 = cJSON_Parse("{\"command\":\"mkdir -p tar_out && tar xf archive.tar -C tar_out && cat tar_out/file1.txt\"}");
        ToolResult r2 = tool_shell("shell", p2, &g_ctx);
        ASSERT_TRUE(r2.success, "tar extract succeeded");
        ASSERT_STR_CONTAINS(r2.text, "content1", "extracted content correct");
        free(r2.text); cJSON_Delete(p2);
    }
    TEST_PASS("shell_tar");

    /* shell timeout */
    TEST_BEGIN("shell_timeout");
    {
        cJSON *p = cJSON_Parse("{\"command\":\"sleep 10\",\"timeout\":1}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell timeout executed");
        ASSERT_STR_CONTAINS(r.text, "Exit code: 124", "timed out with exit 124");
        ASSERT_STR_CONTAINS(r.text, "timed out", "timeout message");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_timeout");

    /* shell pipe + wc counting */
    TEST_BEGIN("shell_pipe_wc");
    {
        write_raw("wc_test.txt", "line1\nline2\nline3\nline4\nline5\n");
        cJSON *p = cJSON_Parse("{\"command\":\"cat wc_test.txt | wc -l\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell pipe wc succeeded");
        ASSERT_STR_CONTAINS(r.text, "5", "5 lines counted");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_pipe_wc");

    /* shell quoting with special characters */
    TEST_BEGIN("shell_quoting");
    {
        cJSON *p = cJSON_Parse("{\"command\":\"echo \\\"hello 'world' and $HOME\\\"\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell quoting succeeded");
        ASSERT_STR_CONTAINS(r.text, "hello", "output present");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_quoting");

    /* shell symbolic link */
    TEST_BEGIN("shell_symlink");
    {
        write_raw("link_target.txt", "linked content");
        cJSON *p = cJSON_Parse("{\"command\":\"ln -s link_target.txt link_src && cat link_src\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell symlink succeeded");
        ASSERT_STR_CONTAINS(r.text, "linked content", "symlink read correct");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_symlink");

    /* shell find + xargs combo */
    TEST_BEGIN("shell_find_xargs");
    {
        write_raw("xargs_a.c", "TODO: fix this");
        write_raw("xargs_b.c", "nothing here");
        write_raw("xargs_c.c", "TODO: add tests");
        cJSON *p = cJSON_Parse("{\"command\":\"find . -name '*.c' | xargs grep TODO | wc -l\"}");
        ToolResult r = tool_shell("shell", p, &g_ctx);
        ASSERT_TRUE(r.success, "shell find+xargs succeeded");
        /* Should find 2 lines with TODO */
        ASSERT_STR_CONTAINS(r.text, "2", "found 2 TODO lines");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("shell_find_xargs");

    printf("\n%d tests, %d failures\n", g_tests_run, g_tests_failed);
    test_cleanup_temp_dir();
    return g_tests_failed > 0 ? 1 : 0;
}
