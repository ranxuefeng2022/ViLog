#include "test_framework.h"
#include "cJSON.h"
#include "tools/linux_cmds.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static const char *g_tmpdir;
static ToolContext g_ctx;

static void write_raw(const char *rel_path, const char *content) {
    char full[1024];
    snprintf(full, sizeof(full), "%s/%s", g_tmpdir, rel_path);
    FILE *f = fopen(full, "w");
    if (f) { fputs(content, f); fclose(f); }
}

static void mkdir_raw(const char *rel_path) {
    char full[1024];
    snprintf(full, sizeof(full), "%s/%s", g_tmpdir, rel_path);
    mkdir(full, 0755);
}

/* ===== find ===== */

static void test_find_basic(void) {
    TEST_BEGIN("find_basic");
    write_raw("find_a.txt", "aaa");
    write_raw("find_b.c", "bbb");
    mkdir_raw("find_sub");
    write_raw("find_sub/find_c.txt", "ccc");

    cJSON *p = cJSON_Parse("{}");
    ToolResult r = tool_find("find", p, &g_ctx);
    ASSERT_TRUE(r.success, "find succeeded");
    ASSERT_STR_CONTAINS(r.text, "find_a.txt", "file a listed");
    ASSERT_STR_CONTAINS(r.text, "find_b.c", "file b listed");
    ASSERT_STR_CONTAINS(r.text, "find_sub", "subdir listed");
    ASSERT_STR_CONTAINS(r.text, "find_c.txt", "nested file listed");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("find_basic");
}

static void test_find_by_name(void) {
    TEST_BEGIN("find_by_name");
    write_raw("match.txt", "x");
    write_raw("nomatch.c", "y");

    cJSON *p = cJSON_Parse("{\"name\":\"*.txt\"}");
    ToolResult r = tool_find("find", p, &g_ctx);
    ASSERT_TRUE(r.success, "find succeeded");
    ASSERT_STR_CONTAINS(r.text, "match.txt", "matched txt");
    ASSERT_STR_NOT_CONTAINS(r.text, "nomatch.c", "excluded c file");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("find_by_name");
}

static void test_find_by_type(void) {
    TEST_BEGIN("find_by_type");
    write_raw("type_file.txt", "x");
    mkdir_raw("type_dir");

    cJSON *p = cJSON_Parse("{\"type\":\"d\"}");
    ToolResult r = tool_find("find", p, &g_ctx);
    ASSERT_TRUE(r.success, "find succeeded");
    ASSERT_STR_CONTAINS(r.text, "type_dir", "directory found");
    ASSERT_STR_NOT_CONTAINS(r.text, "type_file.txt", "file excluded");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("find_by_type");
}

static void test_find_max_depth(void) {
    TEST_BEGIN("find_max_depth");
    mkdir_raw("depth1");
    mkdir_raw("depth1/depth2");
    write_raw("depth1/depth2/deep.txt", "deep");

    cJSON *p = cJSON_Parse("{\"max_depth\":1}");
    ToolResult r = tool_find("find", p, &g_ctx);
    ASSERT_TRUE(r.success, "find succeeded");
    ASSERT_STR_NOT_CONTAINS(r.text, "deep.txt", "deep file excluded at depth 1");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("find_max_depth");
}

/* ===== fd ===== */

static void test_fd_basic(void) {
    TEST_BEGIN("fd_basic");
    write_raw("fd_test.txt", "x");
    write_raw("fd_other.c", "y");

    cJSON *p = cJSON_Parse("{}");
    ToolResult r = tool_fd("fd", p, &g_ctx);
    ASSERT_TRUE(r.success, "fd succeeded");
    ASSERT_STR_CONTAINS(r.text, "fd_test.txt", "fd found txt");
    ASSERT_STR_CONTAINS(r.text, "fd_other.c", "fd found c");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("fd_basic");
}

static void test_fd_by_extension(void) {
    TEST_BEGIN("fd_by_extension");
    write_raw("fd_ext.txt", "x");
    write_raw("fd_ext.c", "y");

    cJSON *p = cJSON_Parse("{\"extension\":\"txt\"}");
    ToolResult r = tool_fd("fd", p, &g_ctx);
    ASSERT_TRUE(r.success, "fd succeeded");
    ASSERT_STR_CONTAINS(r.text, "fd_ext.txt", "fd matched txt");
    ASSERT_STR_NOT_CONTAINS(r.text, "fd_ext.c", "fd excluded c");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("fd_by_extension");
}

static void test_fd_by_type(void) {
    TEST_BEGIN("fd_by_type");
    mkdir_raw("fd_dir");
    write_raw("fd_file.txt", "x");

    cJSON *p = cJSON_Parse("{\"type\":\"d\"}");
    ToolResult r = tool_fd("fd", p, &g_ctx);
    ASSERT_TRUE(r.success, "fd succeeded");
    ASSERT_STR_CONTAINS(r.text, "fd_dir", "fd found dir");
    ASSERT_STR_NOT_CONTAINS(r.text, "fd_file.txt", "fd excluded file");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("fd_by_type");
}

/* ===== grep ===== */

static void test_grep_basic(void) {
    TEST_BEGIN("grep_basic");
    write_raw("grep_a.txt", "hello world\nfoo bar\n");
    write_raw("grep_b.txt", "hello again\nno match\n");

    cJSON *p = cJSON_Parse("{\"pattern\":\"hello\"}");
    ToolResult r = tool_grep("grep", p, &g_ctx);
    ASSERT_TRUE(r.success, "grep succeeded");
    ASSERT_STR_CONTAINS(r.text, "hello", "match found");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("grep_basic");
}

static void test_grep_include(void) {
    TEST_BEGIN("grep_include");
    write_raw("grep_inc.c", "target_string_here\n");
    write_raw("grep_inc.txt", "target_string_here\n");

    cJSON *p = cJSON_Parse("{\"pattern\":\"target_string\",\"include\":\".c\"}");
    ToolResult r = tool_grep("grep", p, &g_ctx);
    ASSERT_TRUE(r.success, "grep succeeded");
    ASSERT_STR_CONTAINS(r.text, "grep_inc.c", "matched c file");
    ASSERT_STR_NOT_CONTAINS(r.text, "grep_inc.txt", "excluded txt file");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("grep_include");
}

static void test_grep_no_match(void) {
    TEST_BEGIN("grep_no_match");
    write_raw("grep_empty.txt", "nothing relevant\n");

    cJSON *p = cJSON_Parse("{\"pattern\":\"zzzzzz_no_such\"}");
    ToolResult r = tool_grep("grep", p, &g_ctx);
    ASSERT_TRUE(r.success, "grep succeeded");
    ASSERT_STR_CONTAINS(r.text, "Exit code:", "has exit code");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("grep_no_match");
}

static void test_grep_missing_pattern(void) {
    TEST_BEGIN("grep_missing_pattern");
    cJSON *p = cJSON_Parse("{}");
    ToolResult r = tool_grep("grep", p, &g_ctx);
    ASSERT_FALSE(r.success, "should fail");
    ASSERT_STR_CONTAINS(r.text, "Error", "missing pattern error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("grep_missing_pattern");
}

/* ===== rg ===== */

static void test_rg_basic(void) {
    TEST_BEGIN("rg_basic");
    write_raw("rg_a.txt", "search_target_one\n");
    write_raw("rg_b.txt", "search_target_two\n");

    cJSON *p = cJSON_Parse("{\"pattern\":\"search_target\"}");
    ToolResult r = tool_rg("rg", p, &g_ctx);
    ASSERT_TRUE(r.success, "rg succeeded");
    ASSERT_STR_CONTAINS(r.text, "search_target", "rg found match");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("rg_basic");
}

static void test_rg_glob(void) {
    TEST_BEGIN("rg_glob");
    write_raw("rg_glob.c", "rg_pattern_here\n");
    write_raw("rg_glob.txt", "rg_pattern_here\n");

    cJSON *p = cJSON_Parse("{\"pattern\":\"rg_pattern\",\"glob\":\"*.c\"}");
    ToolResult r = tool_rg("rg", p, &g_ctx);
    ASSERT_TRUE(r.success, "rg succeeded");
    ASSERT_STR_CONTAINS(r.text, "rg_glob.c", "rg matched c file");
    ASSERT_STR_NOT_CONTAINS(r.text, "rg_glob.txt", "rg excluded txt file");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("rg_glob");
}

static void test_rg_missing_pattern(void) {
    TEST_BEGIN("rg_missing_pattern");
    cJSON *p = cJSON_Parse("{}");
    ToolResult r = tool_rg("rg", p, &g_ctx);
    ASSERT_FALSE(r.success, "should fail");
    ASSERT_STR_CONTAINS(r.text, "Error", "missing pattern error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("rg_missing_pattern");
}

/* ===== sed ===== */

static void test_sed_substitute(void) {
    TEST_BEGIN("sed_substitute");
    write_raw("sed_test.txt", "hello old world\n");

    cJSON *p = cJSON_Parse("{\"path\":\"sed_test.txt\",\"expression\":\"s/old/new/\"}");
    ToolResult r = tool_sed("sed", p, &g_ctx);
    ASSERT_TRUE(r.success, "sed succeeded");
    ASSERT_STR_CONTAINS(r.text, "hello new world", "sed replaced");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("sed_substitute");
}

static void test_sed_in_place(void) {
    TEST_BEGIN("sed_in_place");
    write_raw("sed_inplace.txt", "color is red\n");

    cJSON *p = cJSON_Parse("{\"path\":\"sed_inplace.txt\",\"expression\":\"s/red/blue/\",\"in_place\":true}");
    ToolResult r = tool_sed("sed", p, &g_ctx);
    ASSERT_TRUE(r.success, "sed in-place succeeded");

    /* Verify file was actually modified */
    char full[1024];
    snprintf(full, sizeof(full), "%s/sed_inplace.txt", g_tmpdir);
    FILE *f = fopen(full, "r");
    ASSERT_NOT_NULL(f, "file exists");
    char buf[256];
    fgets(buf, sizeof(buf), f);
    fclose(f);
    ASSERT_STR_CONTAINS(buf, "blue", "file content changed to blue");
    ASSERT_STR_NOT_CONTAINS(buf, "red", "old content replaced");

    (void)r;
    free(r.text); cJSON_Delete(p);
    TEST_PASS("sed_in_place");
}

static void test_sed_missing_params(void) {
    TEST_BEGIN("sed_missing_params");
    cJSON *p = cJSON_Parse("{\"path\":\"x.txt\"}");
    ToolResult r = tool_sed("sed", p, &g_ctx);
    ASSERT_FALSE(r.success, "should fail");
    ASSERT_STR_CONTAINS(r.text, "Error", "missing expression error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("sed_missing_params");
}

/* ===== awk ===== */

static void test_awk_print_field(void) {
    TEST_BEGIN("awk_print_field");
    write_raw("awk_test.txt", "Alice 30\nBob 25\n");

    cJSON *p = cJSON_Parse("{\"program\":\"{print $1}\",\"path\":\"awk_test.txt\"}");
    ToolResult r = tool_awk("awk", p, &g_ctx);
    ASSERT_TRUE(r.success, "awk succeeded");
    ASSERT_STR_CONTAINS(r.text, "Alice", "first field");
    ASSERT_STR_CONTAINS(r.text, "Bob", "first field row 2");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("awk_print_field");
}

static void test_awk_field_separator(void) {
    TEST_BEGIN("awk_field_separator");
    write_raw("awk_fs.csv", "name,age,city\nAlice,30,NYC\nBob,25,LA\n");

    cJSON *p = cJSON_Parse("{\"program\":\"{print $3}\",\"path\":\"awk_fs.csv\",\"field_separator\":\",\"}");
    ToolResult r = tool_awk("awk", p, &g_ctx);
    ASSERT_TRUE(r.success, "awk succeeded");
    ASSERT_STR_CONTAINS(r.text, "NYC", "third field with comma separator");
    ASSERT_STR_CONTAINS(r.text, "LA", "third field row 2");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("awk_field_separator");
}

static void test_awk_missing_program(void) {
    TEST_BEGIN("awk_missing_program");
    cJSON *p = cJSON_Parse("{}");
    ToolResult r = tool_awk("awk", p, &g_ctx);
    ASSERT_FALSE(r.success, "should fail");
    ASSERT_STR_CONTAINS(r.text, "Error", "missing program error");
    free(r.text); cJSON_Delete(p);
    TEST_PASS("awk_missing_program");
}

int main(void) {
    g_tmpdir = test_create_temp_dir();
    snprintf(g_ctx.workspace, sizeof(g_ctx.workspace), "%s", g_tmpdir);
    printf("=== test_linux_cmds ===\n");
    printf("  workspace: %s\n", g_tmpdir);

    test_find_basic();
    test_find_by_name();
    test_find_by_type();
    test_find_max_depth();

    test_fd_basic();
    test_fd_by_extension();
    test_fd_by_type();

    test_grep_basic();
    test_grep_include();
    test_grep_no_match();
    test_grep_missing_pattern();

    test_rg_basic();
    test_rg_glob();
    test_rg_missing_pattern();

    test_sed_substitute();
    test_sed_in_place();
    test_sed_missing_params();

    test_awk_print_field();
    test_awk_field_separator();
    test_awk_missing_program();

    printf("\n%d tests, %d failures\n", g_tests_run, g_tests_failed);
    test_cleanup_temp_dir();
    return g_tests_failed > 0 ? 1 : 0;
}
