#include "test_framework.h"
#include "cJSON.h"
#include "config.h"
#include "llm_client.h"
#include "tool_engine.h"
#include "tools/file_ops.h"
#include "tools/compiler.h"
#include "tools/project_analyzer.h"
#include "tools/math_ops.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static const char *g_tmpdir;

static char *run_agent(LLMContext *ctx, ToolRegistry *reg, const char *prompt, int max_iters) {
    llm_append_user_message(ctx, prompt);

    for (int i = 0; i < max_iters; i++) {
        LLMResponse resp;
        memset(&resp, 0, sizeof(resp));
        int rc = llm_chat(ctx, NULL, &resp);
        if (rc != 0) {
            char *err = strdup("[API Error]");
            llm_response_free(&resp);
            return err;
        }

        if (resp.is_tool_use && resp.tool_calls) {
            llm_append_assistant_tool_calls(ctx, resp.text, resp.tool_calls);

            cJSON *item;
            cJSON_ArrayForEach(item, resp.tool_calls) {
                const char *id   = cJSON_GetObjectItem(item, "id")->valuestring;
                const char *name = cJSON_GetObjectItem(item, "name")->valuestring;
                cJSON *input     = cJSON_GetObjectItem(item, "input");
                ToolResult result = tool_execute(reg, name, input);
                llm_append_tool_result(ctx, id, result.text);
                free(result.text);
            }
            llm_response_free(&resp);
        } else {
            if (resp.text) {
                llm_append_assistant_text(ctx, resp.text);
            }
            char *final_text = resp.text ? strdup(resp.text) : strdup("");
            llm_response_free(&resp);
            return final_text;
        }
    }
    return strdup("[Max iterations reached]");
}

static void setup_deepseek(AgentConfig *cfg) {
    memset(cfg, 0, sizeof(*cfg));
    cfg->api_key    = strdup(getenv("DEEPSEEK_API_KEY") ? getenv("DEEPSEEK_API_KEY") : "");
    cfg->base_url   = strdup("https://api.deepseek.com/anthropic");
    cfg->model      = strdup("deepseek-v4-pro[1m]");
    cfg->timeout_ms = 60000;
    cfg->workspace_dir = strdup(g_tmpdir);
    cfg->max_tokens   = 4096;
}

static void register_tools(ToolRegistry *reg) {
    tool_register_module(reg, file_ops_module_get_module());
    tool_register_module(reg, compiler_module_get_module());
}

static void sync_tools(LLMContext *ctx, ToolRegistry *reg) {
    for (int i = 0; i < reg->count; i++) {
        if (reg->entries[i].available) {
            llm_register_tool(ctx, reg->entries[i].name,
                              reg->entries[i].description,
                              reg->entries[i].param_schema);
        }
    }
}

static const char *SYSTEM_PROMPT_TEST =
    "You are a coding assistant. All paths are relative to the workspace root.\n"
    "When you need to use a tool, output EXACTLY:\n"
    "TOOL_CALL: {\"name\": \"tool_name\", \"params\": {\"key\": \"value\"}}\n"
    "Available tools: read_file(path), write_file(path, content), list_files(path), shell(command).\n"
    "After using tools, report your findings concisely.\n";

static void write_test_file(const char *name, const char *content) {
    char path[1024];
    snprintf(path, sizeof(path), "%s/%s", g_tmpdir, name);
    FILE *f = fopen(path, "w");
    if (f) { fputs(content, f); fclose(f); }
}

static char *read_test_file(const char *name) {
    char path[1024];
    snprintf(path, sizeof(path), "%s/%s", g_tmpdir, name);
    FILE *f = fopen(path, "r");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = malloc(len + 1);
    fread(buf, 1, len, f);
    buf[len] = '\0';
    fclose(f);
    return buf;
}

static LLMContext *create_context(AgentConfig *cfg) {
    LLMContext *ctx = llm_context_create(cfg);
    ctx->system_prompt = SYSTEM_PROMPT_TEST;
    return ctx;
}

static void test_file_find(void) {
    TEST_BEGIN("file_find");
    write_test_file("main.c", "#include <stdio.h>\nint main() { return 0; }\n");
    write_test_file("utils.c", "int add(int a, int b) { return a + b; }\n");
    write_test_file("README.md", "# Test Project\n");

    AgentConfig cfg;
    setup_deepseek(&cfg);
    LLMContext *ctx = create_context(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_registry_set_workspace(&reg, g_tmpdir);
    register_tools(&reg);
    sync_tools(ctx, &reg);

    char *result = run_agent(ctx, &reg,
        "List the files in the current directory using list_files, and tell me how many .c files there are.",
        5);
    ASSERT_STR_CONTAINS(result, ".c", "should mention .c files");
    free(result);

    llm_context_free(ctx);
    tool_registry_free(&reg);
    config_free(&cfg);
    TEST_PASS("file_find");
}

static void test_file_read(void) {
    TEST_BEGIN("file_read");
    write_test_file("calc.c",
        "#include <stdio.h>\n"
        "int factorial(int n) {\n"
        "    if (n <= 1) return 1;\n"
        "    return n * factorial(n - 1);\n"
        "}\n"
        "int main() {\n"
        "    printf(\"%d\\n\", factorial(5));\n"
        "    return 0;\n"
        "}\n");

    AgentConfig cfg;
    setup_deepseek(&cfg);
    LLMContext *ctx = create_context(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_registry_set_workspace(&reg, g_tmpdir);
    register_tools(&reg);
    sync_tools(ctx, &reg);

    char *result = run_agent(ctx, &reg,
        "Read the file calc.c and tell me what the function factorial does.",
        5);
    ASSERT_STR_CONTAINS(result, "factorial", "should mention factorial");
    free(result);

    llm_context_free(ctx);
    tool_registry_free(&reg);
    config_free(&cfg);
    TEST_PASS("file_read");
}

static void test_file_write(void) {
    TEST_BEGIN("file_write");
    AgentConfig cfg;
    setup_deepseek(&cfg);
    LLMContext *ctx = create_context(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_registry_set_workspace(&reg, g_tmpdir);
    register_tools(&reg);
    sync_tools(ctx, &reg);

    char *result = run_agent(ctx, &reg,
        "Use write_file to create a file called greet.c with this exact content:\n"
        "#include <stdio.h>\nint main() { printf(\"Greetings!\"); return 0; }\n",
        5);
    free(result);

    char *content = read_test_file("greet.c");
    ASSERT_NOT_NULL(content, "greet.c should exist");
    if (content) {
        ASSERT_STR_CONTAINS(content, "printf", "should contain printf");
        free(content);
    }

    llm_context_free(ctx);
    tool_registry_free(&reg);
    config_free(&cfg);
    TEST_PASS("file_write");
}

static void test_bug_fix(void) {
    TEST_BEGIN("bug_fix");
    write_test_file("broken.c",
        "#include <stdio.h>\n"
        "int main() {\n"
        "    int arr[5];\n"
        "    for (int i = 0; i <= 5; i++) {  // off-by-one bug\n"
        "        arr[i] = i * 2;\n"
        "    }\n"
        "    printf(\"%d\\n\", arr[4]);\n"
        "    return 0;\n"
        "}\n");

    AgentConfig cfg;
    setup_deepseek(&cfg);
    LLMContext *ctx = create_context(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_registry_set_workspace(&reg, g_tmpdir);
    register_tools(&reg);
    sync_tools(ctx, &reg);

    char *result = run_agent(ctx, &reg,
        "Read broken.c, find the bug, fix it using write_file, then compile with shell: gcc broken.c -o broken",
        8);
    free(result);

    char *content = read_test_file("broken.c");
    if (content) {
        ASSERT_STR_NOT_CONTAINS(content, "i <= 5", "off-by-one should be fixed");
        free(content);
    }

    llm_context_free(ctx);
    tool_registry_free(&reg);
    config_free(&cfg);
    TEST_PASS("bug_fix");
}

static void test_framework(void) {
    TEST_BEGIN("framework");
    AgentConfig cfg;
    setup_deepseek(&cfg);
    LLMContext *ctx = create_context(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_registry_set_workspace(&reg, g_tmpdir);
    register_tools(&reg);
    sync_tools(ctx, &reg);

    char *result = run_agent(ctx, &reg,
        "Create a simple C project with 3 files using write_file:\n"
        "1. mathutil.h — header with declaration: int add(int a, int b);\n"
        "2. mathutil.c — implementation of add function\n"
        "3. main.c — calls add(3,4) and prints result\n"
        "Then compile with: gcc main.c mathutil.c -o mathapp",
        10);
    free(result);

    char *h = read_test_file("mathutil.h");
    char *c = read_test_file("mathutil.c");
    char *m = read_test_file("main.c");
    ASSERT_NOT_NULL(h, "mathutil.h should exist");
    ASSERT_NOT_NULL(c, "mathutil.c should exist");
    ASSERT_NOT_NULL(m, "main.c should exist");
    if (h) ASSERT_STR_CONTAINS(h, "add", "header should declare add");
    if (c) ASSERT_STR_CONTAINS(c, "add", "impl should define add");
    free(h); free(c); free(m);

    llm_context_free(ctx);
    tool_registry_free(&reg);
    config_free(&cfg);
    TEST_PASS("framework");
}

static void test_code_understand(void) {
    TEST_BEGIN("code_understand");
    write_test_file("stack.h",
        "#ifndef STACK_H\n#define STACK_H\n"
        "void stack_push(int val);\nint stack_pop(void);\nint stack_empty(void);\n"
        "#endif\n");
    write_test_file("stack.c",
        "#include \"stack.h\"\n"
        "static int data[100];\nstatic int top = 0;\n"
        "void stack_push(int val) { data[top++] = val; }\n"
        "int stack_pop(void) { return data[--top]; }\n"
        "int stack_empty(void) { return top == 0; }\n");

    AgentConfig cfg;
    setup_deepseek(&cfg);
    LLMContext *ctx = create_context(&cfg);
    ToolRegistry reg;
    tool_registry_init(&reg);
    tool_registry_set_workspace(&reg, g_tmpdir);
    register_tools(&reg);
    sync_tools(ctx, &reg);

    char *result = run_agent(ctx, &reg,
        "Read stack.h and stack.c, then explain how the stack works and what is its maximum capacity.",
        5);
    ASSERT_STR_CONTAINS(result, "100", "should mention capacity 100");
    ASSERT_STR_CONTAINS(result, "stack", "should mention stack");
    free(result);

    llm_context_free(ctx);
    tool_registry_free(&reg);
    config_free(&cfg);
    TEST_PASS("code_understand");
}

int main(void) {
    g_tmpdir = test_create_temp_dir();

    printf("LLM Integration Tests (workspace: %s)\n", g_tmpdir);
    printf("These tests call real APIs and may take 10-60 seconds each.\n\n");

    test_file_find();
    test_file_read();
    test_file_write();
    test_bug_fix();
    test_framework();
    test_code_understand();

    printf("\n%d tests, %d failures\n", g_tests_run, g_tests_failed);
    test_cleanup_temp_dir();
    return g_tests_failed > 0 ? 1 : 0;
}
