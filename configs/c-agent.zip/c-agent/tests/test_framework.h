#ifndef TEST_FRAMEWORK_H
#define TEST_FRAMEWORK_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int g_tests_run = 0;
static int g_tests_failed = 0;

#define ASSERT_TRUE(cond, msg) do { \
    g_tests_run++; \
    if (!(cond)) { \
        g_tests_failed++; \
        printf("  FAIL [%s:%d] %s\n", __FILE__, __LINE__, msg); \
    } \
} while(0)

#define ASSERT_FALSE(cond, msg) do { \
    g_tests_run++; \
    if (cond) { \
        g_tests_failed++; \
        printf("  FAIL [%s:%d] %s\n", __FILE__, __LINE__, msg); \
    } \
} while(0)

#define ASSERT_STR_EQ(actual, expected, msg) do { \
    g_tests_run++; \
    if (strcmp((actual), (expected)) != 0) { \
        g_tests_failed++; \
        printf("  FAIL [%s:%d] %s\n    got: \"%s\"\n    exp: \"%s\"\n", \
               __FILE__, __LINE__, msg, actual, expected); \
    } \
} while(0)

#define ASSERT_STR_CONTAINS(haystack, needle, msg) do { \
    g_tests_run++; \
    if (!strstr((haystack), (needle))) { \
        g_tests_failed++; \
        printf("  FAIL [%s:%d] %s\n    \"%s\" not found in \"%s\"\n", \
               __FILE__, __LINE__, msg, needle, haystack); \
    } \
} while(0)

#define ASSERT_STR_NOT_CONTAINS(haystack, needle, msg) do { \
    g_tests_run++; \
    if (strstr((haystack), (needle))) { \
        g_tests_failed++; \
        printf("  FAIL [%s:%d] %s\n    \"%s\" unexpectedly found\n", \
               __FILE__, __LINE__, msg, needle); \
    } \
} while(0)

#define ASSERT_INT_EQ(actual, expected, msg) do { \
    g_tests_run++; \
    if ((actual) != (expected)) { \
        g_tests_failed++; \
        printf("  FAIL [%s:%d] %s\n    got: %d, exp: %d\n", \
               __FILE__, __LINE__, msg, (int)(actual), (int)(expected)); \
    } \
} while(0)

#define ASSERT_NOT_NULL(ptr, msg) do { \
    g_tests_run++; \
    if ((ptr) == NULL) { \
        g_tests_failed++; \
        printf("  FAIL [%s:%d] %s\n", __FILE__, __LINE__, msg); \
    } \
} while(0)

#define ASSERT_NULL(ptr, msg) do { \
    g_tests_run++; \
    if ((ptr) != NULL) { \
        g_tests_failed++; \
        printf("  FAIL [%s:%d] %s (expected NULL)\n", __FILE__, __LINE__, msg); \
    } \
} while(0)

static char g_temp_dir[256];

static const char *test_create_temp_dir(void) {
    strcpy(g_temp_dir, "/tmp/cagent_test_XXXXXX");
    char *result = mkdtemp(g_temp_dir);
    if (!result) {
        fprintf(stderr, "FATAL: mkdtemp failed\n");
        exit(1);
    }
    return g_temp_dir;
}

static void test_cleanup_temp_dir(void) {
    if (g_temp_dir[0]) {
        char cmd[512];
        snprintf(cmd, sizeof(cmd), "rm -rf %s", g_temp_dir);
        system(cmd);
        g_temp_dir[0] = '\0';
    }
}

#define TEST_BEGIN(name) printf("  [%s] ", name)
#define TEST_PASS(name) printf("ok\n")

#endif
