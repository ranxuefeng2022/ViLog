#include "test_framework.h"
#include "protocol.h"
#include "cJSON.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ===== Mock transport for testing ===== */

#define MOCK_BUF_SIZE 65536

typedef struct {
    char    output_buf[MOCK_BUF_SIZE];
    size_t  output_len;
} MockData;

static int mock_init(Transport *t, const char *address)
{
    (void)address;
    MockData *data = (MockData *)t->user_data;
    data->output_len = 0;
    data->output_buf[0] = '\0';
    return 0;
}

static TransportReadResult mock_read_message(Transport *t)
{
    (void)t;
    TransportReadResult r = {NULL, true};
    return r;
}

static int mock_write_message(Transport *t, const char *json, size_t len)
{
    MockData *data = (MockData *)t->user_data;
    size_t avail = MOCK_BUF_SIZE - data->output_len - 1;
    size_t to_copy = len < avail ? len : avail;
    memcpy(data->output_buf + data->output_len, json, to_copy);
    data->output_len += to_copy;
    data->output_buf[data->output_len] = '\0';
    /* Append newline separator */
    if (data->output_len < MOCK_BUF_SIZE - 1) {
        data->output_buf[data->output_len++] = '\n';
        data->output_buf[data->output_len] = '\0';
    }
    return 0;
}

static void mock_cleanup(Transport *t)
{
    free(t->user_data);
    t->user_data = NULL;
}

static Transport *create_mock_transport(void)
{
    Transport *t = calloc(1, sizeof(Transport));
    MockData *data = calloc(1, sizeof(MockData));
    t->user_data = data;
    t->init = mock_init;
    t->read_message = mock_read_message;
    t->write_message = mock_write_message;
    t->cleanup = mock_cleanup;
    t->name = "mock";
    return t;
}

static const char *mock_output(Transport *t)
{
    MockData *data = (MockData *)t->user_data;
    return data->output_buf;
}

static void mock_reset(Transport *t)
{
    MockData *data = (MockData *)t->user_data;
    data->output_len = 0;
    data->output_buf[0] = '\0';
}

/* ===== Test: JSON escaping ===== */

static void test_json_escape(void)
{
    TEST_BEGIN("json_escape");
    char *r;

    r = protocol_json_escape("hello", 5);
    ASSERT_STR_EQ(r, "hello", "plain text");
    free(r);

    r = protocol_json_escape("say \"hi\"", 8);
    ASSERT_STR_EQ(r, "say \\\"hi\\\"", "double quotes escaped");
    free(r);

    r = protocol_json_escape("line1\nline2", 11);
    ASSERT_STR_EQ(r, "line1\\nline2", "newline escaped");
    free(r);

    r = protocol_json_escape("tab\there", 8);
    ASSERT_STR_EQ(r, "tab\\there", "tab escaped");
    free(r);

    r = protocol_json_escape("back\\slash", 10);
    ASSERT_STR_EQ(r, "back\\\\slash", "backslash escaped");
    free(r);

    r = protocol_json_escape("", 0);
    ASSERT_TRUE(r == NULL || r[0] == '\0', "empty string");
    free(r);

    TEST_PASS("json_escape");
}

/* ===== Test: JSON-RPC request parsing ===== */

static void test_parse_request_valid(void)
{
    TEST_BEGIN("parse_request_valid");

    int id = 0;
    char *method = NULL;
    char *params = NULL;

    int rc = protocol_parse_request(
        "{\"jsonrpc\":\"2.0\",\"id\":42,\"method\":\"chat/send\",\"params\":{\"message\":\"hello\"}}",
        &id, &method, &params);

    ASSERT_INT_EQ(rc, 0, "parse should succeed");
    ASSERT_INT_EQ(id, 42, "id should be 42");
    ASSERT_STR_EQ(method, "chat/send", "method should be chat/send");
    ASSERT_NOT_NULL(params, "params should not be NULL");
    ASSERT_STR_CONTAINS(params, "hello", "params should contain message");

    free(method);
    free(params);

    TEST_PASS("parse_request_valid");
}

static void test_parse_request_no_id(void)
{
    TEST_BEGIN("parse_request_no_id");

    int id = -1;
    char *method = NULL;
    char *params = NULL;

    int rc = protocol_parse_request(
        "{\"jsonrpc\":\"2.0\",\"method\":\"chat/cancel\",\"params\":{}}",
        &id, &method, &params);

    ASSERT_INT_EQ(rc, 0, "parse should succeed");
    ASSERT_INT_EQ(id, 0, "id should default to 0");
    ASSERT_STR_EQ(method, "chat/cancel", "method should be chat/cancel");

    free(method);
    free(params);

    TEST_PASS("parse_request_no_id");
}

static void test_parse_request_invalid(void)
{
    TEST_BEGIN("parse_request_invalid");

    int id = 0;
    char *method = NULL;
    char *params = NULL;

    ASSERT_INT_EQ(protocol_parse_request("not json", &id, &method, &params), -1,
                  "garbage input should fail");

    ASSERT_INT_EQ(protocol_parse_request("{}", &id, &method, &params), -1,
                  "missing jsonrpc should fail");

    ASSERT_INT_EQ(protocol_parse_request(
        "{\"jsonrpc\":\"1.0\",\"method\":\"test\"}", &id, &method, &params), -1,
                  "wrong jsonrpc version should fail");

    ASSERT_INT_EQ(protocol_parse_request(
        "{\"jsonrpc\":\"2.0\"}", &id, &method, &params), -1,
                  "missing method should fail");

    TEST_PASS("parse_request_invalid");
}

/* ===== Test: JSON-RPC response/error sending ===== */

static void test_send_response(void)
{
    TEST_BEGIN("send_response");

    Transport *t = create_mock_transport();
    t->init(t, NULL);

    ProtocolAdapter adapter;
    protocol_adapter_init(&adapter, t);

    protocol_send_response(&adapter, 1, "{\"status\":\"idle\"}");

    const char *out = mock_output(t);
    ASSERT_STR_CONTAINS(out, "\"id\":1", "should contain id");
    ASSERT_STR_CONTAINS(out, "\"result\":{\"status\":\"idle\"}", "should contain result");
    ASSERT_STR_CONTAINS(out, "\"jsonrpc\":\"2.0\"", "should contain jsonrpc version");

    protocol_adapter_free(&adapter);
    t->cleanup(t);
    free(t);

    TEST_PASS("send_response");
}

static void test_send_error(void)
{
    TEST_BEGIN("send_error");

    Transport *t = create_mock_transport();
    t->init(t, NULL);

    ProtocolAdapter adapter;
    protocol_adapter_init(&adapter, t);

    protocol_send_error(&adapter, 5, -32600, "Parse error");

    const char *out = mock_output(t);
    ASSERT_STR_CONTAINS(out, "\"id\":5", "should contain id");
    ASSERT_STR_CONTAINS(out, "\"code\":-32600", "should contain error code");
    ASSERT_STR_CONTAINS(out, "Parse error", "should contain error message");

    protocol_adapter_free(&adapter);
    t->cleanup(t);
    free(t);

    TEST_PASS("send_error");
}

static void test_send_notification(void)
{
    TEST_BEGIN("send_notification");

    Transport *t = create_mock_transport();
    t->init(t, NULL);

    ProtocolAdapter adapter;
    protocol_adapter_init(&adapter, t);

    protocol_send_notification(&adapter, "{\"type\":\"text\",\"content\":\"hello\"}");

    const char *out = mock_output(t);
    ASSERT_STR_CONTAINS(out, "\"method\":\"notify\"", "should contain notify method");
    ASSERT_STR_CONTAINS(out, "\"type\":\"text\"", "should contain type");
    ASSERT_STR_CONTAINS(out, "\"content\":\"hello\"", "should contain content");

    protocol_adapter_free(&adapter);
    t->cleanup(t);
    free(t);

    TEST_PASS("send_notification");
}

/* ===== Test: AgentOutput callbacks produce valid notifications ===== */

static void test_on_text_callback(void)
{
    TEST_BEGIN("on_text_callback");

    Transport *t = create_mock_transport();
    t->init(t, NULL);

    ProtocolAdapter adapter;
    protocol_adapter_init(&adapter, t);

    AgentOutput output = protocol_adapter_create_output(&adapter);
    output.on_text(&adapter, "Hello world", 11);

    const char *out = mock_output(t);
    ASSERT_STR_CONTAINS(out, "\"type\":\"text\"", "should be text type");
    ASSERT_STR_CONTAINS(out, "Hello world", "should contain text content");

    protocol_adapter_free(&adapter);
    t->cleanup(t);
    free(t);

    TEST_PASS("on_text_callback");
}

static void test_on_text_with_special_chars(void)
{
    TEST_BEGIN("on_text_special_chars");

    Transport *t = create_mock_transport();
    t->init(t, NULL);

    ProtocolAdapter adapter;
    protocol_adapter_init(&adapter, t);

    AgentOutput output = protocol_adapter_create_output(&adapter);
    output.on_text(&adapter, "line1\nline2", 11);

    const char *out = mock_output(t);
    ASSERT_STR_CONTAINS(out, "\\n", "newline should be escaped");
    ASSERT_STR_NOT_CONTAINS(out, "line1\n", "should not contain raw newline in JSON");

    protocol_adapter_free(&adapter);
    t->cleanup(t);
    free(t);

    TEST_PASS("on_text_special_chars");
}

static void test_on_tool_call_callback(void)
{
    TEST_BEGIN("on_tool_call_callback");

    Transport *t = create_mock_transport();
    t->init(t, NULL);

    ProtocolAdapter adapter;
    protocol_adapter_init(&adapter, t);

    AgentOutput output = protocol_adapter_create_output(&adapter);
    output.on_tool_call(&adapter, "read_file", "{\"path\":\"main.c\"}");

    const char *out = mock_output(t);
    ASSERT_STR_CONTAINS(out, "\"type\":\"tool_call\"", "should be tool_call type");
    ASSERT_STR_CONTAINS(out, "read_file", "should contain tool name");
    ASSERT_STR_CONTAINS(out, "main.c", "should contain input");

    protocol_adapter_free(&adapter);
    t->cleanup(t);
    free(t);

    TEST_PASS("on_tool_call_callback");
}

static void test_on_tool_result_callback(void)
{
    TEST_BEGIN("on_tool_result_callback");

    Transport *t = create_mock_transport();
    t->init(t, NULL);

    ProtocolAdapter adapter;
    protocol_adapter_init(&adapter, t);

    AgentOutput output = protocol_adapter_create_output(&adapter);
    output.on_tool_result(&adapter, "file contents here", false);

    const char *out = mock_output(t);
    ASSERT_STR_CONTAINS(out, "\"type\":\"tool_result\"", "should be tool_result type");
    ASSERT_STR_CONTAINS(out, "file contents here", "should contain result");
    ASSERT_STR_CONTAINS(out, "\"truncated\":false", "should show truncated=false");

    protocol_adapter_free(&adapter);
    t->cleanup(t);
    free(t);

    TEST_PASS("on_tool_result_callback");
}

static void test_on_status_callback(void)
{
    TEST_BEGIN("on_status_callback");

    Transport *t = create_mock_transport();
    t->init(t, NULL);

    ProtocolAdapter adapter;
    protocol_adapter_init(&adapter, t);

    AgentOutput output = protocol_adapter_create_output(&adapter);
    output.on_status(&adapter, "Executing tools (iter 1/25)");

    const char *out = mock_output(t);
    ASSERT_STR_CONTAINS(out, "\"type\":\"status\"", "should be status type");
    ASSERT_STR_CONTAINS(out, "Executing tools", "should contain status text");

    protocol_adapter_free(&adapter);
    t->cleanup(t);
    free(t);

    TEST_PASS("on_status_callback");
}

/* ===== Test: Multiple callbacks produce multiple lines ===== */

static void test_multiple_notifications(void)
{
    TEST_BEGIN("multiple_notifications");

    Transport *t = create_mock_transport();
    t->init(t, NULL);

    ProtocolAdapter adapter;
    protocol_adapter_init(&adapter, t);

    AgentOutput output = protocol_adapter_create_output(&adapter);
    output.on_status(&adapter, "starting");
    output.on_text(&adapter, "Hello", 5);
    output.on_text(&adapter, " world", 6);

    const char *out = mock_output(t);
    /* Should contain 3 separate JSON lines */
    int count = 0;
    const char *p = out;
    while ((p = strstr(p, "\"method\":\"notify\"")) != NULL) {
        count++;
        p++;
    }
    ASSERT_INT_EQ(count, 3, "should have 3 notifications");

    protocol_adapter_free(&adapter);
    t->cleanup(t);
    free(t);

    TEST_PASS("multiple_notifications");
}

/* ===== Main ===== */

int main(void)
{
    printf("=== Protocol Tests ===\n\n");

    test_json_escape();
    test_parse_request_valid();
    test_parse_request_no_id();
    test_parse_request_invalid();
    test_send_response();
    test_send_error();
    test_send_notification();
    test_on_text_callback();
    test_on_text_with_special_chars();
    test_on_tool_call_callback();
    test_on_tool_result_callback();
    test_on_status_callback();
    test_multiple_notifications();

    printf("\n  Results: %d/%d passed\n", g_tests_run - g_tests_failed, g_tests_run);
    return g_tests_failed > 0 ? 1 : 0;
}
