#include "test_framework.h"
#include "cJSON.h"
#include "config.h"
#include "llm_client.h"
#include "context.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// === Token Estimation ===

static void test_estimate_tokens_empty(void) {
    TEST_BEGIN("estimate_tokens_empty");
    ASSERT_TRUE(context_estimate_tokens(NULL) == 0, "null text");
    ASSERT_TRUE(context_estimate_tokens("") == 0, "empty text");
    TEST_PASS("estimate_tokens_empty");
}

static void test_estimate_tokens_basic(void) {
    TEST_BEGIN("estimate_tokens_basic");
    int t1 = context_estimate_tokens("hello");
    ASSERT_TRUE(t1 > 0, "positive tokens for 'hello'");
    int t2 = context_estimate_tokens("hello world this is a longer text");
    ASSERT_TRUE(t2 > t1, "longer text has more tokens");
    TEST_PASS("estimate_tokens_basic");
}

static void test_estimate_tokens_ratio(void) {
    TEST_BEGIN("estimate_tokens_ratio");
    char buf[401];
    memset(buf, 'a', 400);
    buf[400] = '\0';
    int tokens = context_estimate_tokens(buf);
    ASSERT_TRUE(tokens == 100, "400 chars = 100 tokens at 4 chars/token");
    TEST_PASS("estimate_tokens_ratio");
}

// === Context Stats ===

static void test_compute_stats_empty(void) {
    TEST_BEGIN("compute_stats_empty");
    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test-model");

    LLMContext *ctx = llm_context_create(&cfg);
    ContextStats stats = context_compute_stats(ctx, "system prompt");
    ASSERT_TRUE(stats.message_count == 0, "no messages");
    ASSERT_TRUE(stats.total_estimated_tokens > 0, "has system prompt tokens");

    llm_context_free(ctx);
    config_free(&cfg);
    TEST_PASS("compute_stats_empty");
}

static void test_compute_stats_with_messages(void) {
    TEST_BEGIN("compute_stats_with_messages");
    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test-model");

    LLMContext *ctx = llm_context_create(&cfg);
    llm_append_user_message(ctx, "Hello, this is a test message");
    llm_append_assistant_text(ctx, "I received your message.");

    ContextStats stats = context_compute_stats(ctx, "system prompt");
    ASSERT_TRUE(stats.message_count == 2, "2 messages");
    ASSERT_TRUE(stats.total_estimated_tokens > 10, "has tokens");

    llm_context_free(ctx);
    config_free(&cfg);
    TEST_PASS("compute_stats_with_messages");
}

// === Raw Context (no truncation) ===

static void test_raw_tool_result(void) {
    TEST_BEGIN("raw_tool_result");
    AgentConfig cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.api_key = strdup("test");
    cfg.base_url = strdup("http://localhost");
    cfg.model = strdup("test-model");

    LLMContext *ctx = llm_context_create(&cfg);

    /* Large tool result is stored completely, no truncation */
    char big[20001];
    memset(big, 'y', 20000);
    big[20000] = '\0';

    llm_append_tool_result(ctx, "tool_1", big);
    ASSERT_TRUE(ctx->msg_count == 1, "one message added");
    ASSERT_TRUE((int)strlen(ctx->messages[0].content) == 20000, "full content preserved");

    llm_context_free(ctx);
    config_free(&cfg);
    TEST_PASS("raw_tool_result");
}

// ============================================================

int main(void) {
    test_estimate_tokens_empty();
    test_estimate_tokens_basic();
    test_estimate_tokens_ratio();
    test_compute_stats_empty();
    test_compute_stats_with_messages();
    test_raw_tool_result();

    printf("\n%d tests, %d failures\n", g_tests_run, g_tests_failed);
    return g_tests_failed > 0 ? 1 : 0;
}
