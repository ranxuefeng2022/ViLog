#include "test_framework.h"
#include "cJSON.h"
#include "tools/file_ops.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *g_tmpdir;
static ToolContext g_ctx;

static void write_raw(const char *rel_path, const char *content) {
    char full[1024];
    snprintf(full, sizeof(full), "%s/%s", g_tmpdir, rel_path);
    FILE *f = fopen(full, "w");
    if (f) { fputs(content, f); fclose(f); }
}

int main(void) {
    g_tmpdir = test_create_temp_dir();
    snprintf(g_ctx.workspace, sizeof(g_ctx.workspace), "%s", g_tmpdir);
    printf("=== test_file_ops ===\n");
    printf("  workspace: %s\n", g_tmpdir);

    /* write_file basic */
    TEST_BEGIN("write_file_basic");
    {
        cJSON *p = cJSON_Parse("{\"path\":\"hello.txt\",\"content\":\"hello world\"}");
        ToolResult r = tool_write_file("write_file", p, &g_ctx);
        ASSERT_TRUE(r.success, "write succeeded");
        ASSERT_STR_CONTAINS(r.text, "OK: Written", "write success");
        ASSERT_STR_CONTAINS(r.text, "hello.txt", "filename in result");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("write_file_basic");

    /* write_file subdir */
    TEST_BEGIN("write_file_subdir");
    {
        cJSON *p = cJSON_Parse("{\"path\":\"sub/dir/nested.txt\",\"content\":\"deep\"}");
        ToolResult r = tool_write_file("write_file", p, &g_ctx);
        ASSERT_TRUE(r.success, "write subdir succeeded");
        ASSERT_STR_CONTAINS(r.text, "OK: Written", "auto-create parent dirs");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("write_file_subdir");

    /* write_file missing path */
    TEST_BEGIN("write_file_missing_path");
    {
        cJSON *p = cJSON_Parse("{\"content\":\"data\"}");
        ToolResult r = tool_write_file("write_file", p, &g_ctx);
        ASSERT_FALSE(r.success, "should fail");
        ASSERT_STR_CONTAINS(r.text, "Error", "missing path error");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("write_file_missing_path");

    /* write_file missing content */
    TEST_BEGIN("write_file_missing_content");
    {
        cJSON *p = cJSON_Parse("{\"path\":\"x.txt\"}");
        ToolResult r = tool_write_file("write_file", p, &g_ctx);
        ASSERT_FALSE(r.success, "should fail");
        ASSERT_STR_CONTAINS(r.text, "Error", "missing content error");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("write_file_missing_content");

    /* read_file basic */
    TEST_BEGIN("read_file_basic");
    {
        cJSON *p = cJSON_Parse("{\"path\":\"hello.txt\"}");
        ToolResult r = tool_read_file("read_file", p, &g_ctx);
        ASSERT_TRUE(r.success, "read succeeded");
        ASSERT_STR_CONTAINS(r.text, "hello world", "content present");
        ASSERT_STR_CONTAINS(r.text, "1 |", "line numbers present");
        ASSERT_STR_CONTAINS(r.text, "File: hello.txt", "filename in header");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("read_file_basic");

    /* read_file not found */
    TEST_BEGIN("read_file_not_found");
    {
        cJSON *p = cJSON_Parse("{\"path\":\"nonexistent.txt\"}");
        ToolResult r = tool_read_file("read_file", p, &g_ctx);
        ASSERT_FALSE(r.success, "should fail");
        ASSERT_STR_CONTAINS(r.text, "Error: File not found", "file not found error");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("read_file_not_found");

    /* read_file missing path */
    TEST_BEGIN("read_file_missing_path");
    {
        cJSON *p = cJSON_Parse("{}");
        ToolResult r = tool_read_file("read_file", p, &g_ctx);
        ASSERT_FALSE(r.success, "should fail");
        ASSERT_STR_CONTAINS(r.text, "Error", "missing path error");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("read_file_missing_path");

    /* delete_file */
    TEST_BEGIN("delete_file");
    {
        write_raw("to_delete.txt", "bye");
        cJSON *p = cJSON_Parse("{\"path\":\"to_delete.txt\"}");
        ToolResult r = tool_delete_file("delete_file", p, &g_ctx);
        ASSERT_TRUE(r.success, "delete succeeded");
        ASSERT_STR_CONTAINS(r.text, "OK: Deleted", "delete success");
        free(r.text);
        ToolResult r2 = tool_read_file("read_file", p, &g_ctx);
        ASSERT_FALSE(r2.success, "should fail after delete");
        ASSERT_STR_CONTAINS(r2.text, "Error: File not found", "file actually deleted");
        free(r2.text); cJSON_Delete(p);
    }
    TEST_PASS("delete_file");

    /* delete_file missing path */
    TEST_BEGIN("delete_file_missing_path");
    {
        cJSON *p = cJSON_Parse("{}");
        ToolResult r = tool_delete_file("delete_file", p, &g_ctx);
        ASSERT_FALSE(r.success, "should fail");
        ASSERT_STR_CONTAINS(r.text, "Error", "missing path error");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("delete_file_missing_path");

    /* list_files */
    TEST_BEGIN("list_files");
    {
        write_raw("alpha.c", "int a;");
        write_raw("beta.txt", "text");
        char mkdir_cmd[512];
        snprintf(mkdir_cmd, sizeof(mkdir_cmd), "mkdir -p %s/subdir2", g_tmpdir);
        system(mkdir_cmd);

        cJSON *p = cJSON_Parse("{}");
        ToolResult r = tool_list_files("list_files", p, &g_ctx);
        ASSERT_TRUE(r.success, "list succeeded");
        ASSERT_STR_CONTAINS(r.text, "alpha.c", "file listed");
        ASSERT_STR_CONTAINS(r.text, "beta.txt", "file listed");
        ASSERT_STR_CONTAINS(r.text, "[DIR]", "directory shown");
        ASSERT_STR_CONTAINS(r.text, "subdir2", "subdirectory listed");
        ASSERT_STR_NOT_CONTAINS(r.text, ".dotfile", "hidden files excluded");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("list_files");

    /* list_files empty dir */
    TEST_BEGIN("list_files_empty_dir");
    {
        char empty_path[512];
        snprintf(empty_path, sizeof(empty_path), "%s/emptydir", g_tmpdir);
        mkdir(empty_path, 0755);

        cJSON *p = cJSON_Parse("{\"path\":\"emptydir\"}");
        ToolResult r = tool_list_files("list_files", p, &g_ctx);
        ASSERT_TRUE(r.success, "list empty succeeded");
        ASSERT_STR_CONTAINS(r.text, "Directory: emptydir", "header present");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("list_files_empty_dir");

    /* search_in_file */
    TEST_BEGIN("search_in_file");
    {
        write_raw("search.txt", "line one\nline two match\nline three\nanother match here\n");
        cJSON *p = cJSON_Parse("{\"path\":\"search.txt\",\"pattern\":\"match\"}");
        ToolResult r = tool_search_in_file("search_in_file", p, &g_ctx);
        ASSERT_TRUE(r.success, "search succeeded");
        ASSERT_STR_CONTAINS(r.text, "L2:", "match on line 2");
        ASSERT_STR_CONTAINS(r.text, "L4:", "match on line 4");
        ASSERT_STR_CONTAINS(r.text, "Found 2 matches", "match count");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("search_in_file");

    /* search_in_file no matches */
    TEST_BEGIN("search_in_file_no_matches");
    {
        cJSON *p = cJSON_Parse("{\"path\":\"search.txt\",\"pattern\":\"zzzzz\"}");
        ToolResult r = tool_search_in_file("search_in_file", p, &g_ctx);
        ASSERT_TRUE(r.success, "search no matches succeeded");
        ASSERT_STR_CONTAINS(r.text, "no matches found", "no matches message");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("search_in_file_no_matches");

    /* search_in_file missing params */
    TEST_BEGIN("search_in_file_missing_params");
    {
        cJSON *p = cJSON_Parse("{\"path\":\"x.txt\"}");
        ToolResult r = tool_search_in_file("search_in_file", p, &g_ctx);
        ASSERT_FALSE(r.success, "should fail");
        ASSERT_STR_CONTAINS(r.text, "Error", "missing pattern error");
        free(r.text); cJSON_Delete(p);
    }
    TEST_PASS("search_in_file_missing_params");

    printf("\n%d tests, %d failures\n", g_tests_run, g_tests_failed);
    test_cleanup_temp_dir();
    return g_tests_failed > 0 ? 1 : 0;
}
