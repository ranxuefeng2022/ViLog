lua require('kanagawa').load()
