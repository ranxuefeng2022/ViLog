# frozen_string_literal: true

require "spec_helper"

RSpec.describe "Diff Popup", :git, :nvim, :popup do # rubocop:disable RSpec/EmptyExampleGroup
  let(:keymap) { "d" }
  let(:view) do
    [
      "Diff                      Show                                                  ",
      "d this       u unstaged   c Commit                                              ",
      "r range      s staged     t Stash                                               ",
      "p paths      w worktree                                                         "
    ]
  end

  %w[d r p u s w c t].each { it_behaves_like "interaction", it }
end
