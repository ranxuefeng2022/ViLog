# frozen_string_literal: true

require "spec_helper"

RSpec.describe "Remote Popup", :git, :nvim, :popup do
  let(:keymap) { "M" }
  let(:view) do
    [
      "Variables                                                                       ",
      "u remote.origin.url unset                                                       ",
      "U remote.origin.fetch unset                                                     ",
      "s remote.origin.pushurl unset                                                   ",
      "S remote.origin.push unset                                                      ",
      "O remote.origin.tagOpt [--no-tags|--tags]                                       ",
      "                                                                                ",
      "Arguments                                                                       ",
      "-f Fetch after add (-f)                                                         ",
      "                                                                                ",
      "Actions                                                                         ",
      "a Add         C Configure...                                                    ",
      "r Rename      p Prune stale branches                                            ",
      "x Remove      P Prune stale refspecs                                            ",
      "              b Update default branch                                           ",
      "              z Unshallow remote                                                "
    ]
  end

  %w[u U s S O a d x C p P b z].each { it_behaves_like "interaction", it }
  %w[-f].each { it_behaves_like "argument", it }

  describe "add" do
    context "with 'origin 'unset" do
      it "allow user to add remote" do
        nvim.keys("a")
        nvim.keys("origin<cr>")
        nvim.keys("git@github.com:NeogitOrg/neogit.git<cr>")
        origin = git.remote_list.find { |r| r.name == "origin" }
        expect(origin.name).to eq("origin")
        expect(origin.url.first).to eq("git@github.com:NeogitOrg/neogit.git")
      end
    end

    context "with 'origin' set" do
      before do
        git.config_set("remote.origin.url", "git@github.com:NeogitOrg/neogit.git")
      end

      it "auto-populates host/remote" do
        nvim.keys("a")
        nvim.keys("fork<cr>")
        expect(nvim.screen.last).to start_with("URL for fork: git@github.com:fork/neogit.git")
      end
    end
  end

  describe "remove" do
    context "with no remotes configured" do
      it "notifies user" do
        nvim.keys("x")
        expect(nvim.screen.last).to start_with("No remotes found")
      end
    end

    context "with a remote configured" do
      before do
        git.config_set("remote.origin.url", "git@github.com:NeogitOrg/neogit.git")
      end

      it "can remove a remote" do
        nvim.keys("x")
        nvim.keys("origin<cr>")
        expect(nvim.screen.last).to start_with("Removed remote 'origin'")
        expect(git.remote_list).to be_empty
      end
    end
  end

  describe "rename" do
    context "with no remotes configured" do
      it "notifies user" do
        nvim.keys("r")
        expect(nvim.screen.last).to start_with("No remotes found")
      end
    end

    context "with a remote configured" do
      before do
        git.config_set("remote.origin.url", "git@github.com:NeogitOrg/neogit.git")
      end

      it "can rename a remote" do
        nvim.keys("r")
        nvim.keys("origin<cr>")
        nvim.keys("fork<cr>")
        expect(nvim.screen.last).to start_with("Renamed 'origin' -> 'fork'")
        expect(git.remote_list.first.name).to eq("fork")
      end
    end
  end

  describe "configure" do
    context "with no remotes configured" do
      it "notifies user" do
        nvim.keys("C")
        expect(nvim.screen.last).to start_with("No remotes found")
      end
    end

    context "with a remote configured" do
      before do
        git.config_set("remote.origin.url", "git@github.com:NeogitOrg/neogit.git")
      end

      it "can launch remote config popup" do
        nvim.keys("C")
        nvim.keys("origin<cr>")
        await do
          screen = nvim.screen
          idx    = screen.index { |line| line.start_with?("Configure remote") }
          expect(screen[idx, 6]).to eq(
            ["Configure remote                                                                ",
             "u remote.origin.url git@github.com:NeogitOrg/neogit.git                         ",
             "U remote.origin.fetch unset                                                     ",
             "s remote.origin.pushurl unset                                                   ",
             "S remote.origin.push unset                                                      ",
             "O remote.origin.tagOpt [--no-tags|--tags]                                       "]
          )
        end
      end
    end
  end

  describe "prune_branches" do
    context "with no remotes configured" do
      it "notifies user" do
        nvim.keys("p")
        expect(nvim.screen.last).to start_with("No remotes found")
      end
    end

    context "with a remote configured" do
      before do
        git.config_set("remote.origin.url", "git@github.com:NeogitOrg/neogit.git")
      end

      it "can launch remote config popup" do
        nvim.keys("p")
        nvim.keys("origin<cr>")
        await do
          expect(nvim.screen.last).to start_with("Pruned remote origin")
        end
      end
    end
  end

  describe "unshallow" do
    context "with no remotes configured" do
      it "notifies user" do
        nvim.keys("z")
        expect(nvim.screen.last).to start_with("No remotes found")
      end
    end
  end
end
