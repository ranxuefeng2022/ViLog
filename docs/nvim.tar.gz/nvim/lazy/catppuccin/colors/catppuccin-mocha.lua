require("catppuccin").load "mocha"
