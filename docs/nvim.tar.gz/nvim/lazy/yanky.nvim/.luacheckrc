globals = { "vim", "Snacks" }
